"""智慧图书馆数字资源平台 —— 命令行主程序。

两种运行方式：
    python3 app.py            # 菜单式交互
    python3 app.py --demo     # 无人值守全功能自检（用于过程记录与验收取证）

程序只通过 db.py 取连接，连接参数全部来自环境变量（单机 / 副本集 / 分片集群均可复用）。
"""
import sys
from datetime import datetime

import config
import db
import schema
import audit
import book_service
import reader_service
import borrow_service
import file_service
from util import print_table, banner, fmt_day

MENU = """
==================== 智慧图书馆数字资源平台 ====================
 检索（6 项）
   1. 按类别 + 价格区间筛选图书        2. 按标签多选匹配（同时含）
   3. 按书名模糊检索                  4. 按出版年份范围检索
   5. 核查缺少 tags 的图书           6. 评分榜 TOP10
 统计（5 项）
   7. 按类别统计藏书量/均价/评分      8. 学院借阅量 TOP5
   9. 月度借阅趋势                   10. 借阅次数 TOP10（含馆藏位置）
  11. 生成并写入分类统计集合
 业务
  12. 新增图书        13. 删除图书       14. 读者检索
  15. 借书            16. 还书/逾期扫描
 文件与日志
  17. 上传电子书/封面（GridFS）       18. 按书名查电子书并下载校验
  19. GridFS 文件清单                 20. 最近操作日志
   0. 退出
===============================================================
"""


def show_identity():
    info = db.server_identity()
    print(f"连接目标：{info['uri']}")
    print(f"拓扑类型：{info['topology']}    当前主节点：{info['primary']}    "
          f"读偏好：{info['readPreference']}")
    print(f"集合条数：{db.collection_counts()}")


# ---------- 1-6 检索 ----------
def q1():
    rows, n = book_service.search_by_category_price("计算机", 50, 100, limit=20)
    print_table([(r["isbn"], r["title"], r["category"], r["price"]) for r in rows],
                ["ISBN", "书名", "类别", "价格"], widths=[15, 34, 8, 7])
    print(f"结果数量：{n}")


def q2():
    rows, n = book_service.search_by_tags_all(["编程", "入门"])
    print_table([(r["isbn"], r["title"], "/".join(r["tags"])) for r in rows],
                ["ISBN", "书名", "标签"], widths=[15, 34, 26])
    print(f"结果数量：{n}")


def q3():
    rows, n = book_service.search_title_like("计算机", limit=20)
    print_table([(r["isbn"], r["title"], r["author"]) for r in rows],
                ["ISBN", "书名", "作者"], widths=[15, 36, 18])
    print(f"结果数量：{n}")


def q4():
    rows, n = book_service.search_by_year_range(2022, 2024)
    print_table([(r["isbn"], r["title"], fmt_day(r["publish_date"])) for r in rows],
                ["ISBN", "书名", "出版日期"], widths=[15, 36, 12])
    print(f"结果数量：{n}")


def q5():
    rows, n = book_service.find_missing_tags()
    print_table([(r["isbn"], r["title"], r["category"]) for r in rows],
                ["ISBN", "书名", "类别"], widths=[15, 36, 8])
    print(f"结果数量：{n}（数据质量核查：这些图书缺 tags 字段）")


def q6():
    rows, n = book_service.top_rated(10)
    print_table([(r["title"], r["author"], r["rating"]) for r in rows],
                ["书名", "作者", "评分"], widths=[36, 18, 6])
    print(f"结果数量：{n}")


# ---------- 7-11 统计 ----------
def q7():
    rows, n = borrow_service.stats_by_category()
    print_table([(r["_id"], r["book_count"], r["total_stock"], f"{r['avg_price']:.1f}",
                  f"{r['avg_rating']:.2f}") for r in rows],
                ["类别", "藏书量", "在架库存", "平均价格", "平均评分"],
                widths=[10, 8, 10, 10, 10])
    print(f"结果数量：{n} 个类别")


def q8():
    rows, n = borrow_service.top_colleges(5)
    print_table([(i + 1, r["_id"], r["borrow_total"], r["readers"]) for i, r in enumerate(rows)],
                ["排名", "学院", "借阅总量", "活跃读者数"], widths=[6, 16, 10, 12])
    print(f"结果数量：{n} 行（TOP5）")


def q9():
    rows, n = borrow_service.monthly_trend()
    print_table([(r["_id"], r["count"], "▇" * max(1, round(r["count"] / 8))) for r in rows],
                ["年月", "借阅量", "趋势"], widths=[10, 8, 30], max_rows=40)
    print(f"结果数量：{n} 个月")


def q10():
    rows, n = borrow_service.top_borrowed_books(10)
    print_table([(r["title"], r["category"], r["borrow_times"],
                  f"{r['location']['floor']}/{r['location']['shelf']}") for r in rows],
                ["书名", "类别", "借阅次数", "馆藏位置"], widths=[34, 10, 10, 30])
    print(f"结果数量：{n}")


def q11():
    n = borrow_service.materialize_category_stats()
    rows = borrow_service.read_category_stats()
    print_table([(r["category"], r["book_count"], r["avg_price"], r["avg_rating"])
                 for r in rows], ["类别", "藏书量", "平均价格", "平均评分"],
                widths=[10, 8, 10, 10])
    print(f"已写入集合 {config.COL_CATEGORY_STATS}：{n} 条（可直接按 category 查询）")


def q12():
    demo_book = {
        "isbn": "9787000000001",
        "title": "MongoDB 实战（演示临时数据）",
        "author": "项目组",
        "publisher": "内部资料",
        "category": "计算机",
        "price": 66.0,
        "rating": 4.2,
        "stock": 3,
        "tags": ["NoSQL", "演示"],
        "publish_date": "2025-06-01",
        "borrow_count": 0,
        "location": {"floor": "三楼新书区", "shelf": "N-01", "copies": 1},
    }
    book_service.add_book(demo_book)
    print(f"新增图书成功：{demo_book['title']}，当前图书总数 "
          f"{db.get_db()[config.COL_BOOKS].count_documents({})}")


def q13():
    n = book_service.delete_book("9787000000001")
    print(f"删除演示图书 {n} 条，当前图书总数 "
          f"{db.get_db()[config.COL_BOOKS].count_documents({})}")


def q14():
    rows, n = reader_service.search(keyword="张", limit=20)
    print_table([(r["card_no"], r["name"], r["college"], r["level"]) for r in rows],
                ["借阅证号", "姓名", "学院", "等级"], widths=[12, 10, 18, 8])
    print(f"结果数量：{n}")


def q15():
    ok, msg = borrow_service.borrow("R20240001", "9787115428028", days=30)
    print(msg)


def q16():
    rows, n = borrow_service.overdue_scan(days=60, limit=10)
    print_table([(r["reader_card"], r["book_isbn"], fmt_day(r["borrow_date"]), r["status"])
                 for r in rows], ["借阅证号", "ISBN", "借阅日期", "状态"],
                widths=[12, 16, 12, 8])
    print(f"超 60 天未还的在借记录：{n} 条")


def q17():
    manifest = [
        ("ebook_1.pdf", "9787115428028", "ebook"), ("ebook_2.pdf", "9787121362726", "ebook"),
        ("ebook_3.pdf", "9787115546081", "ebook"), ("cover_1.png", "9787115428028", "cover"),
        ("cover_2.png", "9787121362726", "cover"), ("cover_3.png", "9787115546081", "cover"),
    ]
    rows = []
    for name, isbn, ftype in manifest:
        info = file_service.upload_file(config.DATA_DIR / name, isbn=isbn, file_type=ftype)
        rows.append((info["filename"], ftype, isbn, info["bytes"], info["local_bytes"],
                     "一致" if info["bytes"] == info["local_bytes"] else "不一致"))
    print_table(rows, ["文件", "类型", "ISBN", "GridFS字节", "本地字节", "核对"],
                widths=[14, 7, 15, 11, 9, 6])
    print("上传完成：6 个文件（3 本 PDF + 3 张封面），字节数与源文件一致")


def q18():
    hits = file_service.find_by_title("Python编程")
    for h in hits:
        print(f"命中：{h['title']} -> {h['filename']}（{h['bytes']} 字节）")
        res = file_service.download_by_isbn(h["isbn"], expect_bytes=h["bytes"])
        print(f"下载到：{res['path']}")
        print(f"校验：GridFS {res['gridfs_bytes']} 字节 / 本地 {res['local_bytes']} 字节 / "
              f"SHA-256 一致={res['sha256_match']} -> {'校验通过' if res['ok'] else '校验失败'}")


def q19():
    rows = file_service.list_files()
    print_table([(r["filename"], r["file_type"], r["bytes"], str(r["uploadDate"])[:19], r["isbn"])
                 for r in rows], ["文件名", "类型", "字节", "上传时间", "ISBN"],
                widths=[14, 7, 9, 20, 15], max_rows=20)
    print(f"GridFS 文件总数：{len(rows)}")


def q20():
    audit.dump(12)


MENU_ACTIONS = {
    "1": q1, "2": q2, "3": q3, "4": q4, "5": q5, "6": q6, "7": q7, "8": q8, "9": q9,
    "10": q10, "11": q11, "12": q12, "13": q13, "14": q14, "15": q15, "16": q16,
    "17": q17, "18": q18, "19": q19, "20": q20,
}


def demo():
    banner("智慧图书馆数字资源平台 —— 全功能自检（--demo）")
    show_identity()
    for num, title in [
        ("1", "检索① 类别+价格区间"), ("2", "检索② 标签多选匹配"), ("3", "检索③ 书名模糊"),
        ("4", "检索④ 出版年份范围"), ("5", "检索⑤ 缺 tags 数据质量核查"), ("6", "检索⑥ 评分榜 TOP10"),
    ]:
        banner(title, "-")
        MENU_ACTIONS[num]()
    for num, title in [
        ("7", "统计① 分类藏书/均价/评分"), ("8", "统计② 学院借阅 TOP5"),
        ("9", "统计③ 月度借阅趋势"), ("10", "统计④ 借阅 TOP10 + 馆藏位置"),
        ("11", "统计⑤ 分类统计落库"),
    ]:
        banner(title, "-")
        MENU_ACTIONS[num]()
    banner("业务：读者检索 / 借书还书（演示实体隔离，不动真实数据）", "-")
    q14()
    demo_card, demo_isbn = "RDEMO0001", "9787000000001"
    reader_service.add_reader({
        "card_no": demo_card, "name": "演示读者", "college": "计算机学院",
        "email": "demo@example.edu", "phone": "13900000000", "level": "普通",
        "register_date": "2026-09-01", "fav_categories": ["计算机"],
    })
    book_service.add_book({
        "isbn": demo_isbn, "title": "MongoDB 实战（演示临时数据）", "author": "项目组",
        "publisher": "内部资料", "category": "计算机", "price": 66.0, "rating": 4.2,
        "stock": 3, "tags": ["NoSQL", "演示"], "publish_date": "2025-06-01",
        "borrow_count": 0, "location": {"floor": "三楼新书区", "shelf": "N-01", "copies": 1},
    })
    print(borrow_service.borrow(demo_card, demo_isbn, days=15)[1])
    print(borrow_service.return_book(demo_card, demo_isbn)[1])
    # 清理演示实体：流水、读者、图书一起删除，保证 50/30/3000 不被污染
    db.get_db()[config.COL_BORROW].delete_many({"reader_card": demo_card})
    reader_service.delete_reader(demo_card)
    book_service.delete_book(demo_isbn)
    print(f"演示实体已清理，当前集合条数：{db.collection_counts()}")
    banner("文件存储：GridFS 上传 / 下载校验 / 清单", "-")
    q17()
    q18()
    q19()
    banner("操作日志 audit_logs", "-")
    q20()
    banner("自检结束：最终集合条数")
    print(db.collection_counts())
    db.close()


def interactive():
    print(MENU)
    show_identity()
    while True:
        choice = input("\n请选择功能编号（0 退出）：").strip()
        if choice == "0":
            break
        action = MENU_ACTIONS.get(choice)
        if not action:
            print("无效编号，请重新输入")
            continue
        try:
            action()
        except Exception as exc:
            print(f"执行失败：{exc}")
    db.close()


if __name__ == "__main__":
    config.ensure_dirs()
    schema.ensure_collections(db.get_db())
    if "--demo" in sys.argv:
        demo()
    else:
        interactive()
