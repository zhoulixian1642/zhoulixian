"""操作日志模块。

设计要点（对应 T2 的 audit_logs 设计决策）：
- 普通集合而非时间序列：写入量低（人工操作级），但需要按 action 过滤与长期留存；
- ts 单独建倒序索引，支撑「按时间倒序查询最近 100 条」；
- detail 用嵌套文档保存前后值，字段可变，不额外拆表。
"""
import os
from datetime import datetime, timezone

import config
import db
from util import fmt_date

_OPERATOR = os.environ.get("SMARTLIB_OPERATOR", "app_user")


def record(action: str, target: str = "", detail: dict = None, result: str = "ok") -> dict:
    doc = {
        "ts": datetime.now(timezone.utc).replace(tzinfo=None),
        "operator": _OPERATOR,
        "action": action,
        "target": str(target),
        "detail": detail or {},
        "result": result,
    }
    db.get_db()[config.COL_AUDIT].insert_one(doc)
    return doc


def recent(limit: int = 100) -> list:
    cur = db.get_db()[config.COL_AUDIT].find({}, {"_id": 0}).sort("ts", -1).limit(limit)
    return list(cur)


def dump(limit: int = 10) -> None:
    rows = recent(limit)
    if not rows:
        print("（暂无操作日志）")
        return
    data = [(fmt_date(r["ts"]), r["operator"], r["action"], r["target"], r["result"]) for r in rows]
    from util import print_table
    print_table(data, ["时间", "操作人", "动作", "对象", "结果"], max_rows=limit,
                widths=[17, 12, 12, 26, 6], title=f"最近 {limit} 条操作日志（audit_logs，按 ts 倒序）")
