"""图书业务模块：检索、增删改、数据质量核查。

检索函数与任务书 F3/F4 的 11 项能力一一对应，返回 (结果列表, 命中条数)，
便于程序既打印数据又记录"结果数量"。
"""
from datetime import datetime, timezone

import config
import db
import audit
from util import to_date


def _coll():
    return db.get_db()[config.COL_BOOKS]


# ---------- 6 项检索 ----------
def search_by_category_price(category: str, min_price: float, max_price: float, limit: int = 0):
    """1) 按类别 + 价格区间组合筛选（走 idx_category_price）。"""
    query = {"category": category, "price": {"$gte": min_price, "$lte": max_price}}
    cur = _coll().find(query, {"_id": 0, "isbn": 1, "title": 1, "category": 1, "price": 1})
    if limit:
        cur = cur.limit(limit)
    rows = list(cur)
    return rows, len(rows)


def search_by_tags_all(tags, limit: int = 0):
    """2) 按标签多选匹配：$all，要求同时含全部指定标签（走 idx_tags 多键索引）。"""
    query = {"tags": {"$all": list(tags)}}
    cur = _coll().find(query, {"_id": 0, "isbn": 1, "title": 1, "tags": 1})
    if limit:
        cur = cur.limit(limit)
    rows = list(cur)
    return rows, len(rows)


def search_title_like(keyword: str, limit: int = 0):
    """3) 按书名模糊检索：正则匹配，不区分大小写。"""
    query = {"title": {"$regex": keyword, "$options": "i"}}
    cur = _coll().find(query, {"_id": 0, "isbn": 1, "title": 1, "author": 1})
    if limit:
        cur = cur.limit(limit)
    rows = list(cur)
    return rows, len(rows)


def search_by_year_range(start_year: int, end_year: int, limit: int = 0):
    """4) 按出版年份范围检索（Date 字段比较，走 idx_publish_date）。"""
    start = datetime(start_year, 1, 1)
    end = datetime(end_year + 1, 1, 1)
    query = {"publish_date": {"$gte": start, "$lt": end}}
    cur = _coll().find(query, {"_id": 0, "isbn": 1, "title": 1, "publish_date": 1})
    if limit:
        cur = cur.limit(limit)
    rows = list(cur)
    return rows, len(rows)


def find_missing_tags():
    """5) 查询缺少 tags 字段的图书（$exists:false），用于数据质量核查。"""
    query = {"tags": {"$exists": False}}
    rows = list(_coll().find(query, {"_id": 0, "isbn": 1, "title": 1, "category": 1}))
    return rows, len(rows)


def top_rated(limit: int = 10):
    """6) 按评分降序取前 N（排序 + 投影，只返回书名、作者、评分）。"""
    cur = _coll().find({}, {"_id": 0, "title": 1, "author": 1, "rating": 1}) \
        .sort("rating", -1).limit(limit)
    rows = list(cur)
    return rows, len(rows)


# ---------- 增删改 ----------
def add_book(doc: dict, operator: str = None) -> dict:
    doc = dict(doc)
    doc["isbn"] = str(doc["isbn"]).strip()
    doc["price"] = float(doc.get("price", 0))
    doc["rating"] = float(doc.get("rating", 0))
    doc["stock"] = int(doc.get("stock", 0))
    doc["borrow_count"] = int(doc.get("borrow_count", 0))
    if doc.get("publish_date"):
        doc["publish_date"] = to_date(doc["publish_date"])
    doc.setdefault("tags", [])
    doc.setdefault("location", {"floor": "未分配", "shelf": "未分配", "copies": 1})
    _coll().insert_one(doc)
    audit.record("新增图书", doc["isbn"], {"title": doc.get("title")})
    return doc


def update_stock(isbn: str, stock: int) -> int:
    res = _coll().update_one({"isbn": isbn}, {"$set": {"stock": int(stock)}})
    audit.record("修改库存", isbn, {"stock": int(stock)})
    return res.modified_count


def delete_book(isbn: str) -> int:
    doc = _coll().find_one({"isbn": isbn}, {"_id": 0, "title": 1})
    res = _coll().delete_one({"isbn": isbn})
    audit.record("删除图书", isbn, {"title": (doc or {}).get("title")})
    return res.deleted_count


def get_by_isbn(isbn: str) -> dict:
    return _coll().find_one({"isbn": isbn}, {"_id": 0})


def paginate(page: int = 1, size: int = 10, query: dict = None):
    """通用分页 + 排序，供图形化界面与命令行共用。"""
    query = query or {}
    skip = (page - 1) * size
    total = _coll().count_documents(query)
    rows = list(_coll().find(query, {"_id": 0}).sort("isbn", 1).skip(skip).limit(size))
    return rows, total


def export_all(path) -> int:
    import json
    rows = list(_coll().find({}, {"_id": 0}))
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=1, default=str)
    audit.record("导出图书数据", str(path.name), {"rows": len(rows)})
    return len(rows)
