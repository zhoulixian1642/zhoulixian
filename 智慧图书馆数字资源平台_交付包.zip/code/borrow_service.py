"""借阅业务与统计模块。

11 项能力中的 5 项统计都在这里：分类统计、学院排行、月度趋势、
借阅排行（关联馆藏位置）、统计结果落库。
"""
from datetime import datetime, timedelta, timezone

import config
import db
import audit
import book_service
import reader_service


def _logs():
    return db.get_db()[config.COL_BORROW]


# ---------- 借还 ----------
def borrow(card_no: str, isbn: str, days: int = 30):
    """借书：校验读者/图书存在、在借上限、库存>0，然后写流水并回扣库存。"""
    reader = reader_service.get_by_card(card_no)
    if not reader:
        return False, f"借阅证 {card_no} 不存在"
    book = book_service.get_by_isbn(isbn)
    if not book:
        return False, f"ISBN {isbn} 不存在"
    if book.get("stock", 0) <= 0:
        return False, "库存不足，无法借出"
    if reader_service.active_borrow_count(card_no) >= reader_service.borrow_limit(card_no):
        return False, "已达该读者借阅上限"
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    doc = {
        "borrow_date": now,
        "reader_card": card_no,
        "book_isbn": isbn,
        "status": "借出",
        "duration_days": int(days),
    }
    _logs().insert_one(doc)
    db.get_db()[config.COL_BOOKS].update_one(
        {"isbn": isbn}, {"$inc": {"stock": -1, "borrow_count": 1}}
    )
    audit.record("借书", f"{card_no}/{isbn}", {"days": int(days)})
    return True, f"借出成功：{reader['name']} 借《{book['title']}》，应还日期 " \
                 f"{(now + timedelta(days=days)).strftime('%Y-%m-%d')}"


def return_book(card_no: str, isbn: str):
    """还书：把最近一条「借出/逾期」流水置为已归还，回补库存。"""
    log = _logs().find_one(
        {"reader_card": card_no, "book_isbn": isbn, "status": {"$in": ["借出", "逾期"]}},
        sort=[("borrow_date", -1)],
    )
    if not log:
        return False, "未找到该读者的在借记录"
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    days = max((now - log["borrow_date"]).days, 0)
    _logs().update_one({"_id": log["_id"]},
                       {"$set": {"status": "已归还", "return_date": now, "duration_days": days}})
    db.get_db()[config.COL_BOOKS].update_one({"isbn": isbn}, {"$inc": {"stock": 1}})
    audit.record("还书", f"{card_no}/{isbn}", {"duration_days": days})
    return True, f"归还成功，实际借阅 {days} 天"


def overdue_scan(days: int = 30, limit: int = 10):
    """逾期识别：仍在借出且借阅时长超过阈值。"""
    threshold = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=days)
    query = {"status": "借出", "borrow_date": {"$lt": threshold}}
    rows = list(_logs().find(query, {"_id": 0}).sort("borrow_date", 1).limit(limit))
    return rows, _logs().count_documents(query)


# ---------- 5 项统计 ----------
def stats_by_category():
    """7) 按类别统计藏书量、平均价格、平均评分（$group + $avg）。"""
    pipeline = [
        {"$group": {
            "_id": "$category",
            "book_count": {"$sum": 1},
            "total_stock": {"$sum": "$stock"},
            "avg_price": {"$avg": "$price"},
            "avg_rating": {"$avg": "$rating"},
            "total_borrow": {"$sum": "$borrow_count"},
        }},
        {"$sort": {"book_count": -1}},
    ]
    rows = list(db.get_db()[config.COL_BOOKS].aggregate(pipeline))
    return rows, len(rows)


def top_colleges(limit: int = 5):
    """8) 统计各学院借阅总量，取前 5（借阅集合 $lookup 读者集合）。"""
    pipeline = [
        {"$group": {"_id": "$reader_card", "borrows": {"$sum": 1}}},
        {"$lookup": {"from": config.COL_READERS, "localField": "_id",
                     "foreignField": "card_no", "as": "reader"}},
        {"$unwind": {"path": "$reader", "preserveNullAndEmptyArrays": False}},
        {"$group": {"_id": "$reader.college", "readers": {"$sum": 1},
                    "borrow_total": {"$sum": "$borrows"}}},
        {"$sort": {"borrow_total": -1}},
        {"$limit": limit},
    ]
    rows = list(db.get_db()[config.COL_BORROW].aggregate(pipeline))
    return rows, len(rows)


def monthly_trend():
    """9) 按月统计借阅趋势，输出可读年月标签（$dateToString 指定 +08:00）。"""
    pipeline = [
        {"$group": {
            "_id": {"$dateToString": {"format": "%Y-%m", "date": "$borrow_date", "timezone": "+08:00"}},
            "count": {"$sum": 1},
        }},
        {"$sort": {"_id": 1}},
    ]
    rows = list(db.get_db()[config.COL_BORROW].aggregate(pipeline))
    return rows, len(rows)


def top_borrowed_books(limit: int = 10):
    """10) 找出借阅次数最多的 10 本图书，并关联馆藏位置（books.location）。"""
    pipeline = [
        {"$group": {"_id": "$book_isbn", "borrow_times": {"$sum": 1}}},
        {"$sort": {"borrow_times": -1}},
        {"$limit": limit},
        {"$lookup": {"from": config.COL_BOOKS, "localField": "_id",
                     "foreignField": "isbn", "as": "book"}},
        {"$unwind": "$book"},
        {"$project": {
            "_id": 0, "isbn": "$_id", "title": "$book.title", "category": "$book.category",
            "borrow_times": 1, "location": "$book.location", "ebook_name": "$book.ebook_name",
        }},
    ]
    rows = list(db.get_db()[config.COL_BORROW].aggregate(pipeline))
    return rows, len(rows)


def materialize_category_stats():
    """11) 把分类统计结果写入新集合 category_stats，供后续直接查询。"""
    rows, _ = stats_by_category()
    coll = db.get_db()[config.COL_CATEGORY_STATS]
    coll.delete_many({})
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    docs = [{
        "category": r["_id"],
        "book_count": r["book_count"],
        "total_stock": r["total_stock"],
        "avg_price": round(r["avg_price"], 2),
        "avg_rating": round(r["avg_rating"], 3),
        "total_borrow": r["total_borrow"],
        "generated_at": now,
    } for r in rows]
    if docs:
        coll.insert_many(docs)
        coll.create_index([("category", 1)], unique=True, name="uk_category")
    audit.record("生成分类统计", config.COL_CATEGORY_STATS, {"rows": len(docs)})
    return len(docs)


def read_category_stats():
    return list(db.get_db()[config.COL_CATEGORY_STATS].find({}, {"_id": 0}).sort("book_count", -1))


def export_stats(path) -> dict:
    """导出统计结果集合为 JSON + CSV，交付物之一。"""
    import csv
    import json
    data = {
        "by_category": [
            dict(r, _id=r["_id"]) for r in stats_by_category()[0]
        ],
        "top_colleges": top_colleges()[0],
        "monthly_trend": monthly_trend()[0],
        "top_borrowed_books": top_borrowed_books()[0],
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=1, default=str)
    csv_path = path.with_suffix(".csv")
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["统计项", "维度", "指标1", "指标2", "指标3"])
        for r in data["by_category"]:
            writer.writerow(["类别藏书", r["_id"], r["book_count"], round(r["avg_price"], 2),
                             round(r["avg_rating"], 3)])
        for r in data["top_colleges"]:
            writer.writerow(["学院借阅", r["_id"], r["borrow_total"], r["readers"], ""])
        for r in data["monthly_trend"]:
            writer.writerow(["月度趋势", r["_id"], r["count"], "", ""])
        for r in data["top_borrowed_books"]:
            writer.writerow(["借阅排行", r["title"], r["borrow_times"],
                             (r.get("location") or {}).get("shelf", ""), r["isbn"]])
    audit.record("导出统计", path.name, {"items": len(data)})
    return {"json": str(path), "csv": str(csv_path), "items": len(data)}
