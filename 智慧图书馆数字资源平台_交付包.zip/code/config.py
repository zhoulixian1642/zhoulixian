"""全局配置。

原则：程序内不出现硬编码的绝对路径与写死的连接串，全部通过环境变量覆盖；
默认值只指向本机 127.0.0.1:27017 与项目内 data 目录，换机器只需改环境变量。
"""
import os
from pathlib import Path

# 项目根目录：code/ 的上一级，所有相对路径都从这里出发
BASE_DIR = Path(__file__).resolve().parent.parent


def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


# ---------- 连接参数 ----------
MONGO_URI = _env("MONGO_URI")                      # 整串优先，形如 mongodb://host:port
MONGO_HOST = _env("MONGO_HOST", "127.0.0.1")
MONGO_PORT = int(_env("MONGO_PORT", "27017"))
MONGO_DB = _env("MONGO_DB", "smartlib")

MONGO_USER = _env("MONGO_USER")                    # 启用认证时填写
MONGO_PASSWORD = _env("MONGO_PASSWORD")
MONGO_AUTH_SOURCE = _env("MONGO_AUTH_SOURCE", "admin")

MONGO_REPLICA_SET = _env("MONGO_REPLICA_SET")      # 副本集名，单机/分片留空
# primary / primaryPreferred / secondaryPreferred / nearest
READ_PREFERENCE = _env("MONGO_READ_PREFERENCE", "primary")
APP_NAME = "smartlib-app"

# ---------- 业务路径 ----------
DATA_DIR = Path(_env("SMARTLIB_DATA_DIR", str(BASE_DIR / "data")))
EXPORT_DIR = Path(_env("SMARTLIB_EXPORT_DIR", str(BASE_DIR / "data" / "exports")))
DOWNLOAD_DIR = Path(_env("SMARTLIB_DOWNLOAD_DIR", str(BASE_DIR / "data" / "downloads")))
GRIDFS_BUCKET = _env("SMARTLIB_GRIDFS_BUCKET", "ebook_fs")

# ---------- 数据文件 ----------
BOOKS_FILE = DATA_DIR / "books.txt"
READERS_FILE = DATA_DIR / "readers.txt"
BORROW_FILE = DATA_DIR / "borrow_logs.txt"

# ---------- 集合名 ----------
COL_BOOKS = "books"
COL_READERS = "readers"
COL_BORROW = "borrow_logs"
COL_AUDIT = "audit_logs"
COL_CATEGORY_STATS = "category_stats"


def build_uri() -> str:
    """拼装连接串：显式 MONGO_URI 优先，否则按主机端口/认证/副本集参数拼。"""
    if MONGO_URI:
        return MONGO_URI
    if MONGO_USER and MONGO_PASSWORD:
        from urllib.parse import quote_plus
        auth = f"{quote_plus(MONGO_USER)}:{quote_plus(MONGO_PASSWORD)}@{MONGO_HOST}:{MONGO_PORT}"
        uri = f"mongodb://{auth}/?authSource={MONGO_AUTH_SOURCE}"
    else:
        uri = f"mongodb://{MONGO_HOST}:{MONGO_PORT}/"
    if MONGO_REPLICA_SET:
        sep = "&" if "?" in uri else "?"
        uri = f"{uri}{sep}replicaSet={MONGO_REPLICA_SET}"
    if READ_PREFERENCE and READ_PREFERENCE != "primary":
        sep = "&" if "?" in uri else "?"
        uri = f"{uri}{sep}readPreference={READ_PREFERENCE}"
    return uri


def ensure_dirs() -> None:
    for d in (EXPORT_DIR, DOWNLOAD_DIR):
        d.mkdir(parents=True, exist_ok=True)


def describe() -> str:
    """对外展示当前连接目标（不打印密码）。"""
    tail = f" / replicaSet={MONGO_REPLICA_SET}" if MONGO_REPLICA_SET else ""
    return f"{MONGO_HOST}:{MONGO_PORT} db={MONGO_DB} readPreference={READ_PREFERENCE}{tail}"
