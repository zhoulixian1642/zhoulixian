"""统一数据库连接模块。

所有业务程序（图书、读者、借阅、GridFS、导出、图形化控制台）只通过本模块取连接，
换单机 / 副本集 / 分片集群、开关认证，都只改环境变量，不改业务代码。
"""
from pymongo import MongoClient, ReadPreference
from pymongo.errors import ServerSelectionTimeoutError, OperationFailure
import gridfs

import config

_client = None
_uri = None


def get_client() -> MongoClient:
    """进程内单例；首次连接失败会抛出可读错误，避免程序继续跑空。"""
    global _client, _uri
    if _client is not None:
        return _client
    uri = config.build_uri()
    _client = MongoClient(
        uri,
        appname=config.APP_NAME,
        serverSelectionTimeoutMS=5000,
        connectTimeoutMS=5000,
        maxPoolSize=20,
    )
    try:
        _client.admin.command("ping")
    except (ServerSelectionTimeoutError, OperationFailure) as exc:
        _client.close()
        _client = None
        raise RuntimeError(f"无法连接 MongoDB：{config.describe()} -> {exc}") from exc
    _uri = uri
    return _client


def get_db():
    return get_client()[config.MONGO_DB]


def get_fs() -> gridfs.GridFS:
    # pymongo 4.x：桶名通过 collection 参数指定，实际集合为 <bucket>.files / <bucket>.chunks
    return gridfs.GridFS(get_db(), collection=config.GRIDFS_BUCKET)


def read_preference() -> str:
    return config.READ_PREFERENCE


READ_PREFS = {
    "primary": ReadPreference.PRIMARY,
    "primaryPreferred": ReadPreference.PRIMARY_PREFERRED,
    "secondary": ReadPreference.SECONDARY,
    "secondaryPreferred": ReadPreference.SECONDARY_PREFERRED,
    "nearest": ReadPreference.NEAREST,
}


def get_collection(name: str, read_pref: str = None):
    """按需指定读偏好的集合句柄（pymongo 4.x 读偏好是集合/操作级设置）。"""
    coll = get_db()[name]
    if read_pref:
        coll = coll.with_options(read_preference=READ_PREFS[read_pref])
    return coll


def server_identity() -> dict:
    """连接健康检查：拓扑类型、主节点、当前读偏好，用于截图取证。"""
    client = get_client()
    info = {"uri": config.describe(), "primary": None, "topology": "standalone",
            "readPreference": config.READ_PREFERENCE, "setName": None}
    try:
        hello = client.admin.command("isMaster")
    except Exception:
        hello = {}
    info["setName"] = hello.get("setName")
    if hello.get("msg") == "isdbgrid":
        info["topology"] = "sharded（mongos 路由）"
    elif hello.get("setName"):
        info["topology"] = f"replicaset（{hello['setName']}）"
    else:
        info["topology"] = "standalone（单机）"
    if info["topology"].startswith("sharded"):
        info["primary"] = "无（mongos 不区分主从）"
    elif info["topology"].startswith("standalone"):
        info["primary"] = "无（单机无主节点）"
    else:
        info["primary"] = hello.get("primary") or "（选举中）"
    return info


def collection_counts() -> dict:
    db = get_db()
    return {
        config.COL_BOOKS: db[config.COL_BOOKS].count_documents({}),
        config.COL_READERS: db[config.COL_READERS].count_documents({}),
        config.COL_BORROW: db[config.COL_BORROW].count_documents({}),
        config.COL_AUDIT: db[config.COL_AUDIT].count_documents({}),
    }


def close() -> None:
    global _client
    if _client is not None:
        _client.close()
        _client = None
