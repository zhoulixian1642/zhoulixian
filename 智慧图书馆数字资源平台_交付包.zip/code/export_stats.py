"""导出统计结果集合：生成交付用的 datasets/borrow_stats_export.json + .csv。"""
import config
import db
import borrow_service


def main():
    config.ensure_dirs()
    borrow_service.materialize_category_stats()
    path = config.EXPORT_DIR / "borrow_stats_export.json"
    info = borrow_service.export_stats(path)
    rows = borrow_service.read_category_stats()
    from util import print_table
    print_table([(r["category"], r["book_count"], r["avg_price"], r["avg_rating"])
                 for r in rows], ["类别", "藏书量", "均价", "均分"], widths=[10, 8, 8, 8],
                title="分类统计（category_stats 集合）")
    print(f"导出完成：{info['json']}（{info['items']} 组统计）")
    print(f"CSV 副本：{info['csv']}")
    db.close()


if __name__ == "__main__":
    main()
