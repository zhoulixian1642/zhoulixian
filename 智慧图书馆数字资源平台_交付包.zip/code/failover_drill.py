"""故障转移演练：杀掉主节点 -> 观察重新选举 -> 记录耗时 -> 重启原主节点观察角色变化。

生产环境的"手工停主节点"在这里用 SIGKILL 模拟进程崩溃（比正常关闭更严苛）。
"""
import json
import os
import signal
import time
from pathlib import Path

from pymongo import MongoClient
from pymongo.errors import PyMongoError

ROOT = Path(__file__).resolve().parent.parent
HOSTS = ["127.0.0.1:27018", "127.0.0.1:27019", "127.0.0.1:27020"]
URL = "mongodb://" + ",".join(HOSTS) + "/smartlib?replicaSet=rs0"


def roles() -> dict:
    out = {}
    for host in HOSTS:
        try:
            c = MongoClient(f"mongodb://{host}/?directConnection=true", serverSelectionTimeoutMS=1500)
            h = c.admin.command("isMaster")
            out[host] = "PRIMARY" if h.get("ismaster") else "SECONDARY"
            c.close()
        except PyMongoError:
            out[host] = "DOWN"
    return out


def new_primary_now(exclude: str):
    for host in HOSTS:
        if host == exclude:
            continue
        try:
            c = MongoClient(f"mongodb://{host}/?directConnection=true",
                            serverSelectionTimeoutMS=800)
            h = c.admin.command("isMaster")
            c.close()
            if h.get("ismaster"):
                return host
        except PyMongoError:
            pass
    return None


def main():
    pids = json.loads((ROOT / "conf" / "run" / "pids.json").read_text())
    print("① 演练前角色：", roles())

    client = MongoClient(URL, serverSelectionTimeoutMS=3000, w="majority")
    coll = client["smartlib"]["failover_test"]
    coll.delete_many({})
    coll.insert_one({"stage": "before", "ts": time.time()})
    print(f"② 写入一条测试文档成功（writeConcern=majority），当前文档数 "
          f"{coll.count_documents({})}")

    before = roles()
    primary = [h for h, r in before.items() if r == "PRIMARY"][0]
    port = int(primary.split(":")[1])
    pid_key = {27018: "rs1", 27019: "rs2", 27020: "rs3"}[port]
    pid = pids[pid_key]
    print(f"③ 手动停止主节点 {primary}（SIGKILL，pid={pid}），模拟进程崩溃")
    t_kill = time.perf_counter()
    os.kill(pid, signal.SIGKILL)
    kill_at = time.strftime("%H:%M:%S")
    print(f"   故障时刻 {kill_at}，立即开始压读请求（每 0.3 s 一次，共 30 次），"
          f"期间观察新主节点产生")

    fails, ok, elect_ms, new_primary = 0, 0, None, None
    for i in range(30):
        try:
            MongoClient(URL, serverSelectionTimeoutMS=1000)["smartlib"]["readers"] \
                .count_documents({})
            ok += 1
        except PyMongoError:
            fails += 1
        if new_primary is None:
            new_primary = new_primary_now(exclude=primary)
            if new_primary:
                elect_ms = (time.perf_counter() - t_kill) * 1000
        time.sleep(0.3)
    print(f"   新主节点 {new_primary} 产生，距故障 {elect_ms/1000:.1f} s；"
          f"故障窗口内 30 次读：成功 {ok} 次，失败 {fails} 次")
    print("④ 演练后角色：", roles())

    client2 = MongoClient(URL, serverSelectionTimeoutMS=4000, w="majority")
    try:
        client2["smartlib"]["failover_test"].insert_one({"stage": "after", "ts": time.time()})
        print("⑤ 新主节点已可写入，故障前数据仍可读：",
              client2["smartlib"]["failover_test"].count_documents({}), "条")
    except PyMongoError as exc:
        print("⑤ 写入仍失败：", exc)

    # 重启原主节点：直接复用 launch.py，保持端口/数据目录/pid 文件一致
    print(f"⑥ 重启原主节点 {primary} ...")
    os.system(f"python3 {ROOT}/conf/launch.py start rs > /dev/null 2>&1")
    time.sleep(1)
    for _ in range(40):
        r = roles()
        if r[primary] == "SECONDARY":
            print(f"   原主节点 {primary} 已以 SECONDARY 角色重新加入副本集")
            break
        time.sleep(0.5)
    print("⑦ 最终角色：", roles())
    client.close()


if __name__ == "__main__":
    main()
