"""电子书与封面文件存储模块（GridFS）。

- 文件二进制入 GridFS（默认 fs.chunks / fs.files 分桶 ebook_fs，避免与其他业务冲突）；
- 元数据（ISBN、文件类型、原始文件名、上传人、上传时间）写入 GridFS 文件文档的 metadata；
- 下载后按字节数与 SHA-256 双向校验，防止"看起来成功、实际截断"。
"""
import hashlib
from datetime import datetime, timezone
from pathlib import Path

import config
import db
import audit


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def upload_file(path, isbn: str, file_type: str = "ebook", replace: bool = True) -> dict:
    """上传单个文件：先按 (isbn, file_type) 清理旧版本，再写入并回读校验大小。"""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    fs = db.get_fs()
    if replace:
        for old in fs.find({"metadata.isbn": isbn, "metadata.file_type": file_type}):
            fs.delete(old._id)
    with open(path, "rb") as fh:
        file_id = fs.put(
            fh,
            filename=path.name,
            metadata={
                "isbn": isbn,
                "file_type": file_type,
                "original_name": path.name,
                "uploader": "app_user",
                "uploaded_at": datetime.now(timezone.utc).replace(tzinfo=None),
                "sha256": _sha256(path),
            },
        )
    stored = fs.get(file_id)
    audit.record("上传电子书" if file_type == "ebook" else "上传封面", path.name,
                 {"isbn": isbn, "bytes": stored.length, "file_id": str(file_id)})
    return {
        "file_id": str(file_id),
        "filename": path.name,
        "isbn": isbn,
        "bytes": stored.length,
        "local_bytes": path.stat().st_size,
        "sha256": stored.metadata.get("sha256"),
    }


def list_files(file_type: str = None) -> list:
    fs = db.get_fs()
    query = {} if not file_type else {"metadata.file_type": file_type}
    rows = []
    for f in fs.find(query).sort("uploadDate", -1):
        rows.append({
            "filename": f.filename,
            "bytes": f.length,
            "uploadDate": f.uploadDate,
            "isbn": (f.metadata or {}).get("isbn", "-"),
            "file_type": (f.metadata or {}).get("file_type", "-"),
            "chunk_size": f.chunk_size,
            "md5": f.md5,
        })
    return rows


def find_by_title(title: str) -> list:
    """按书名查询电子书：先匹配 books，再用 isbn 到 GridFS 找文件。"""
    import book_service
    books, _ = book_service.search_title_like(title)
    result = []
    fs = db.get_fs()
    for b in books:
        for f in fs.find({"metadata.isbn": b["isbn"], "metadata.file_type": "ebook"}):
            result.append({"title": b["title"], "isbn": b["isbn"], "filename": f.filename,
                           "bytes": f.length, "file_id": str(f._id)})
    return result


def download_by_isbn(isbn: str, dest_dir=None, expect_bytes: int = None) -> dict:
    """按 ISBN 下载电子书到本地，并做字节数 + SHA-256 校验。"""
    fs = db.get_fs()
    f = fs.find_one({"metadata.isbn": isbn, "metadata.file_type": "ebook"})
    if not f:
        return {"ok": False, "reason": f"ISBN {isbn} 无电子书"}
    dest_dir = Path(dest_dir or config.DOWNLOAD_DIR)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f.filename
    with open(dest, "wb") as fh:
        fh.write(f.read())
    got = dest.stat().st_size
    got_sha = _sha256(dest)
    meta_sha = (f.metadata or {}).get("sha256")
    expect = expect_bytes if expect_bytes is not None else f.length
    ok = (got == expect) and (got == f.length) and (meta_sha in (None, got_sha))
    audit.record("下载电子书", f.filename,
                 {"isbn": isbn, "bytes": got, "verify": "ok" if ok else "failed"})
    return {
        "ok": ok, "path": str(dest), "filename": f.filename,
        "gridfs_bytes": f.length, "local_bytes": got, "sha256_match": meta_sha == got_sha,
        "sha256": got_sha,
    }


def delete_file(filename: str) -> bool:
    fs = db.get_fs()
    f = fs.find_one({"filename": filename})
    if not f:
        return False
    fs.delete(f._id)
    audit.record("删除文件", filename, {})
    return True
