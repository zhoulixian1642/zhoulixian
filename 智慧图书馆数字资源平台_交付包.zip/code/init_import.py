"""数据导入与建库脚本：建集合 -> 导入三份数据 -> 建索引 -> 三方核对。

用法：
    python3 init_import.py            # 导入（可重复执行，--reset 先清空）
    python3 init_import.py --reset
"""
import json
import sys

import config
import db
import schema
from util import to_date, print_table

DATE_FIELDS = {
    config.COL_BOOKS: ["publish_date"],
    config.COL_READERS: ["register_date"],
    config.COL_BORROW: ["borrow_date", "return_date"],
}


def load(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def prepare(docs, coll):
    out = []
    for d in docs:
        d = dict(d)
        for field in DATE_FIELDS.get(coll, []):
            if field in d:
                d[field] = to_date(d[field])
        out.append(d)
    return out


def main(reset: bool = False):
    config.ensure_dirs()
    database = db.get_db()
    print(f"连接目标：{config.describe()}")

    if reset:
        for coll in (config.COL_BOOKS, config.COL_READERS, config.COL_BORROW, config.COL_AUDIT):
            database[coll].drop()
        for coll in database.list_collection_names():
            if coll.endswith(".files") or coll.endswith(".chunks"):
                database[coll].drop()
        print("已清空原有业务集合与 GridFS 桶")

    created = schema.ensure_collections(database)
    print(f"新建集合：{created if created else '（已存在，跳过）'}")

    sources = {
        config.COL_BOOKS: config.BOOKS_FILE,
        config.COL_READERS: config.READERS_FILE,
        config.COL_BORROW: config.BORROW_FILE,
    }
    check_rows = []
    for coll, path in sources.items():
        docs = prepare(load(path), coll)
        if reset or database[coll].count_documents({}) == 0:
            if docs:
                database[coll].insert_many(docs, ordered=False)
            action = "insert_many"
        else:
            # 幂等导入：清空后重导，避免重复计数
            database[coll].delete_many({})
            if docs:
                database[coll].insert_many(docs, ordered=False)
            action = "delete_many + insert_many"
        src_count = len(docs)
        db_count = database[coll].count_documents({})
        check_rows.append((coll, src_count, db_count, "一致" if src_count == db_count else "不一致",
                           action, path.name))

    print("\n建立索引：")
    schema.ensure_indexes(database)

    total_docs = sum(r[1] for r in check_rows)
    total_db = sum(r[2] for r in check_rows)
    print_table(check_rows, ["集合", "源文件条数", "库内条数", "核对", "写入方式", "源文件"],
                widths=[13, 11, 9, 6, 26, 20], title="\n导入结果与条数核对")
    print(f"合计：源文件 {total_docs} 条 / 库内 {total_db} 条 -> "
          f"{'全部一致 ✔' if total_docs == total_db else '存在差异 ✘'}")

    # 索引清单回读，作为 T2 索引设计的落地证据
    idx_rows = []
    for coll in (config.COL_BOOKS, config.COL_READERS, config.COL_BORROW, config.COL_AUDIT):
        for name, spec in database[coll].index_information().items():
            if name == "_id_":
                continue
            keys = ",".join(f"{k}:{v}" for k, v in spec["key"])
            idx_rows.append((coll, name, keys, "是" if spec.get("unique") else "否"))
    print_table(idx_rows, ["集合", "索引名", "键", "唯一"], widths=[13, 24, 34, 6],
                title="已建索引清单")
    db.close()


if __name__ == "__main__":
    main(reset="--reset" in sys.argv)
