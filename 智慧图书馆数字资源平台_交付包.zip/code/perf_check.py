"""索引优化前后对比脚本。

做法：对同一查询，先在无索引状态跑 explain + 200 次计时，再建索引跑一遍，
记录「扫描方式 / 检查文档数 / 检查索引键数 / explain 耗时 / 平均查询耗时」。
"""
import statistics
import time

import config
import db

ITER = 200

CASES = [
    {
        "name": "Q1 图书：类别+价格区间",
        "coll": config.COL_BOOKS,
        "query": {"category": "计算机", "price": {"$gte": 50, "$lte": 100}},
        "sort": None,
        "index": [("category", 1), ("price", 1)],
        "index_name": "idx_category_price",
    },
    {
        "name": "Q2 流水：出版/借阅日期区间",
        "coll": config.COL_BORROW,
        "query": {"borrow_date": {"$gte": __import__("datetime").datetime(2024, 1, 1),
                                   "$lt": __import__("datetime").datetime(2024, 7, 1)}},
        "sort": None,
        "index": [("borrow_date", 1), ("status", 1)],
        "index_name": "idx_date_status",
    },
    {
        "name": "Q3 流水：某本书的借阅记录倒序",
        "coll": config.COL_BORROW,
        "query": {"book_isbn": "9787115428028"},
        "sort": [("borrow_date", -1)],
        "index": [("book_isbn", 1), ("borrow_date", -1)],
        "index_name": "idx_book_date",
    },
    {
        "name": "Q4 流水：逾期记录按时长倒序",
        "coll": config.COL_BORROW,
        "query": {"status": "逾期"},
        "sort": [("duration_days", -1)],
        "index": [("status", 1), ("duration_days", -1)],
        "index_name": "idx_status_duration",
    },
]


def explain_stats(coll, query, sort, natural=False):
    cur = coll.find(query)
    if natural:
        cur = cur.hint([("$natural", 1)])   # 强制全表扫描，作为"无索引"基线
    if sort:
        cur = cur.sort(sort)
    plan = cur.explain().get("executionStats", {})
    node = plan.get("executionStages", {})
    # 逐层下钻到真正取数的叶子阶段（COLLSCAN / IXSCAN），避免只看到外层 FETCH/SORT
    while node.get("inputStage"):
        if node.get("stage") in ("COLLSCAN", "IXSCAN"):
            break
        node = node["inputStage"]
    stage = node.get("stage", "?")
    return {
        "stage": stage,
        "docs": plan.get("totalDocsExamined", 0),
        "keys": plan.get("totalKeysExamined", 0),
        "ms": plan.get("executionTimeMillis", 0),
    }


def timed(coll, query, sort, iters=ITER, natural=False):
    samples = []

    def once():
        cur = coll.find(query)
        if natural:
            cur = cur.hint([("$natural", 1)])
        if sort:
            cur = cur.sort(sort)
        return list(cur.limit(50))

    for _ in range(5):  # 预热
        once()
    for _ in range(iters):
        t0 = time.perf_counter()
        once()
        samples.append((time.perf_counter() - t0) * 1000)
    return statistics.median(samples), sum(samples) / len(samples)


def run():
    database = db.get_db()
    rows = []
    for case in CASES:
        coll = database[case["coll"]]
        # 无索引：确保目标索引不存在
        if case["index_name"] in coll.index_information():
            coll.drop_index(case["index_name"])
        before = explain_stats(coll, case["query"], case["sort"], natural=True)
        med_b, avg_b = timed(coll, case["query"], case["sort"], natural=True)
        # 有索引
        coll.create_index(case["index"], name=case["index_name"])
        after = explain_stats(coll, case["query"], case["sort"])
        med_c, avg_c = timed(coll, case["query"], case["sort"])
        rows.append((case["name"], "无索引", before["stage"], before["docs"], before["keys"],
                     f"{before['ms']} ms", f"{med_b:.3f} ms"))
        rows.append(("", "有索引", after["stage"], after["docs"], after["keys"],
                     f"{after['ms']} ms", f"{med_c:.3f} ms"))
        speedup = (med_b / med_c) if med_c else 0
        print(f"{case['name']}: 扫描文档 {before['docs']} -> {after['docs']}，"
              f"中位耗时 {med_b:.3f} -> {med_c:.3f} ms（提速 {speedup:.1f}x）")

    from util import print_table
    print_table(rows, ["查询用例", "索引状态", "扫描方式", "检查文档", "检查索引键",
                       "explain 耗时", f"程序平均耗时({ITER}次中位)"],
                widths=[26, 8, 18, 9, 11, 11, 22],
                title="\n表索引优化前后执行计划与耗时对比")
    db.close()


if __name__ == "__main__":
    run()
