"""单次读取探针：用应用自己的连接模块跑一次查询，用于验证读偏好是否作用到业务程序。"""
import sys

import config
import db
from util import print_table

if __name__ == "__main__":
    info = db.server_identity()
    counts = db.collection_counts()
    books, n = __import__("book_service").top_rated(3)
    print(f"连接：{info['uri']}")
    print(f"拓扑：{info['topology']}  主节点：{info['primary']}  读偏好：{info['readPreference']}")
    print(f"集合条数：{counts}")
    print_table([(b['title'], b['rating']) for b in books], ["书名", "评分"], widths=[36, 6],
                title=f"评分榜前 3（本次读取由 readPreference={config.READ_PREFERENCE} 选出的节点服务）")
