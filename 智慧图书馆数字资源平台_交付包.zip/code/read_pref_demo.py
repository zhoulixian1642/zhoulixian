"""读偏好与从节点读取验证。

步骤：
1) 在副本集上写一条测试文档，确认数据落在主节点并复制到从节点；
2) 用 collection 级 SECONDARY 读偏好从从节点读回这条数据（证明从节点可读、且复制已生效）；
3) 把两个从节点临时改为 hidden（仍参与投票，但不再对客户端可见、不可读），
   这时 secondary 读偏好必须报"无可用节点"，而 secondaryPreferred 会回落到主节点 ——
   以此证明读偏好确实参与了选节点，而不是"碰巧连上了主节点"；
4) 还原配置，确认三节点角色恢复。
"""
import time

from pymongo import MongoClient, ReadPreference
from pymongo.errors import PyMongoError

import config
import db
from util import print_table

HOSTS = "127.0.0.1:27018,127.0.0.1:27019,127.0.0.1:27020"
URL = f"mongodb://{HOSTS}/?replicaSet=rs0"


def roles(client=None) -> dict:
    client = client or MongoClient(URL, serverSelectionTimeoutMS=3000)
    st = client.admin.command("replSetGetStatus")
    return {m["name"]: m["stateStr"] for m in st["members"]}


def try_read(mode: str):
    client = MongoClient(URL, serverSelectionTimeoutMS=2500)
    coll = client["smartlib"].get_collection("readers").with_options(
        read_preference=getattr(ReadPreference, mode))
    try:
        rows = list(coll.find({"card_no": "R20240001"}, {"_id": 0, "card_no": 1, "name": 1}))
        return f"成功：读到 {len(rows)} 条 {rows[0]['name'] if rows else ''}"
    except PyMongoError as exc:
        return f"失败：{type(exc).__name__} {str(exc).split(',')[0][:70]}"
    finally:
        client.close()


PRIORITY = {0: 2, 1: 1, 2: 1}   # 初始配置里 rs1 优先级最高，便于固定首选主节点


def set_hidden(hidden: bool, primary_name: str = None):
    """只对「非主节点」的成员设置 hidden：hidden 成员不能当主节点，动了主节点会导致无主。"""
    client = MongoClient(URL, serverSelectionTimeoutMS=3000)
    conf = client.admin.command("replSetGetConfig")["config"]
    for m in conf["members"]:
        if primary_name and m.get("host", m.get("name")) == primary_name:
            m["hidden"] = False
            m["priority"] = PRIORITY[m["_id"]]
            continue
        m["hidden"] = hidden
        m["priority"] = 0 if hidden else PRIORITY[m["_id"]]
    conf["version"] = conf["version"] + 1
    client.admin.command("replSetReconfig", conf, force=True)
    client.close()


def main():
    print("① 当前角色：", roles())
    client = MongoClient(URL, serverSelectionTimeoutMS=3000, w="majority")
    coll = client["smartlib"]["repl_probe"]
    coll.delete_many({})
    coll.insert_one({"probe": "read-preference", "ts": time.time()})
    print(f"② 主节点写入 1 条测试文档成功，当前 {coll.count_documents({})} 条（writeConcern=majority）")
    time.sleep(1.5)

    rows = [
        ("PRIMARY（默认）", try_read("PRIMARY")),
        ("SECONDARY（只读从节点）", try_read("SECONDARY")),
        ("SECONDARY_PREFERRED", try_read("SECONDARY_PREFERRED")),
    ]
    print_table(rows, ["读偏好", "读取结果"], widths=[24, 58], title="③ 三节点正常时的读取")

    current = roles()
    primary_name = [h for h, r in current.items() if r == "PRIMARY"][0]
    print(f"④ 将两个从节点（{', '.join(h for h in current if h != primary_name)}）"
          f"临时设为 hidden（priority=0，对客户端不可见、不可读），模拟“没有可读从节点”")
    set_hidden(True, primary_name)
    time.sleep(3)
    print("   此时角色：", roles())
    rows2 = [
        ("PRIMARY", try_read("PRIMARY")),
        ("SECONDARY", try_read("SECONDARY")),
        ("SECONDARY_PREFERRED", try_read("SECONDARY_PREFERRED")),
    ]
    print_table(rows2, ["读偏好", "读取结果"], widths=[24, 58],
                title="⑤ 两个从节点 hidden 时的读取（对比两种偏好的差异）")

    print("⑥ 还原从节点配置（hidden=false，优先级回到初始值）")
    set_hidden(False, primary_name)
    time.sleep(4)
    print("   角色恢复为：", roles())
    client.close()
    db.close()


if __name__ == "__main__":
    main()
