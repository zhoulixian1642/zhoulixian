"""读者业务模块：检索、分页、借阅资格与偏好分析。"""
import config
import db
import audit
from util import to_date


def _coll():
    return db.get_db()[config.COL_READERS]


def search(keyword: str = "", college: str = "", level: str = "", limit: int = 0):
    query = {}
    if keyword:
        query["$or"] = [
            {"name": {"$regex": keyword}},
            {"card_no": {"$regex": keyword}},
        ]
    if college:
        query["college"] = college
    if level:
        query["level"] = level
    cur = _coll().find(query, {"_id": 0}).sort("card_no", 1)
    if limit:
        cur = cur.limit(limit)
    rows = list(cur)
    return rows, len(rows)


def get_by_card(card_no: str) -> dict:
    return _coll().find_one({"card_no": card_no}, {"_id": 0})


def add_reader(doc: dict) -> dict:
    doc = dict(doc)
    if doc.get("register_date"):
        doc["register_date"] = to_date(doc["register_date"])
    _coll().insert_one(doc)
    audit.record("新增读者", doc.get("card_no"), {"name": doc.get("name")})
    return doc


def delete_reader(card_no: str) -> int:
    res = _coll().delete_one({"card_no": card_no})
    audit.record("删除读者", card_no, {})
    return res.deleted_count


def active_borrow_count(card_no: str) -> int:
    """在借数量：用于借阅上限判断（教师 10 本、高级 8 本、普通 5 本）。"""
    return db.get_db()[config.COL_BORROW].count_documents({"reader_card": card_no, "status": "借出"})


def borrow_limit(card_no: str) -> int:
    reader = get_by_card(card_no) or {}
    return {"教师": 10, "高级": 8}.get(reader.get("level"), 5)


def missing_fav_categories() -> int:
    """数据质量：缺少 fav_categories 的读者数（字段不齐的核查口径）。"""
    return _coll().count_documents({"fav_categories": {"$exists": False}})


def favourite_category_report():
    """按偏好类别展开统计读者人数（数组字段 unwind）。"""
    pipeline = [
        {"$unwind": "$fav_categories"},
        {"$group": {"_id": "$fav_categories", "readers": {"$sum": 1}}},
        {"$sort": {"readers": -1, "_id": 1}},
    ]
    return list(_coll().aggregate(pipeline))
