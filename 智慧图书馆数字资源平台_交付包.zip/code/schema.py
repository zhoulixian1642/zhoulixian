"""数据模型定义：集合清单、字段类型表、索引清单、集合选项。

T2「数据建模」的落地实现：字段类型、嵌套与拆分的决策全部在这里被固化为代码，
导入脚本与业务程序共用同一份定义，避免"文档写一套、代码建另一套"。
"""
import config

# 字段类型表（业务语义 -> BSON 类型），供文档与程序共用
SCHEMA = {
    config.COL_BOOKS: [
        ("isbn", "String", "ISBN-13，唯一标识"),
        ("title", "String", "书名"),
        ("author", "String", "作者"),
        ("publisher", "String", "出版社"),
        ("category", "String", "类别，共 6 类"),
        ("price", "Double", "定价（元）"),
        ("rating", "Double", "读者评分 0~5"),
        ("stock", "Int", "在架库存"),
        ("tags", "Array<String>", "标签，部分图书无此字段"),
        ("publish_date", "Date", "出版日期（UTC 存储）"),
        ("borrow_count", "Int", "历史累计借阅次数"),
        ("location", "Object{floor,shelf,copies}", "嵌套文档：楼层区域/架位号/复本数"),
        ("ebook_name", "String", "关联电子书文件名，仅部分图书有"),
    ],
    config.COL_READERS: [
        ("card_no", "String", "借阅证号，唯一标识"),
        ("name", "String", "姓名"),
        ("college", "String", "所属学院"),
        ("email", "String/null", "邮箱，部分为空"),
        ("phone", "String", "联系电话"),
        ("level", "String", "普通 / 高级 / 教师"),
        ("register_date", "Date", "注册时间"),
        ("fav_categories", "Array<String>", "偏好类别，部分读者无此字段"),
    ],
    config.COL_BORROW: [
        ("borrow_date", "Date", "借阅时间"),
        ("return_date", "Date", "归还时间，未归还时无此字段"),
        ("reader_card", "String", "借阅证号，逻辑关联 readers.card_no"),
        ("book_isbn", "String", "图书 ISBN，逻辑关联 books.isbn"),
        ("status", "String", "已归还 / 借出 / 逾期"),
        ("duration_days", "Int", "借阅时长（天）"),
    ],
    config.COL_AUDIT: [
        ("ts", "Date", "操作时间（UTC）"),
        ("operator", "String", "操作账号（应用登录名）"),
        ("action", "String", "动作：新增图书/删除图书/导出统计/上传电子书/下载电子书"),
        ("target", "String", "操作对象，如 ISBN 或文件名"),
        ("detail", "Object", "附加信息（前后值、耗时等）"),
        ("result", "String", "ok / failed"),
    ],
}

# 集合选项：borrow_logs 走时间序列（写多读多、按时间聚合），audit_logs 走普通集合+TTL 思维（保留策略留空）
COLLECTION_OPTIONS = {
    config.COL_BOOKS: {},
    config.COL_READERS: {},
    config.COL_BORROW: {},       # 分片集群中该集合需建 shard key（见 conf/shard 脚本）
    config.COL_AUDIT: {},
    config.COL_CATEGORY_STATS: {},
}

# 索引清单（字段, 类型, 用途）
INDEXES = {
    config.COL_BOOKS: [
        ({"isbn": 1}, {"unique": True, "name": "uk_isbn"}),
        ({"category": 1, "price": 1}, {"name": "idx_category_price"}),
        ({"tags": 1}, {"name": "idx_tags"}),
        ({"rating": -1}, {"name": "idx_rating_desc"}),
        ({"publish_date": 1}, {"name": "idx_publish_date"}),
        ({"borrow_count": -1}, {"name": "idx_borrow_count"}),
    ],
    config.COL_READERS: [
        ({"card_no": 1}, {"unique": True, "name": "uk_card_no"}),
        ({"college": 1, "level": 1}, {"name": "idx_college_level"}),
        ({"register_date": 1}, {"name": "idx_register_date"}),
    ],
    config.COL_BORROW: [
        ({"reader_card": 1, "borrow_date": -1}, {"name": "idx_reader_date"}),
        ({"book_isbn": 1, "borrow_date": -1}, {"name": "idx_book_date"}),
        ({"borrow_date": 1, "status": 1}, {"name": "idx_date_status"}),
        ({"status": 1, "duration_days": -1}, {"name": "idx_status_duration"}),
    ],
    config.COL_AUDIT: [
        ({"ts": -1}, {"name": "idx_ts_desc"}),
        ({"action": 1, "ts": -1}, {"name": "idx_action_ts"}),
    ],
    config.COL_CATEGORY_STATS: [],
}


def ensure_collections(db) -> list:
    existing = set(db.list_collection_names())
    created = []
    for name, opts in COLLECTION_OPTIONS.items():
        if name not in existing:
            db.create_collection(name, **opts)
            created.append(name)
    return created


def ensure_indexes(db, verbose: bool = True) -> list:
    result = []
    for coll, idx_list in INDEXES.items():
        for keys, opts in idx_list:
            name = db[coll].create_index(list(keys.items()), **opts)
            result.append((coll, name, keys, opts.get("unique", False)))
            if verbose:
                uniq = " UNIQUE" if opts.get("unique") else ""
                key_txt = ",".join(f"{k}:{v}" for k, v in keys.items())
                print(f"  [index] {coll:13s} {name:22s} ({key_txt}){uniq}")
    return result
