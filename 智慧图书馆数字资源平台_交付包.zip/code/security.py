"""账号与权限脚本：创建应用库的三个角色账号并验证越权被拒。

角色划分（最小权限原则）：
- lib_readonly  只读：仅 find/aggregate，任何写操作在服务端被拒；
- lib_readwrite 读写：业务增删改，但无权建索引/建集合；
- lib_admin     管理：库级 dbOwner，可建索引与维护。
"""
import sys

from urllib.parse import quote_plus

import config
import db

USERS = [
    {
        "user": "lib_readonly",
        "pwd": "Read@123456",
        "roles": [{"role": "read", "db": config.MONGO_DB}],
        "desc": "只读账号（前台检索）",
    },
    {
        "user": "lib_readwrite",
        "pwd": "Write@123456",
        "roles": [{"role": "readWrite", "db": config.MONGO_DB}],
        "desc": "读写账号（业务程序）",
    },
    {
        "user": "lib_admin",
        "pwd": "Admin@123456",
        "roles": [{"role": "dbOwner", "db": config.MONGO_DB}],
        "desc": "管理账号（运维建索引）",
    },
]


def create_users():
    database = db.get_db()
    for u in USERS:
        try:
            database.command("dropUser", u["user"])
        except Exception:
            pass
        database.command("createUser", u["user"], pwd=u["pwd"], roles=u["roles"])
        print(f"创建账号 {u['user']:14s} {u['desc']}  角色={u['roles']}")


def verify():
    """用只读/读写账号各连一次，验证只读账号写操作被拒（服务端报 Unauthorized）。"""
    from pymongo import MongoClient
    from pymongo.errors import OperationFailure

    results = []
    for u in USERS:
        quoted_pwd = quote_plus(u["pwd"])   # 密码含 @ 等字符必须转义，否则 URI 解析失败
        uri = (f"mongodb://{u['user']}:{quoted_pwd}@{config.MONGO_HOST}:{config.MONGO_PORT}"
               f"/{config.MONGO_DB}?authSource={config.MONGO_DB}")
        client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        try:
            coll = client[config.MONGO_DB][config.COL_BOOKS]
            readable = coll.count_documents({})
            try:
                coll.update_one({"isbn": "9787115428028"}, {"$set": {"stock": 15}})
                write = "写入成功"
            except OperationFailure as exc:
                write = f"写入被拒（code={exc.code}）"
            results.append((u["user"], u["roles"][0]["role"], readable, write))
        finally:
            client.close()
    from util import print_table
    print_table(results, ["账号", "角色", "可读图书数", "写操作结果"], widths=[14, 10, 10, 28],
                title="权限验证：三个账号的实际行为")
    return results


if __name__ == "__main__":
    config.ensure_dirs()
    if "--create-only" in sys.argv:
        create_users()
    elif "--verify-only" in sys.argv:
        verify()
    else:
        create_users()
        verify()
    db.close()
