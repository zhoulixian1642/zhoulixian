"""分片集群查询对比：定向查询（命中分片键）vs 跨分片查询（不命中分片键）。

通过 mongos 的 explain 输出判断有多少分片参与，再各跑 100 次计时。
"""
import statistics
import time

import db
from util import print_table

CASES = [
    ("定向：按 ISBN 查某本书的借阅记录", {"book_isbn": "9787115428028"}),
    ("定向：按 ISBN + 时间范围", {"book_isbn": "9787115428028",
                              "borrow_date": {"$gte": __import__("datetime").datetime(2024, 1, 1)}}),
    ("跨片：按状态筛逾期记录", {"status": "逾期"}),
    ("跨片：按读者证号查借阅历史", {"reader_card": "R20240001"}),
    ("跨片：按年月统计借阅量", {"borrow_date": {"$gte": __import__("datetime").datetime(2025, 1, 1)}}),
]


def shards_involved(coll_name: str, query: dict):
    client = db.get_client()
    res = client[db.config.MONGO_DB].command(
        {"explain": {"find": coll_name, "filter": query}, "verbosity": "queryPlanner"})
    plan = res.get("queryPlanner", {}).get("winningPlan", {})
    if "shards" in res:          # mongos 侧 explain 会给出参与的分片
        return len(res["shards"]), [s["shardName"] for s in res["shards"]]
    if "shards" in plan:
        return len(plan["shards"]), [s["shardName"] for s in plan["shards"]]
    # 单分片命中时 mongos 可能直接返回单分片计划
    return 1, [plan.get("shardName", "单分片")]


def measure(query: dict, iters: int = 100):
    coll = db.get_collection("borrow_logs")
    samples = []
    for _ in range(5):
        list(coll.find(query).limit(100))
    for _ in range(iters):
        t0 = time.perf_counter()
        list(coll.find(query).limit(100))
        samples.append((time.perf_counter() - t0) * 1000)
    return statistics.median(samples), len(list(coll.find(query).limit(100)))


if __name__ == "__main__":
    rows = []
    for name, q in CASES:
        n_shards, shard_names = shards_involved("borrow_logs", q)
        med, cnt = measure(q)
        rows.append((name, n_shards, ",".join(shard_names), cnt, f"{med:.2f} ms"))
    print_table(rows, ["查询", "参与分片数", "分片", "返回条数(limit 100)", "100 次中位耗时"],
                widths=[32, 10, 18, 17, 14],
                title="跨分片查询与定向查询对比（经 mongos 执行）")
    db.close()
