"""通用工具：日期解析、中文等宽表格输出、金额/时间格式化。"""
import unicodedata
from datetime import datetime, timedelta, timezone
from typing import Iterable, Sequence


def to_date(value):
    """把 ISO 8601 字符串转成 naive UTC datetime（MongoDB Date 类型）。

    源数据带 +08:00 时区，MongoDB 内部按 UTC 存储，这里统一转 UTC 且去掉 tzinfo，
    避免不同机器时区导致查询边界漂移。
    """
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        text = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(text)
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


CST_OFFSET = 8  # 源数据为 +08:00 时区，库里按 UTC 存储，展示时换回本地时间


def to_local(value):
    if isinstance(value, datetime):
        return value.replace(tzinfo=timezone.utc).astimezone(
            timezone(timedelta(hours=CST_OFFSET))).replace(tzinfo=None)
    return value


def fmt_date(value) -> str:
    if not value:
        return "-"
    if isinstance(value, datetime):
        return to_local(value).strftime("%Y-%m-%d %H:%M")
    return str(value)


def fmt_day(value) -> str:
    if not value:
        return "-"
    if isinstance(value, datetime):
        return to_local(value).strftime("%Y-%m-%d")
    return str(value)[:10]


def _width(text: str) -> int:
    return sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in text)


def _pad(text: str, width: int) -> str:
    text = str(text)
    gap = width - _width(text)
    return text + " " * max(gap, 0)


_table_width = 0
_cols: Sequence[tuple] = ()


def table(rows: Iterable[Sequence], headers: Sequence[str], max_rows: int = 20,
          widths: Sequence[int] = None, title: str = "") -> str:
    """按显示宽度对齐打印表格（中文按 2 列宽），返回文本，便于同时打印与落盘。"""
    rows = list(rows)
    if widths is None:
        widths = []
        for i, h in enumerate(headers):
            cells = [str(r[i]) if i < len(r) else "" for r in rows[:max_rows]]
            widths.append(max([_width(str(h))] + [_width(c) for c in cells]))
    lines = []
    if title:
        lines.append(title)
    lines.append(" | ".join(_pad(h, widths[i]) for i, h in enumerate(headers)))
    lines.append("-+-".join("-" * w for w in widths))
    for r in rows[:max_rows]:
        lines.append(" | ".join(_pad(r[i] if i < len(r) else "", widths[i]) for i in range(len(headers))))
    if len(rows) > max_rows:
        lines.append(f"... 共 {len(rows)} 行，仅显示前 {max_rows} 行")
    return "\n".join(lines)


def print_table(rows, headers, max_rows=20, widths=None, title=""):
    print(table(rows, headers, max_rows, widths, title))


def banner(text: str, char: str = "=") -> None:
    print("\n" + char * 72)
    print(text)
    print(char * 72)
