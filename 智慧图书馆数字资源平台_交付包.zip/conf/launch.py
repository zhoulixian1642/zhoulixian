"""本地多实例启动器：单机 / 三节点副本集 / 分片集群（config + 2 shard + mongos）。

用途：把「端口、数据目录、配置文件」集中管理，一条命令拉起或停止一组实例，
避免手工敲一长串 mongod 参数；配置模板里只有端口和数据目录不同。

用法：
    python3 conf/launch.py single start|stop|status
    python3 conf/launch.py rs     start|stop [--auth]
    python3 conf/launch.py shard  start|stop [--auth]
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent          # 项目根目录
CONF = Path(__file__).resolve().parent                 # conf/
RUN = CONF / "run"
RUN.mkdir(exist_ok=True)


def find_bin(name: str) -> str:
    candidates = []
    if os.environ.get("MONGODB_HOME"):
        candidates.append(Path(os.environ["MONGODB_HOME"]) / "bin" / name)
    for base in (ROOT / "tools", ROOT.parent / "tools"):
        candidates += sorted(base.glob(f"mongodb-*/bin/{name}"))
    for p in candidates:
        if p.exists():
            return str(p)
    found = shutil.which(name)
    if found:
        return found
    raise SystemExit(f"找不到 {name}，请设置环境变量 MONGODB_HOME 指向 MongoDB 安装目录")


def keyfile() -> str:
    path = RUN / "keyfile"
    if not path.exists():
        subprocess.run(["openssl", "rand", "-base64", "256"], stdout=open(path, "w"), check=True)
        os.chmod(path, 0o600)
    return str(path)


def security_block(auth: bool, group: str = "single", kind: str = "mongod") -> str:
    if not auth:
        return ""
    if group == "single":
        return "security:\n  authorization: enabled\n"
    if kind == "mongos":
        # mongos 只接受 keyFile，写 authorization 会被判为非法配置
        return f"security:\n  keyFile: {keyfile()}\n"
    return (f"security:\n  keyFile: {keyfile()}\n  authorization: enabled\n")


def render(template: str, values: dict, path: Path) -> str:
    text = (CONF / template).read_text(encoding="utf-8")
    for key, val in values.items():
        text = text.replace("{{%s}}" % key, str(val))
    path.write_text(text, encoding="utf-8")
    return str(path)


def nodes(group: str, auth: bool):
    db = ROOT / "db"
    if group == "single":
        return [dict(name="single", kind="mongod", port=27017,
                     dbpath=db / "single", template="mongod-standalone.conf", extra={})]
    if group == "rs":
        return [dict(name=f"rs{n}", kind="mongod", port=27017 + n,
                     dbpath=db / "rs" / f"n{n}", template="mongod-repl.conf",
                     extra={"REPLSET": "rs0"}) for n in (1, 2, 3)]
    if group == "rs4":
        return [dict(name="rs4", kind="mongod", port=27025, dbpath=db / "rs" / "n4",
                     template="mongod-repl.conf", extra={"REPLSET": "rs0"})]
    if group == "shard":
        return [
            dict(name="cfg", kind="mongod", port=27021, dbpath=db / "sh" / "cfg",
                 template="mongod-configsvr.conf", extra={"REPLSET": "rsConfig"}),
            dict(name="shard1", kind="mongod", port=27022, dbpath=db / "sh" / "shard1",
                 template="mongod-shard.conf", extra={"REPLSET": "rsShard1"}),
            dict(name="shard2", kind="mongod", port=27023, dbpath=db / "sh" / "shard2",
                 template="mongod-shard.conf", extra={"REPLSET": "rsShard2"}),
            dict(name="mongos", kind="mongos", port=27024, dbpath=None,
                 template="mongos.conf", extra={"CONFIGDB": "rsConfig/127.0.0.1:27021"}),
        ]
    raise SystemExit(f"未知实例组 {group}")


def port_open(port: int, timeout: float = 40.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket() as s:
            s.settimeout(0.5)
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.3)
    return False


PID_FILE = RUN / "pids.json"


def load_pids() -> dict:
    return json.loads(PID_FILE.read_text()) if PID_FILE.exists() else {}


def save_pids(data: dict) -> None:
    PID_FILE.write_text(json.dumps(data, indent=1))


def start(group: str, auth: bool):
    pids = load_pids()
    for node in nodes(group, auth):
        name = node["name"]
        if name in pids and Path(f"/proc/{pids[name]}").exists():
            print(f"{name} 已在运行 pid={pids[name]}")
            continue
        log = ROOT / "logs" / f"{name}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        values = {"PORT": node["port"], "LOG": log}
        values.update(node["extra"])
        if node["dbpath"]:
            node["dbpath"].mkdir(parents=True, exist_ok=True)
            values["DBPATH"] = node["dbpath"]
        values["SECURITY"] = security_block(auth, group, node["kind"])
        conf_path = RUN / f"{name}-{node['port']}.conf"
        render(node["template"], values, conf_path)
        binary = find_bin("mongod" if node["kind"] == "mongod" else "mongos")
        proc = subprocess.Popen([binary, "--config", str(conf_path)],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                start_new_session=True)
        pids[name] = proc.pid
        save_pids(pids)
        ok = port_open(node["port"])
        print(f"{name:8s} port={node['port']} pid={proc.pid} "
              f"{'启动成功' if ok else '启动超时，请查看 logs/' + name + '.log'}")


def stop(group: str):
    pids = load_pids()
    for node in nodes(group, False):
        pid = pids.pop(node["name"], None)
        if not pid:
            continue
        try:
            os.kill(pid, 15)
            for _ in range(120):
                if not Path(f"/proc/{pid}").exists():
                    break
                time.sleep(0.25)
            for _ in range(40):
                if not port_open(node["port"], 0.2):
                    break
                time.sleep(0.25)
            print(f"{node['name']:8s} 已停止 pid={pid}")
        except ProcessLookupError:
            print(f"{node['name']:8s} 进程已不存在")
    save_pids(pids)


def status(group: str):
    pids = load_pids()
    for node in nodes(group, False):
        pid = pids.get(node["name"])
        alive = bool(pid) and Path(f"/proc/{pid}").exists()
        print(f"{node['name']:8s} port={node['port']:5d} pid={pid} "
              f"{'运行中' if alive else '未运行'} 端口{'可连' if port_open(node['port'], 1) else '不可连'}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    cmd, grp = sys.argv[1], sys.argv[2]
    auth = "--auth" in sys.argv
    {"start": lambda: start(grp, auth), "stop": lambda: stop(grp), "status": lambda: status(grp)}[cmd]()
