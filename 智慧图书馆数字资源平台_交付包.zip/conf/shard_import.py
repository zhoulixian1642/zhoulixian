"""分片集群建库脚本：先建库导静态数据 -> 给 borrow_logs 建分片键 -> 再灌入 3000 条流水。

顺序很关键：先 shardCollection 再灌流水，3 000 条会按 ISBN 哈希直接路由到两个分片；
如果先灌再分片，全部数据会先落在一个分片上，必须等均衡器搬 chunk，验证时间不可控。
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "code"))

import config      # noqa: E402
import db          # noqa: E402
import schema      # noqa: E402
from init_import import load, prepare, DATE_FIELDS   # noqa: E402
from util import print_table, banner  # noqa: E402

SHARD_KEY = [("book_isbn", "hashed")]


def main():
    database = db.get_db()
    banner("① 建库并导入静态数据（books / readers）")
    schema.ensure_collections(database)
    for coll, path in ((config.COL_BOOKS, config.BOOKS_FILE),
                       (config.COL_READERS, config.READERS_FILE)):
        if database[coll].count_documents({}):
            database[coll].delete_many({})
        docs = prepare(load(path), coll)
        if docs:
            database[coll].insert_many(docs, ordered=False)
        print(f"  {coll}: {database[coll].count_documents({})} 条（源文件 {len(docs)} 条）")

    banner("② 开启数据库分片并指定 borrow_logs 的分片键")
    client = db.get_client()
    print("   enableSharding(smartlib):",
          client.admin.command({"enableSharding": config.MONGO_DB})["ok"])
    client.admin.command({"shardCollection": f"{config.MONGO_DB}.{config.COL_BORROW}",
                          "key": dict(SHARD_KEY)})
    print(f"   分片键: {dict(SHARD_KEY)}（hashed，均匀分布）")

    banner("③ 通过 mongos 灌入 3000 条借阅流水")
    if database[config.COL_BORROW].count_documents({}):
        database[config.COL_BORROW].delete_many({})
    docs = prepare(load(config.BORROW_FILE), config.COL_BORROW)
    inserted = 0
    for i in range(0, len(docs), 500):
        chunk = docs[i:i + 500]
        database[config.COL_BORROW].insert_many(chunk, ordered=False)
        inserted += len(chunk)
        print(f"   已写入 {inserted}/{len(docs)}")
    print(f"   库内条数：{database[config.COL_BORROW].count_documents({})}")

    banner("④ 建索引（分片集合上的索引会下发到每个分片）")
    schema.ensure_indexes(database, verbose=False)
    print("   索引数：", len([n for n in database[config.COL_BORROW].index_information()]))

    banner("⑤ 各分片文档分布")
    st = database.command("collStats", config.COL_BORROW)
    rows = []
    for shard, info in st["shards"].items():
        rows.append((shard, info["count"], f"{info['size']/1024:.1f} KB",
                     info.get("avgObjSize", 0)))
    print_table(rows, ["分片", "文档数", "数据大小", "平均对象大小"],
                widths=[12, 10, 12, 14])
    print(f"   合计 {sum(r[1] for r in rows)} 条，覆盖 {len(rows)} 个分片")
    db.close()


if __name__ == "__main__":
    main()
