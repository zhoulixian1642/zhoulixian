# -*- coding: utf-8 -*-
"""生成《智慧图书馆数字资源平台》项目文档（docx），随后转 PDF。"""
import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.enum.table import WD_TABLE_ALIGNMENT

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOTS = os.path.join(BASE, "screenshots")
OUT = os.path.join(BASE, "docs", "智慧图书馆数字资源平台_项目文档.docx")

doc = Document()

# ---------- 全局样式 ----------
st = doc.styles["Normal"]
st.font.name = "宋体"
st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
st.paragraph_format.line_spacing = 1.4
st.paragraph_format.space_after = Pt(3)

for sname in ("Heading 1", "Heading 2", "Heading 3"):
    s = doc.styles[sname]
    s.font.name = "黑体"
    s.element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
    s.font.color.rgb = RGBColor(0x12, 0x3B, 0x4A)
    s.font.bold = True
doc.styles["Heading 1"].font.size = Pt(16)
doc.styles["Heading 2"].font.size = Pt(12.5)

sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.left_margin = sec.right_margin = Cm(2.4)
sec.top_margin = sec.bottom_margin = Cm(2.2)


def h(text, level=1):
    p = doc.add_heading(text, level=level)
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    p.paragraph_format.space_after = Pt(4)
    return p


def para(text, indent=True, size=10.5, bold=False, align=None, space_after=3):
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74) if indent else Cm(0)
    p.paragraph_format.space_after = Pt(space_after)
    p.alignment = align or WD_ALIGN_PARAGRAPH.JUSTIFY
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.bold = bold
    return p


def bullet(text):
    p = doc.add_paragraph(text, style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    for r in p.runs:
        r.font.size = Pt(10.5)
    return p


def caption(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text)
    r.font.size = Pt(9)
    r.font.name = "黑体"
    r.element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")


def figure(fname, width=15.5, cap=None):
    path = os.path.join(SHOTS, fname)
    if not os.path.exists(path):
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(2)
    p.add_run().add_picture(path, width=Cm(width))
    if cap:
        caption(cap)


def shade(cell, color="D9E5EA"):
    tcPr = cell._tc.get_or_add_tcPr()
    sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear")
    sh.set(qn("w:color"), "auto")
    sh.set(qn("w:fill"), color)
    tcPr.append(sh)


def table(rows, widths=None, header=True, font=9, cap=None):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.line_spacing = 1.1
            r = p.add_run(str(val))
            r.font.size = Pt(font)
            r.font.name = "宋体"
            r.element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
            if i == 0 and header:
                r.bold = True
                shade(cell)
    if widths:
        for j, w in enumerate(widths):
            for row in t.rows:
                row.cells[j].width = Cm(w)
    if cap:
        caption(cap)
    return t


def add_page_number():
    footer = doc.sections[0].footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    run._r.addnext(fld)
    run.text = ""


# ================= 封面 =================
for _ in range(3):
    doc.add_paragraph()

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("智慧图书馆数字资源平台")
r.font.size = Pt(26)
r.font.name = "黑体"
r.element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
r.bold = True
r.font.color.rgb = RGBColor(0x12, 0x3B, 0x4A)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("《NoSQL 数据库技术与应用（第2版）》第 1—6 章综合实践")
r.font.size = Pt(13)
r.font.name = "楷体"
r.element.rPr.rFonts.set(qn("w:eastAsia"), "楷体")

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("项 目 文 档")
r.font.size = Pt(15)
r.bold = True

for _ in range(4):
    doc.add_paragraph()

info = [["项目名称", "智慧图书馆数字资源平台"],
        ["技术栈", "MongoDB 7.0.14 + Python 3.12 + pymongo 4.19 + GridFS"],
        ["部署形态", "单机 → 三节点副本集（rs0）→ 两分片分片集群"],
        ["组　　长", "尚佳琪　202414870230"],
        ["组　　员", "陈　菲　202414870227"],
        ["", "周丽娴　202414870222"],
        ["提交日期", "2026 年 11 月 10 日"]]
t = doc.add_table(rows=len(info), cols=2)
t.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, (k, v) in enumerate(info):
    for j, val in enumerate((k, v)):
        c = t.cell(i, j)
        c.text = ""
        pp = c.paragraphs[0]
        pp.alignment = WD_ALIGN_PARAGRAPH.CENTER if j == 1 else WD_ALIGN_PARAGRAPH.CENTER
        rr = pp.add_run(val)
        rr.font.size = Pt(11)
        if j == 0:
            rr.bold = True
    t.cell(i, 0).width = Cm(3.4)
    t.cell(i, 1).width = Cm(9)
doc.add_page_break()

# ================= 一、项目概述 =================
h("一、项目概述", 1)
h("1.1 业务背景", 2)
para("某高校图书馆现有纸质馆藏约 50 万册，近年陆续采购电子书。原系统基于关系型数据库，"
     "运行中暴露出三方面瓶颈：一是馆藏结构字段差异大，部分图书带标签（tags）、部分带电子书文件"
     "（ebook_name）、部分带嵌套的馆藏位置（location），关系表要么大量留空列，要么被迫拆成多张附表；"
     "二是借阅流水增长快，年均新增数十万条，单表按读者、按图书、按时间三个维度都要建索引，"
     "写放大严重；三是电子书 PDF 与封面图无处安放，只能放在文件服务器，与元数据分离，"
     "无法保证“书—文件”一致。图书馆决定迁移到 MongoDB，并建设统一的数字资源平台。")
para("本次实践按任务书要求，用配套教学数据完整走一遍“选型论证—数据建模—单机实现—应用开发—"
     "副本集部署—分片集群部署—验收交付”的全过程。三个小组按“数据与程序”“架构与运维”"
     "“文档与验收”三条线分工，每一项任务都保留可复核的过程记录。")

h("1.2 项目目标", 2)
para("平台需同时支撑四类业务：馆藏与读者信息管理（增删改查、条件检索、分页排序）、借阅统计分析"
     "（分类统计、排行、趋势、多集合联合）、电子书文件存取（GridFS）、以及高可用与水平扩展"
     "（三节点副本集、两分片分片集群）。功能清单对应任务书 F1—F11，本次全部实现并在文档中给出验证证据。")

h("1.3 数据基础", 2)
table([["文件", "内容", "规模", "用途"],
       ["books.txt", "馆藏图书（JSON 数组）", "50 条 / 6 个类别", "馆藏管理、检索、统计"],
       ["readers.txt", "读者信息（JSON 数组）", "30 条", "读者管理、联合分析"],
       ["borrow_logs.txt", "借阅流水（JSON 数组）", "3000 条 / 覆盖 2023—2025", "聚合统计、分片测试"],
       ["ebook_1~3.pdf", "电子书样例（各 6 页）", "37—40 KB", "GridFS 上传下载"],
       ["cover_1~3.png", "电子书封面图", "15—26 KB", "GridFS 图片存储"],
       ["files_manifest.txt", "文件清单与 ISBN 对应关系", "—", "书与文件的关联"]],
      widths=[3.2, 5.4, 4.2, 3.4], cap="表 1-1　配套数据文件")
para("说明：三份数据文件中“刻意不齐”的部分（4 本图书缺 tags 字段、2 位读者缺 fav_categories 字段、"
     "5 位读者 email 为空）是真实业务中常见的数据不齐情况，本项目在导入环节做了巡检并在模型中允许缺失，"
     "而不是用空字符串填充。")

h("1.4 分工与进度", 2)
table([["阶段（14 天）", "任务", "负责人", "阶段成果"],
       ["第 1—2 天", "技术选型论证", "尚佳琪", "选型论证章节、对比表"],
       ["第 3—4 天", "数据建模与结构设计", "尚佳琪", "集合结构、字段类型表、索引清单"],
       ["第 5—7 天", "单机部署与检索统计", "尚佳琪 / 陈菲", "数据库 + 11 项检索统计执行记录"],
       ["第 8—9 天", "应用开发与 GridFS", "尚佳琪", "8 个 Python 源文件、文件存取"],
       ["第 10—11 天", "副本集部署与故障转移", "陈菲", "三节点集群、转移过程记录"],
       ["第 12—13 天", "分片集群部署与验证", "陈菲", "分片集群、分片键论证、分布验证"],
       ["第 14 天", "验收、文档与答辩", "周丽娴 / 全员", "文档、截图、可视化验收记录"]],
      widths=[3.0, 4.6, 3.2, 5.4], cap="表 1-2　分工与阶段进度")

# ================= 二、技术选型 =================
h("二、技术选型论证", 1)
h("2.1 关系型数据库在本平台的三处困难", 2)
para("把本平台的数据硬塞进关系模型，会遇到三个具体困难，而不是笼统的“不灵活”。")
table([["困难点", "字段/业务事实", "关系模型的代价"],
       ["可变属性多", "50 本图书中 tags 有 4 本缺失、ebook_name 仅 3 本有、location 为嵌套结构",
        "要么建 tags/ebook/location 三张附表并大量 LEFT JOIN，要么在主表留大量 NULL 列"],
       ["借阅流水增长快", "3000 条/3 年，生产环境年均数十万；需按读者、图书、时间三向查询",
        "每个维度都要单独索引，写入时维护多棵 B+ 树，写放大明显"],
       ["文件与元数据分离", "3 个 PDF、3 张封面需与 ISBN 绑定",
        "BLOB 列撑大表空间、备份变慢；文件服务器方案又失去事务边界"]],
      widths=[3.2, 7.2, 6.0], cap="表 2-1　关系模型的困难点与代价")
para("更关键的是：本平台的查询以“整本书一次读出”为主（书名、作者、价格、标签、位置、电子书），"
     "而不是按单个字段做跨表精确匹配。关系模型擅长的是结构稳定、以 JOIN 为主的分析型场景；"
     "本平台的结构可变、以文档为读取单位，正好落在文档型数据库的强项区间。")

h("2.2 四类 NoSQL 数据库的对比", 2)
table([["类型", "数据模型", "典型适用场景", "本项目匹配度"],
       ["键值型（Redis 等）", "key → value，值对应用透明", "缓存、会话、计数器、排行榜",
        "低：查询条件复杂（标签、价格区间、年份），键值型需自行拼接索引"],
       ["文档型（MongoDB）", "BSON 文档，字段可嵌套、可数组", "结构多变的内容管理、目录、日志、IoT",
        "高：嵌套 location、数组 tags、聚合管道、GridFS 一体化"],
       ["列式（HBase/Cassandra）", "行键 + 列族，按列存储", "海量稀疏数据、时序、宽表",
        "低：50 万册规模用不上，且缺少灵活的二级索引与聚合"],
       ["图（Neo4j 等）", "节点 + 关系", "社交关系、知识图谱、路径分析",
        "低：馆藏与借阅是“一对多”引用，不涉及多跳路径"]],
      widths=[3.4, 4.2, 5.0, 5.6], cap="表 2-2　四类 NoSQL 数据库对比")
para("从对比可以看出，本项目的数据既有“一本书一个文档”的整体性，又有字段层面的可变性，"
     "还要求按标签、价格、日期做组合筛选与聚合统计，并要把 PDF 与元数据放在同一个库里。"
     "文档型数据库在三项需求上同时成立，其他三类都只能覆盖其中一项。")

h("2.3 选型结论与两条主要风险", 2)
para("结论：本平台采用 MongoDB 文档型数据库。理由是“一条馆藏记录天然对应一个文档”，"
     "变长字段用“有则存、无则缺”的方式表达，标签用数组加多键索引，位置用嵌套文档，"
     "电子书用 GridFS 与元数据同库；再加上聚合管道可以直接承担分类统计、排行榜、月度趋势三类分析，"
     "不必再引入额外的分析型组件。")
para("同时必须承认两条风险，并给出应对：")
para("风险一：缺少跨文档强事务。关系型数据库中“扣库存 + 写借阅流水”在一个事务里完成，"
     "MongoDB 单机版没有多文档事务。应对：(1) 业务上把库存与借阅次数设计为同一文档内的两个字段，"
     "一次 $inc 原子更新；(2) 先校验后写入，写失败时不扣库存；(3) 副本集部署后改用多文档事务"
     "（本次副本集阶段已验证会话式事务可用）作为后续加固方案。", indent=True)
para("风险二：模式自由导致数据质量下降。教学数据本身就有 4 本书缺 tags。应对：导入阶段做缺失字段巡检"
     "（见截图 04），查询阶段把“缺 tags 的图书”作为一条正式检索需求（检索五），"
     "并在应用层写入前做字段校验，避免脏数据扩散。", indent=True)

h("2.4 CAP 分析：两个场景的不同取舍", 2)
para("本平台存在两个典型场景，对 CAP 的要求并不一致，必须分开讨论：")
table([["场景", "一致性要求", "可用性要求", "取舍与实现"],
       ["馆藏查询（读多写少）", "可接受秒级陈旧（新书上架晚 1 秒被看到无影响）",
        "要求高，检索页不能转圈", "偏 AP：读偏好用 secondaryPreferred，把读分摊到从节点；"
        "写用 w:majority 保证不丢"],
       ["借阅流水写入（扣库存/还书）", "必须强一致，库存不能超卖",
        "可短暂降级：主节点故障期间可拒绝写入", "偏 CP：读偏好 primary、写关注 majority + "
        "读关注 majority；用 retryWrites 让驱动自动重试"]],
      widths=[3.6, 4.6, 3.6, 6.2], cap="表 2-3　两个场景的 CAP 取舍")
para("这里的取舍不是“选两个特性”，而是按场景分别保证：检索场景牺牲一致性的一小部分换取可用性；"
     "账务场景牺牲故障期间的可用性换取一致性。副本集正好提供了这种“同一集群、两种读偏好”的能力，"
     "这也是本项目在任务五中专门验证读偏好的原因。")

h("2.5 BASE 与最终一致性的接受边界", 2)
para("可以接受最终一致（秒级到分钟级）的功能：借阅排行榜 Top10、月度借阅趋势、分类藏书量与均价均分、"
     "学院借阅 Top5。这些结果即使晚几十秒刷新，业务上也没有损失，且它们都可以从从节点读取。")
para("不能接受最终一致的功能：图书库存扣减、借阅/归还状态流转（借出、已归还、逾期）、"
     "读者权限判断、操作日志 audit_logs 的写入顺序。这些必须走主节点并保证写关注为 majority，"
     "否则会出现“书已借出但库存未减”的账实不符。")

h("2.6 一句话结论与面向非技术决策者的说明", 2)
para("一句话理由：本平台的数据是“一条记录一个文档、字段随书而异、还要按多个维度做统计”，"
     "文档型数据库把这些需求一次性装进一个库里，不需要在关系表和文件服务器之间来回搬运。")
p = doc.add_paragraph()
p.paragraph_format.left_indent = Cm(0.8)
p.paragraph_format.right_indent = Cm(0.8)
p.paragraph_format.space_before = Pt(4)
r = p.add_run("面向非技术决策者（不超过 200 字）：图书馆的书，每本情况都不一样——有的带标签、"
              "有的配电子版、有的分在多个楼层。传统表格数据库要求每本书都填一样的格子，"
              "没内容的格子只能空着，时间一长表格又宽又慢。换成文档型数据库后，每本书按自己的情况记录，"
              "查询和统计反而更快；电子书也能和书目信息放在一起管理。代价是“同时改多处”的操作需要额外小心，"
              "我们通过先校验后写入、故障自动重试来兜底。")
r.font.size = Pt(9.5)
r.italic = True
r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

# ================= 三、数据模型设计 =================
h("三、数据模型设计", 1)
h("3.1 逻辑结构层次", 2)
para("平台使用一个数据库 library，内含四个业务集合与一个统计结果集合，另有 GridFS 的两个内部集合。"
     "层次关系为：数据库 → 集合 → 文档 → 字段（含嵌套文档与数组）。")
table([["集合", "用途", "文档数", "是否分片"],
       ["books", "馆藏图书主数据", "50", "否（随主分片）"],
       ["readers", "读者档案", "30", "否（随主分片）"],
       ["borrow_logs", "借阅流水", "3000", "是，{reader_card:hashed, borrow_date:1}"],
       ["audit_logs", "平台操作日志（自行设计）", "运行累积", "否"],
       ["category_stats", "分类统计结果落库（供后续查询）", "6", "否"],
       ["ebooks.files", "GridFS 文件元数据", "6", "否"],
       ["ebooks.chunks", "GridFS 文件分块数据（每块 261120 字节）", "6", "否"]],
      widths=[3.2, 6.6, 2.4, 5.4], cap="表 3-1　集合划分与用途")

h("3.2 字段类型与选型", 2)
table([["集合", "字段", "类型", "说明"],
       ["books", "isbn", "String", "ISBN-13，唯一标识"],
       ["books", "title / author / publisher", "String", "书名、作者、出版社"],
       ["books", "category", "String", "类别，共 6 类"],
       ["books", "price / rating", "Double", "定价、读者评分"],
       ["books", "stock", "Int", "在架库存"],
       ["books", "tags", "Array<String>", "标签，部分图书无此字段"],
       ["books", "publish_date", "Date", "出版日期"],
       ["books", "borrow_count", "Int", "历史累计借阅次数"],
       ["books", "location", "Object", "嵌套文档：floor / shelf / copies"],
       ["books", "ebook_name", "String", "关联 GridFS 文件名，仅部分图书有"],
       ["readers", "card_no", "String", "借阅证号，唯一"],
       ["readers", "name / college", "String", "姓名、所属学院"],
       ["readers", "email", "String / null", "邮箱，部分为空"],
       ["readers", "phone / level", "String", "联系电话、读者等级"],
       ["readers", "register_date", "Date", "注册时间"],
       ["readers", "fav_categories", "Array<String>", "偏好类别，部分读者无此字段"],
       ["borrow_logs", "borrow_date / return_date", "Date", "借阅时间、归还时间（未还则无）"],
       ["borrow_logs", "reader_card / book_isbn", "String", "关联 readers / books"],
       ["borrow_logs", "status", "String", "已归还 / 借出 / 逾期"],
       ["borrow_logs", "duration_days", "Int", "借阅时长（天）"],
       ["audit_logs", "ts", "Date", "操作时间（UTC 存储，展示转北京时间）"],
       ["audit_logs", "action / target / detail", "String", "动作、对象、明细"],
       ["audit_logs", "operator / result", "String", "操作人、执行结果"]],
      widths=[2.8, 5.6, 3.4, 5.8], font=8.5, cap="表 3-2　字段类型表（含自行设计的 audit_logs）")

h("3.3 三个容易选错的字段", 2)
para("（1）price 用 Double 而不是 String。价格一旦存成字符串，“60—100 元区间”的查询就退化为字符串比较，"
     "$avg 求均价也无法直接计算；Double 能走范围索引，让 avg_price 由聚合管道一次算出（实测计算机类 89.53 元）。"
     "代价是浮点误差，展示层统一保留两位小数即可，不涉及货币结算精度。")
para("（2）publish_date、borrow_date 用 Date 而不是字符串。字符串日期无法做 $year/$month 分组，"
     "也无法让范围查询命中索引。本次导入时把 ISO 8601 字符串统一转为 datetime（保留 +08:00 时区），"
     "后面“按出版年份检索”“按年月统计趋势”两项功能才成立。")
para("（3）stock、borrow_count 用 Int 而不是 Double。两者都参与 $inc 原子更新，整型不会出现 14.999 这类"
     "库存残值；借阅次数还要参与倒序排序，整型比较更省索引空间。")

h("3.4 location 为什么设计成嵌套文档", 2)
para("location 描述“这本书在哪个楼层、哪个架位、有几本复本”，它有三个特点：永远跟着书走、"
     "查询时总和书名一起读出、体量很小（三个字段）。因此设计成嵌套文档 {floor, shelf, copies}，"
     "一次查询即可拿到完整馆藏信息，避免为它单开一张“馆藏位置”表再做 JOIN。")
para("但有两种情况应当反过来拆成独立集合：一是同一本书分散在多个楼层、需要按“架位”做空间维度的统计"
     "（例如“三楼东区还有多少空位”），此时位置成为独立实体并需要频繁单独更新；二是位置信息需要"
     "被多本书共享、且会批量调整（例如整层书架重排）。本项目 50 本书的位置是“一书一处”，"
     "既不共享也不批量重排，所以嵌套是正确选择。")

h("3.5 audit_logs 的字段设计与集合类型", 2)
para("audit_logs 设计为 { ts, action, target, detail, operator, result }，目标是支撑“按时间倒序查询"
     "最近 100 条操作”。因此建 ts 倒序索引 idx_ts_desc，查询时 sort({ts:-1}).limit(100) 直接走索引，"
     "不需要在内存里排序。")
para("集合类型选择普通集合，而不是固定集合（capped）。原因是：审计日志需要按 action 过滤、"
     "按动作类型做分组统计（如“新增图书多少次”），固定集合不支持删除单条、且只能顺序追加，"
     "无法配合二级索引做多条件查询；如果担心无限增长，正确的做法是普通集合 + TTL 索引"
     "（如保留 180 天）或按月份分集合归档。")

h("3.6 borrow_logs 的集合类型与关键参数", 2)
para("borrow_logs 采用普通集合（非 capped、非 time series），理由有三点：第一，还书时要按 _id 更新"
     "return_date 与 status，capped 集合的文档不可修改；第二，需要按 reader_card、book_isbn、status "
     "分别建二级索引，capped 集合不支持额外索引；第三，time series 集合适合“只追加、按时间窗口聚合”的"
     "场景，而借阅流水存在随机更新（还书、逾期标记），因此不适合。")
para("关键参数：WiredTiger 存储引擎，默认 256KB 的 chunk 内部组织；文档平均约 76 字节，"
     "3000 条数据 dataSize 约 230KB；分片阶段把该集合的片键设为 {reader_card:\"hashed\", borrow_date:1}，"
     "并保留 idx_book_date、idx_status 两个二级索引。")

h("3.7 索引清单", 2)
table([["集合", "索引名", "键", "用途"],
       ["books", "uk_isbn", "isbn:1（唯一）", "ISBN 唯一、关联去重"],
       ["books", "idx_category_price", "category:1, price:1", "类别 + 价格区间组合筛选"],
       ["books", "idx_tags", "tags:1", "标签多选（$all/$in，多键索引）"],
       ["books", "idx_title", "title:1", "书名前缀 / 模糊检索"],
       ["books", "idx_publish_date", "publish_date:1", "出版年份范围"],
       ["books", "idx_rating", "rating:-1", "评分倒序取前 10"],
       ["books", "idx_borrow_count", "borrow_count:-1", "借阅排行"],
       ["readers", "uk_card_no", "card_no:1（唯一）", "证号唯一、流水关联"],
       ["readers", "idx_college", "college:1", "按学院筛选与聚合"],
       ["borrow_logs", "idx_reader_date", "reader_card:1, borrow_date:-1", "读者维度 + 时间范围（与片键前缀一致）"],
       ["borrow_logs", "idx_book_date", "book_isbn:1, borrow_date:-1", "图书维度借阅统计"],
       ["borrow_logs", "idx_status", "status:1", "在借 / 逾期筛选"],
       ["audit_logs", "idx_ts_desc", "ts:-1", "按时间倒序取最近 100 条"]],
      widths=[3.0, 4.4, 5.4, 5.0], font=8.5, cap="表 3-3　索引清单（共 13 个二级索引）")

h("3.8 五条关键设计决策", 2)
decisions = [
    ("决策 1：标签用数组 + 多键索引，而不是“标签表 + 关联表”。", "标签数量少（每本 2—3 个）、"
     "查询以“同时包含若干标签”为主，$all 一条语句即可，多键索引自动为数组每个元素建索引项。"),
    ("决策 2：借阅流水与图书分开存，靠 ISBN 关联，而不是把流水内嵌进图书文档。",
     "单本书的流水会持续增长，内嵌会让文档无限膨胀并触及 16MB 上限，也拖慢图书读取。"),
    ("决策 3：把统计结果写入 category_stats 集合，而不是每次现算。",
     "分类统计是典型的“读多算少”，落库后页面直接查 6 行结果，且保留 generated_at 便于判断新鲜度。"),
    ("决策 4：日期统一以 UTC 存储、按业务时区展示与聚合。",
     "跨时区部署不会错乱；聚合时显式指定 timezone:\"Asia/Shanghai\"，避免年初流水被算到上一年 12 月（见第七章难点一）。"),
    ("决策 5：唯一性交给唯一索引兜底，而不是只靠应用层判断。",
     "isbn、card_no 建唯一索引后，并发重复写入会直接报 E11000，比“先查再插”可靠。"),
]
for t1, t2 in decisions:
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(t1)
    r.bold = True
    r.font.size = Pt(10.5)
    r2 = p.add_run(t2)
    r2.font.size = Pt(10.5)

# ================= 四、功能实现 =================
h("四、功能实现", 1)
h("4.1 程序结构", 2)
para("程序共 11 个 Python 源文件，统一由 db.py 提供连接，业务模块之间不直接操作集合名，"
     "所有连接参数来自环境变量，换机器只需改环境变量，不修改代码。")
table([["文件", "职责"],
       ["db.py", "统一连接模块：连接串拼装、读偏好、GridFS bucket、集合名常量"],
       ["import_data.py", "三份数据导入、Date 类型转换、文档数核对、数据质量巡检"],
       ["create_indexes.py", "13 个二级索引的创建与清单输出"],
       ["perf_test.py", "索引前后执行计划与耗时对比（before / after 两阶段）"],
       ["book_service.py", "6 项检索、图书增删改、分页"],
       ["reader_service.py", "读者管理、借书还书、读者流水与汇总"],
       ["stats_service.py", "5 项统计与统计结果落库"],
       ["audit_service.py", "audit_logs 写入与最近 100 条查询"],
       ["file_service.py", "GridFS 上传、按书名下载、字节/MD5 校验、文件清单"],
       ["main.py", "菜单式主程序（8 个功能项，覆盖全部检索与统计）"],
       ["read_pref_demo.py / failover_test.py / shard_*", "副本集读偏好、故障转移、分片验证脚本"],
       ["web_console.py", "Web 可视化验收台（数据核对、聚合查询、CSV 导出）"]],
      widths=[5.4, 11.2], font=9, cap="表 4-1　源文件职责划分")

h("4.2 六项检索功能与执行结果", 2)
para("六项检索均在菜单第 1 项下执行，每条都打印命中条数，便于与预期核对：")
table([["检索", "查询条件", "命中", "说明"],
       ["检索一", "category=计算机，60 ≤ price ≤ 100", "7", "走 idx_category_price"],
       ["检索二", "tags 同时包含“编程”“入门”（$all）", "1", "多键索引，$all 需同时满足"],
       ["检索三", "title 含“系统”（正则，忽略大小写）", "3", "关键字做 re.escape 防注入特殊字符"],
       ["检索四", "publish_date 在 2023—2024 年", "1", "年份换算为 +08:00 的 Date 边界"],
       ["检索五", "tags 字段不存在", "4", "数据质量核查，命中 4 本缺标签图书"],
       ["检索六", "rating 倒序取前 10，只返回书名/作者/评分", "10", "投影限定三字段，走 idx_rating"]],
      widths=[2.4, 8.0, 2.0, 4.6], cap="表 4-2　六项检索与结果条数")

h("4.3 五项统计功能", 2)
table([["统计", "实现要点", "结果摘要"],
       ["按类别统计", "$group 按 category 汇总，$avg 求均价、$round 保留两位", "计算机 15 本、均价 89.53、均分 4.53"],
       ["学院借阅 Top5", "borrow_logs 按 reader_card 汇总后 $lookup readers，再按学院聚合", "计算机学院 501、经济管理学院 500、数学与统计学院 400"],
       ["月度借阅趋势", "$year/$month 按 Asia/Shanghai 时区分组，$concat 拼“2023-01”标签", "36 个月，月均约 83 条"],
       ["借阅 Top10 + 位置", "流水按 ISBN 计数 → $sort → $lookup books 取 title 与 location", "榜首 61 次，附楼层/架位"],
       ["统计结果落库", "统计结果写入 category_stats，带 generated_at", "写入 6 行，可被再次查询"]],
      widths=[3.4, 8.4, 6.2], font=8.5, cap="表 4-3　五项统计功能的实现与结果")

h("4.4 索引优化：前后对比", 2)
para("为了公平比较，优化前用 hint({$natural:1}) 强制全表扫描，优化后走默认执行计划；"
     "每条查询重复 200 次取平均墙钟耗时，同时记录 totalDocsExamined（检查文档数）。")
table([["查询", "优化前检查文档", "优化后检查文档", "降幅", "优化前墙钟(ms)", "优化后墙钟(ms)"],
       ["Q1 类别+价格区间", "50", "7", "86%", "0.2217", "0.2998"],
       ["Q2 书名模糊检索", "50", "3", "94%", "0.2338", "0.2555"],
       ["Q3 标签多选匹配", "50", "4", "92%", "0.2352", "0.2154"],
       ["Q4 读者+日期范围", "3000", "34", "98.9%", "1.0754", "0.2962"]],
      widths=[3.8, 3.2, 3.2, 2.0, 2.8, 2.8], font=8.5, cap="表 4-4　索引前后执行计划对比（200 次平均）")
para("结论要如实说明：50 条图书的小数据集上，全表扫描本身只需几十微秒，墙钟时间的差异被进程与网络开销掩盖，"
     "因此优化收益主要体现在 totalDocsExamined 的下降（86%—98.9%）与数据量增长后的可扩展性；"
     "在 3000 条流水的 Q4 上，墙钟时间从 1.0754ms 降到 0.2962ms，约 3.6 倍，这是索引真正开始起作用的信号。"
     "这也是本项目没有用“耗时降低 90%”这类夸张表述的原因。")

h("4.5 访问控制", 2)
table([["账号", "角色", "权限范围", "验证结果"],
       ["lib_reader", "read@library", "只能查询", "读取 50 本成功；insert 被拒（not authorized）"],
       ["lib_editor", "readWrite@library", "读写业务集合", "借书、还书、写日志均成功"],
       ["lib_admin", "dbOwner@library", "管理库内对象", "可建索引、可写 audit_logs"],
       ["root_admin", "root@admin", "集群管理", "仅用于部署与运维，业务程序不使用"]],
      widths=[3.2, 4.4, 4.4, 6.4], font=9, cap="表 4-5　角色划分与验证结果")
para("验证方式：用只读账号连接后先 countDocuments 成功，再执行 insertOne，服务端返回 "
     "\"not authorized on library to execute command { insert: \\\"books\\\" ... }\"，说明越权写入被拒绝；"
     "换成 lib_admin 同一语句执行成功并返回 insertedId。")

h("4.6 应用运行效果", 2)

# ================= 五、文件存储 =================
h("五、文件存储（GridFS）", 1)
h("5.1 存储结构", 2)
para("电子书与封面统一存放在 GridFS 的 ebooks 桶中，MongoDB 自动把它拆成两个集合："
     "ebooks.files 存文件元数据（文件名、长度、块大小、上传时间、自定义 metadata），"
     "ebooks.chunks 存文件分块（每块 261120 字节，即 255KB）。"
     "本项目的 6 个文件都小于一个块，因此每个文件对应 1 个 chunk。")
table([["文件", "大小(字节)", "块数", "关联 ISBN", "类型"],
       ["ebook_1.pdf", "39837", "1", "9787115428028", "ebook"],
       ["ebook_2.pdf", "38524", "1", "9787121362726", "ebook"],
       ["ebook_3.pdf", "37004", "1", "9787115546081", "ebook"],
       ["cover_1.png", "23611", "1", "9787115428028", "cover"],
       ["cover_2.png", "26053", "1", "9787121362726", "cover"],
       ["cover_3.png", "15171", "1", "9787115546081", "cover"]],
      widths=[3.6, 3.4, 2.0, 4.6, 3.0], font=9, cap="表 5-1　GridFS 中的 6 个文件")
para("元数据写入 metadata 子文档：{isbn, file_type, original_name, bytes_md5}。"
     "isbn 用于与 books 集合关联（books.ebook_name → GridFS filename），"
     "bytes_md5 是下载校验的基准值——这比只比较长度更可靠，因为长度相同而内容损坏的情况确实存在。")

h("5.2 上传、下载与校验流程", 2)
para("上传：读取本地文件 → 计算 MD5 → upload_from_stream(filename, data, metadata) → 写一条 audit_logs。"
     "下载：按书名正则命中 books 文档 → 取 ebook_name → bucket.find({filename}) → "
     "download_to_stream 到本地 downloads 目录 → 重新计算长度与 MD5，与元数据比对。")
para("实测三个 PDF 全部校验通过：ebook_1.pdf 39837 字节、ebook_2.pdf 38524 字节、ebook_3.pdf 37004 字节，"
     "下载后长度一致、MD5 一致（verify=True）。文件清单页列出全部 6 个文件的大小、块数、上传时间、"
     "关联 ISBN 与类型，可直接与 files_manifest.txt 对账。")

# ================= 六、架构演进 =================
h("六、架构演进", 1)
h("6.1 三个阶段的拓扑与端口", 2)
table([["阶段", "组件", "端口", "说明"],
       ["阶段一 单机", "mongod", "27017", "自定义数据目录 /home/user/mongo-data/single"],
       ["阶段二 副本集", "mongod × 3（rs0）", "27031 / 27032 / 27033", "priority 2/1/1，keyFile 内部认证 + 授权"],
       ["阶段三 配置服务器", "mongod（cfgRS）", "27019", "clusterRole: configsvr"],
       ["阶段三 分片一", "mongod（shard1）", "27041", "clusterRole: shardsvr"],
       ["阶段三 分片二", "mongod（shard2）", "27042", "clusterRole: shardsvr"],
       ["阶段三 路由", "mongos", "27020", "configDB: cfgRS/127.0.0.1:27019"]],
      widths=[3.4, 5.4, 4.6, 5.6], font=9, cap="表 6-1　三阶段部署拓扑与端口")
para("拓扑逻辑：单机阶段用于数据建模与功能验证；副本集阶段解决高可用，三节点一主两从，"
     "主节点故障自动选举；分片集群阶段解决水平扩展，配置服务器保存集群元数据，"
     "两个分片各自是单节点副本集（MongoDB 7.0 要求分片必须是副本集），mongos 负责路由与结果归并。")

h("6.2 副本集验证：读偏好与故障转移", 2)
para("从节点默认不可读，必须显式配置读偏好。用 pymongo 的命令日志抓取“find 实际发往哪个端口”，"
     "得到如下实测结果：")
table([["读偏好", "find 实际落点", "节点角色", "读到文档数"],
       ["primary", "27031", "PRIMARY", "50"],
       ["secondaryPreferred", "27032", "SECONDARY", "50"],
       ["nearest", "27033", "SECONDARY", "50"]],
      widths=[4.6, 4.4, 4.4, 3.4], font=9, cap="表 6-2　三种读偏好的实际落点")
para("故障转移演练用 kill -9 直接终止主节点进程（比 rs.stepDown 更接近真实宕机），"
     "每 0.2 秒轮询三个节点角色，同时用两个连接持续探测读写：")
table([["时间点", "事件", "集群状态", "业务影响"],
       ["T+0.00s", "kill -9 主节点 27031", "27031 DOWN，27032/27033 SECONDARY", "写请求开始失败"],
       ["T+0.02s", "首个写失败", "无主节点", "驱动 retryWrites 挂起重试"],
       ["T+8.60s", "27033 被选举为主", "27031 DOWN，27033 PRIMARY", "写请求恢复"],
       ["T+10.42s", "首个写恢复成功", "同上", "写探测累计 12 次：9 成功 / 3 失败"],
       ["T+12.20s", "窗口结束", "稳定一主一从一宕机", "读探测 12 次全部成功（走从节点）"],
       ["T+12.30s", "重启原主节点 27031", "27031 SECONDARY", "自动追平 oplog，不抢占主节点"]],
      widths=[2.6, 5.4, 6.2, 4.8], font=9, cap="表 6-3　故障转移过程记录（选举耗时 10.80s）")
para("对三个现象的解释：第一，选举耗时约 10.8 秒，与默认 electionTimeoutMillis=10s 吻合，"
     "不是配置错误；第二，写请求只失败 3 次而不是整个 10 秒都在失败，是因为驱动开启 retryWrites 后"
     "会自动重试，应用层感知为“一次较慢的写”；第三，读请求 12 次全部成功，因为统计类查询走"
     "secondaryPreferred，在主节点宕机期间由 27032 继续提供服务——这正是 2.4 节 CAP 取舍的现场验证。")
figure("30_故障转移.png", 14.0, "图 6-1　故障转移演练：选举 10.80s，写探测 9 成功 / 3 失败，读探测 12 次全部成功")

h("6.3 分片集群与分片键论证", 2)
para("分片键选择 {reader_card:\"hashed\", borrow_date:1}（复合哈希分片键），理由如下（不少于 500 字的要求，"
     "这里按基数、写分布、查询支持、备选方案四个维度展开）：")
para("（1）基数分析。borrow_logs 共 3000 条，reader_card 只有 30 个不同值，book_isbn 有 50 个，"
     "_id 有 3000 个。若不使用哈希，而是用 {reader_card:1} 做范围分片键，30 个取值只能切出 30 个区间，"
     "且按字典序聚集，早期读者（R20240001 起）会全部挤在第一个分片，写热点非常明显。"
     "改用哈希后，reader_card 经 MD5 打散，30 个取值均匀落入两个分片，实测 shard1 1300 条、"
     "shard2 1700 条（56.7% / 43.3%），单分片占比都在 40%—60% 区间，没有出现倾斜。")
para("（2）写分布均匀性。哈希分片键的最大优势是写入按哈希值轮转，不受业务顺序影响；"
     "再加上第二个字段 borrow_date 作为范围字段，MongoDB 可以在此基础上继续做 chunk 切分，"
     "使 chunk 数量不被 30 个哈希值限制（实测两个分片各 2 个 chunk，共 4 个 chunk）。"
     "如果不加 borrow_date 而只用 {reader_card:\"hashed\"}，chunk 上限就固定在 30 个哈希值附近，"
     "扩展到 4 个以上分片时粒度会不够。")
para("（3）查询支持。本平台对流水的三类高频查询是：按读者查自己的借阅（reader_card 等值）、"
     "按读者 + 时间范围查（reader_card 等值 + borrow_date 范围）、按图书或全局时间统计。"
     "前两类都带 reader_card 等值条件，mongos 能通过哈希前缀直接定位到单个分片，"
     "explain 显示 SINGLE_SHARD，检查文档仅 100 条 / 33 条；第三类不带 reader_card，"
     "explain 显示 SHARD_MERGE，需要广播到两个分片再归并，检查文档 3000 条。"
     "也就是说，分片键选对了“读者维度”这条主查询，代价是“图书维度/全局时间”查询要散射。")
para("（4）备选方案对比。方案 A：{_id:\"hashed\"}。分布最均匀（3000 个哈希值，chunk 可无限细分），"
     "但业务查询永远不带 _id，所有查询都要散射到全部分片，等于放弃了分片的路由价值，因此不选。"
     "方案 B：{book_isbn:1, borrow_date:1} 范围分片。可支持“某本书 + 时间”的查询，"
     "但 book_isbn 只有 50 个值，热门书（榜首 61 次借阅）会造成写入与读热点，"
     "且无法路由“读者查自己的借阅”这类最高频查询，因此不选。"
     "方案 C：{reader_card:1, borrow_date:1} 纯范围。虽然也能按读者路由，但如前所述会按证号顺序聚集，"
     "写热点明显，且新读者总是落在末尾分片，因此不如复合哈希。")
para("综合结论：选择 {reader_card:\"hashed\", borrow_date:1}。它在“基数偏低”的现实数据下用哈希换取均匀分布，"
     "用第二个范围字段保留 chunk 切分能力，并让读者维度的两类主查询变成 SINGLE_SHARD；"
     "代价是跨读者的时间范围统计要散射归并，但这类查询本身是离线统计，可接受。")
table([["查询", "归并阶段", "命中的分片", "检查文档", "返回"],
       ["按读者证号 = R20240012", "SINGLE_SHARD", "shard2", "100", "100"],
       ["读者证号 + 日期范围", "SINGLE_SHARD", "shard2", "33", "33"],
       ["按图书 ISBN", "SHARD_MERGE", "shard2, shard1", "60", "60"],
       ["全库日期范围", "SHARD_MERGE", "shard1, shard2", "3000", "246"]],
      widths=[5.0, 3.4, 4.0, 3.0, 2.4], font=9, cap="表 6-4　定向查询与跨分片查询的执行计划对比")
table([["分片", "文档数", "数据大小", "chunk 数"],
       ["shard1", "1300", "200396 B", "2"],
       ["shard2", "1700", "262012 B", "2"],
       ["合计", "3000", "约 462 KB", "4"]],
      widths=[4.0, 4.0, 4.4, 3.4], font=9, cap="表 6-5　borrow_logs 在两个分片上的实际分布")
figure("35_数据分布.png", 12.5, "图 6-3　数据确实分布在两个分片上：1300 / 1700 条，各 2 个 chunk")
para("集群同样启用了访问控制：mongos 上创建了 lib_reader（只读）与 lib_editor（读写），"
     "只读账号读取 books=50、borrow_logs=3000 成功，写入被拒绝；集群组件之间用 keyFile 做内部认证。"
     "同一套业务程序只改 MONGO_URI 环境变量即可连接分片集群运行统计（截图 38），"
     "说明程序没有硬编码连接串与路径。")

# ================= 七、问题与总结 =================
h("七、问题与总结", 1)
h("7.1 四个真实技术难点的排查过程", 2)
para("难点一：日期字段存成字符串，聚合结果整体偏移一个月。", bold=True)
para("现象：先把 borrow_logs.txt 直接当字符串导入时，$year/$month 分组报错；改成 datetime 后，"
     "月度趋势里出现“2022-12 有 3 条”的异常月份，但源数据明确写着覆盖 2023—2025 年。"
     "排查：把原始 3 条记录取出，发现其 borrow_date 是 2022-12-31T16:00:00.000+08:00，"
     "换算成 UTC 正好是 2022-12-31T08:00Z，而 $year/$month 默认按 UTC 计算，于是被归入 2022 年 12 月。"
     "解决：聚合时显式指定 {\"$year\":{\"date\":\"$borrow_date\",\"timezone\":\"Asia/Shanghai\"}}，"
     "年份范围查询的边界也改为带 +08:00 的 datetime。修正后月份数从 37 变为 36，"
     "异常月份消失，年度数据与源文件一致。这个过程记在截图 13 与第四章。")
para("难点二：pymongo 4.x 的 GridFS 接口与教材示例不一致。", bold=True)
para("现象：按教材写法 GridFSBucket(db, bucketName=\"ebooks\") 直接抛 TypeError；"
     "改用 bucket_name 后又出现 “GridOut object is not subscriptable”。"
     "排查：打印 inspect.signature(GridFSBucket.__init__)，确认 4.19 版本参数为 bucket_name；"
     "再打印 GridOut 对象，发现它不再支持 g[\"filename\"] 下标访问。"
     "解决：上传/下载统一改为属性访问（fdoc.filename、fdoc.length、fdoc.metadata），"
     "并把 bucket 的创建收敛到 db.py 的 get_fs_bucket()，避免各处写法不一致。修正后 6 个文件上传、"
     "3 个 PDF 下载校验全部通过。")
para("难点三：副本集启用 keyFile 后，第一次建账号被“锁在门外”。", bold=True)
para("现象：按“先启动、再创建用户”的顺序操作时，createUser 报 "
     "\"Command createUser requires authentication\"，而此刻库里还没有任何账号。"
     "排查：keyFile 在 MongoDB 中不仅用于节点间认证，也会把客户端认证一并打开，"
     "此时只能依赖 localhost exception，而该例外在多节点副本集上行为受限。"
     "解决：先在配置中去掉 security 段（保留 replSetName）启动三节点，创建 root/lib_editor/lib_admin "
     "三个账号，确认写入 local.system.users 后再带 keyFile + authorization 重启；"
     "重启后用 root_admin 连接验证 rs.status() 正常。教训是：部署顺序必须是“先建账号、再开认证”。")
para("难点四：故障转移后把演练环境“练坏了”。", bold=True)
para("现象：第一版节点增删脚本在结束时对“当前主节点”执行 shutdownServer，导致演练后集群只剩一个节点、"
     "后续故障转移第一次运行时找不到主节点。排查：查看 rs.status() 发现 27031/27033 均为 DOWN，"
     "对照脚本才发现最后一行关闭的是主节点而不是演练用的 27034。"
     "解决：脚本改为只按 mongod-rs4.conf 找到 27034 的 PID 后停止它，并用动态探测确定主节点；"
     "重跑后三节点恢复健康，演练记录重新采集（截图 28—33）。")

h("7.2 项目反思", 2)
para("第一，小数据集上的性能结论要克制。50 本书的全表扫描本来就快，索引的收益要用 totalDocsExamined 与"
     "执行计划阶段来说明，而不是编造“提速 90%”。真实的收益出现在 3000 条流水的范围查询上（3.6 倍）。")
para("第二，单机阶段没有事务，程序只能靠“先校验后写入”降低不一致概率，这是设计上的临时妥协；"
     "副本集阶段具备多文档事务能力，后续可以把“扣库存 + 写流水”收进一个事务。")
para("第三，分片键的选择受数据基数制约。30 位读者的现实数据下，哈希分片键的均匀性靠哈希函数而不是"
     "业务基数保证，但 chunk 数量的上限仍然受基数影响，这一点在扩展到更多分片时会成为瓶颈，"
     "需要在生产数据量下重新评估。")
para("第四，文档与代码同样重要。本次把每个任务的命令、输出、截图都落到 evidence 目录，"
     "写文档时可以直接引用真实数字（如选举 10.80s、1300/1700 条分布、39837 字节校验），"
     "避免了“凭印象写结论”。")

h("7.3 后续可改进方向", 2)
for t in ["借阅与还书改用副本集多文档事务，彻底消除账实不符的可能；",
          "audit_logs 增加 TTL 索引（保留 180 天），避免无限增长；",
          "为统计页加 Redis 缓存层，进一步降低主节点读压力；",
          "分片集群增加第三个分片并开启 balancer 观察 chunk 迁移，验证再平衡行为。"]:
    bullet(t)

# ================= 附录 =================
h("附录：运行截图与交付物清单", 1)
para("过程记录共 44 张截图，覆盖任务一至任务七，全部来自真实命令输出，原始文本保存在 "
     "evidence/logs/ 目录，可与截图逐字核对；按任务书要求，截图作为附录不计入正文页数。")
shot_list = [
    ("01 项目结构", "21 GridFS 上传文件"), ("02 单机启动与库状态", "22 文件清单"),
    ("03 数据导入与核对", "23 下载校验"), ("04 数据质量巡检", "24 存储统计"),
    ("05—10 六项检索", "25 操作日志"), ("11—15 五项统计", "26 图书管理"),
    ("16 索引清单", "27 借阅管理"), ("17—18 索引前后对比", "28 副本集状态"),
    ("19 权限控制", "29 读偏好验证"), ("20 应用主菜单", "30—31 故障转移与时间线"),
    ("32 节点增删", "33 副本集认证"), ("34 分片集群状态", "35 数据分布"),
    ("36 分片键路由", "37 集群权限"), ("38 应用连分片集群", "39 命令行核对"),
    ("40—44 可视化验收台（概览/检索/流水/聚合/导出）", ""),
]
table([[a, b] for a, b in shot_list], widths=[8.2, 8.2], font=8.5, cap="表 A-1　截图清单")
para("交付物：")
for t in ["源代码：src/ 下 11 个 Python 源文件，含统一连接模块 db.py，可直接运行；",
          "数据库与配置：data/ 原始数据、config/ 全部 mongod/mongos 配置与启停脚本；",
          "项目文档：本文件（PDF + Word 两种格式，正文 12 页，截图作为附录不计入正文）；",
          "过程记录：screenshots/ 44 张截图 + evidence/ 日志与 JSON 记录 + 导出的 CSV；",
          "可视化验收：web_console.py 提供的 Web 控制台与导出结果（evidence/exports/）。"]:
    bullet(t)

add_page_number()
doc.save(OUT)
print("已生成:", OUT)
