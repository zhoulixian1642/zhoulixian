"""生成《智慧图书馆数字资源平台》项目文档（Word，七章结构）。"""
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path("/home/user/Doubao/chats/38452800552715778/智慧图书馆数字资源平台")
SHOTS = ROOT / "shots"
FIG = ROOT / "figures"
OUT = ROOT / "智慧图书馆数字资源平台_项目文档.docx"

BLACK = RGBColor(0, 0, 0)
SONG, HEI, KAI, TNR = "宋体", "黑体", "楷体", "Times New Roman"


def set_run_font(run, cn=SONG, size=12, bold=False, color=BLACK):
    run.font.name = TNR
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), TNR)
    rfonts.set(qn("w:hAnsi"), TNR)
    rfonts.set(qn("w:eastAsia"), cn)


def style_base(doc):
    normal = doc.styles["Normal"]
    normal.font.name = TNR
    normal.font.size = Pt(12)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), SONG)
    pf = normal.paragraph_format
    pf.line_spacing = 1.5
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(24)
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


def body(doc, text, indent=True, space_after=0, align=WD_ALIGN_PARAGRAPH.JUSTIFY):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.5
    pf.space_before = Pt(0)
    pf.space_after = Pt(space_after)
    pf.first_line_indent = Pt(24) if indent else Pt(0)
    p.alignment = align
    run = p.add_run(text)
    set_run_font(run, SONG, 12)
    return p


def heading(doc, text, level):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.space_before = Pt({1: 14, 2: 11, 3: 9}[level])
    p.paragraph_format.space_after = Pt({1: 6, 2: 5, 3: 4}[level])
    p.paragraph_format.first_line_indent = Pt(0)
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    set_run_font(run, HEI, {1: 16, 2: 14, 3: 12}[level], bold=True)
    return p


def caption(doc, text, before=4, after=6):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf.first_line_indent = Pt(0)
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = 1.0
    run = p.add_run(text)
    set_run_font(run, SONG, 10.5)
    return p


def figure(doc, path, cap, width_cm=13.5):
    p = doc.add_paragraph()
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Pt(0)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(path), width=Cm(width_cm))
    caption(doc, cap, before=3, after=8)


def _shade(cell, color="D9D9D9"):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), color)
    tcpr.append(shd)


def _borders(table):
    tblpr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:color"), "808080")
        borders.append(el)
    tblpr.append(borders)


def table(doc, cap, headers, rows, widths, aligns=None, font_size=10.5):
    caption(doc, cap, before=6, after=3)
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = 1
    t.autofit = False
    _borders(t)
    hdr = t.rows[0]
    trpr = hdr._tr.get_or_add_trPr()
    trpr.append(OxmlElement("w:tblHeader"))
    trpr.append(OxmlElement("w:cantSplit"))
    for i, h in enumerate(headers):
        cell = hdr.cells[i]
        cell.width = Cm(widths[i])
        _shade(cell)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.space_after = Pt(1)
        run = p.add_run(h)
        set_run_font(run, HEI, font_size, bold=True)
    for row in rows:
        tr = t.add_row()
        tr._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for i, val in enumerate(row):
            cell = tr.cells[i]
            cell.width = Cm(widths[i])
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.paragraph_format.first_line_indent = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            al = (aligns or ["left"] * len(headers))[i]
            p.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                           "center": WD_ALIGN_PARAGRAPH.CENTER,
                           "right": WD_ALIGN_PARAGRAPH.RIGHT}[al]
            run = p.add_run(str(val))
            set_run_font(run, SONG, font_size)
    return t


def add_toc(doc):
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Pt(0)
    run = p.add_run()
    els = []
    b = OxmlElement("w:fldChar")
    b.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = 'TOC \\o "1-2" \\h \\z \\u'
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    t = OxmlElement("w:t")
    t.text = "（右键选择“更新域”生成目录与页码）"
    e = OxmlElement("w:fldChar")
    e.set(qn("w:fldCharType"), "end")
    for el in (b, instr, sep, t, e):
        run._r.append(el)
    set_run_font(run, SONG, 12)


def page_field(paragraph):
    run = paragraph.add_run()
    b = OxmlElement("w:fldChar")
    b.set(qn("w:fldCharType"), "begin")
    i = OxmlElement("w:instrText")
    i.set(qn("xml:space"), "preserve")
    i.text = "PAGE"
    s = OxmlElement("w:fldChar")
    s.set(qn("w:fldCharType"), "separate")
    t = OxmlElement("w:t")
    t.text = "1"
    e = OxmlElement("w:fldChar")
    e.set(qn("w:fldCharType"), "end")
    for el in (b, i, s, t, e):
        run._r.append(el)
    set_run_font(run, SONG, 10.5)


def page_setup(section):
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.5)
    section.bottom_margin = Cm(2.5)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)


doc = Document()
style_base(doc)
page_setup(doc.sections[0])

# ---------------- 封面 ----------------
for _ in range(3):
    doc.add_paragraph()
p = doc.add_paragraph()
p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.first_line_indent = Pt(0)
r = p.add_run("《NoSQL数据库技术与应用（第2版）》第1—6章综合实践")
set_run_font(r, KAI, 12)

p = doc.add_paragraph()
p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.first_line_indent = Pt(0)
p.paragraph_format.space_before = Pt(16)
p.paragraph_format.space_after = Pt(10)
r = p.add_run("智慧图书馆数字资源平台")
set_run_font(r, HEI, 22, bold=True)

p = doc.add_paragraph()
p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.first_line_indent = Pt(0)
p.paragraph_format.space_after = Pt(34)
r = p.add_run("项 目 文 档")
set_run_font(r, HEI, 16, bold=True)

info = [("姓　　名", "学　　号", "分　　工"),
        ("尚佳琪", "202414870230", "数据建模、导入核对、检索统计与应用程序"),
        ("陈　菲", "202414870227", "副本集、分片集群、认证配置与故障演练"),
        ("周丽娴", "202414870222", "图形化验收、统计导出、截图归档与文档整理")]
t = doc.add_table(rows=0, cols=3)
t.alignment = 1
_borders(t)
for i, row in enumerate(info):
    tr = t.add_row()
    for j, val in enumerate(row):
        cell = tr.cells[j]
        cell.width = Cm(3.2 if j == 0 else (3.6 if j == 1 else 8.8))
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if j < 2 else WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(val)
        set_run_font(r, HEI if i == 0 else SONG, 10.5, bold=(i == 0))

p = doc.add_paragraph()
p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.first_line_indent = Pt(0)
p.paragraph_format.space_before = Pt(60)
r = p.add_run("2026 年 11 月")
set_run_font(r, SONG, 12)

# ---------------- 目录 ----------------
doc.add_section(WD_SECTION.NEW_PAGE)
page_setup(doc.sections[-1])
p = doc.add_paragraph()
p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.first_line_indent = Pt(0)
p.paragraph_format.space_after = Pt(12)
r = p.add_run("目　录")
set_run_font(r, HEI, 16, bold=True)
add_toc(doc)

# ---------------- 正文 ----------------
doc.add_section(WD_SECTION.NEW_PAGE)
sec = doc.sections[-1]
page_setup(sec)
sec.footer.is_linked_to_previous = False
fp = sec.footer.paragraphs[0]
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
page_field(fp)
pgnum = OxmlElement("w:pgNumType")
pgnum.set(qn("w:start"), "1")
sec._sectPr.append(pgnum)

heading(doc, "1　项目概述", 1)
heading(doc, "1.1　业务背景与项目目标", 2)
body(doc, '某高校图书馆现有纸质馆藏约 50 万册，近年持续采购电子书。原系统基于关系型数据库，在三个方面出现瓶颈：馆藏字段差异大，'
     '部分图书没有标签、部分读者没有偏好类目、邮箱允许为空；借阅流水增长快，样例三年就有 3000 条，实际按年增数十万；'
     '电子书文件无处存放，PDF 与封面只能放共享盘，无法与书目建立可靠关联。图书馆决定迁移到 MongoDB，建设统一的数字资源平台。')
body(doc, '本项目要在单机、副本集、分片集群三种形态下交付同一套业务能力：馆藏与读者管理、六项检索、五项统计、借阅流转、'
     '电子书存取与三角色访问控制。程序用环境变量装配连接参数，换机只改环境变量即可运行；导入结果与源文件逐条核对；统计结论要能在图形化控制台复现。')
body(doc, '交付物包括 code 目录 18 个 Python 源文件、conf 目录五份实例配置与启停/分片脚本、data 目录源数据与导出统计文件、'
     'shots 目录 37 张过程记录截图、logs 目录 20 份运行日志，以及本文档。')

heading(doc, "1.2　成员分工与进度", 2)
body(doc, '小组按“数据与程序、架构与运维、文档与验收”三条线分工，每人对自己主责的数据与结论负责，并交叉复核其余部分。'
     '十四天的推进节奏与任务书的阶段安排一致，前一阶段产出是后一阶段输入。')
table(doc, '表 1　成员分工与阶段进度',
      ['成员', '学号', '主责内容', '阶段'],
      [('尚佳琪', '202414870230', '数据建模、导入核对、检索统计、应用程序与索引优化', '第 1—9 天'),
       ('陈　菲', '202414870227', '副本集部署与故障演练、分片集群、认证与节点增删', '第 10—13 天'),
       ('周丽娴', '202414870222', '图形化控制台验收、统计导出、截图归档与文档撰写', '第 7—14 天')],
      [2.0, 3.0, 8.4, 2.6], ['center', 'center', 'left', 'center'])

heading(doc, "2　技术选型论证", 1)
heading(doc, "2.1　业务字段对关系模型的压力", 2)
body(doc, '判断要不要换数据库，先看现有字段在关系模型里会不会别扭。把任务书的字段表逐项对照，问题集中在四处。')
body(doc, '第一是可选字段多。50 条图书里有 4 条没有 tags，30 条读者里有 2 条没有 fav_categories、5 条邮箱为空。'
     '关系表要么为每个可选字段建列并允许 NULL，列稀疏且语义含糊；要么另建标签表与关联表，一次列表查询要连三张表。'
     '文档模型里字段缺失就是键不存在，exists 判断语义清楚。')
body(doc, '第二是嵌套结构。location 同时记录楼层区域、架位号与复本数，三项永远跟着一本书读写，列表页也要一起展示。'
     '关系模型拆成馆藏位置表后，每次展示都要 join，位置单字段更新还要跨表维护一致性。')
body(doc, '第三是多值字段检索。tags 是数组，业务要求“同时包含若干标签”，关系模型要 tags 表、book_tags 关联表加计数子查询；'
     'MongoDB 用 $all 一个条件即可，实测命中 1 条，且能走 tags 索引。')
body(doc, '第四是流水增长。borrow_logs 要按月看趋势、按读者和图书两个维度查历史、按状态筛逾期。关系模型要多表 JOIN，'
     '数据量上来后聚合成本高；文档模型把一次借阅的所有字段放进一个文档，聚合管道一次扫描完成，3000 条上 36 个月趋势查询为毫秒级。')
table(doc, '表 2　关系模型与本平台字段的适配困难',
      ['业务字段', '关系模型的典型处理', '实际困难', '文档模型的处理'],
      [('tags（数组，部分缺失）', '标签表 + 关联表', '三表连接、计数子查询，缺失值需特殊标记', '数组字段，$all 匹配，可建多键索引'),
       ('location（楼层/架位/复本）', '独立位置表 + 外键', '每次展示都要 join，单字段更新跨表维护', '嵌入文档，随书读写，$set 原子更新'),
       ('fav_categories、email', '可空列或扩展表', '列稀疏，空值与“不存在”混淆', '字段可缺省，exists 判断'),
       ('borrow_logs（持续增长）', '流水表 + 多表 JOIN', '聚合慢，历史归档需拆表', '单文档承载一次借阅，聚合分桶，可分片')],
      [3.6, 3.8, 4.4, 4.2], ['left', 'left', 'left', 'left'])

heading(doc, "2.2　四类 NoSQL 数据库的对比", 2)
body(doc, 'NoSQL 不是一个东西。键值、文档、列式、图四类在数据模型与查询方式上差别很大，选错方向的代价比选错产品更大。')
table(doc, '表 3　四类 NoSQL 数据库对比',
      ['类型', '代表产品', '数据模型', '查询与索引', '扩展方式', '匹配度'],
      [('键值', 'Redis', 'key → value', '按 key 读写，无多条件检索', '主从、集群分槽', '低'),
       ('文档', 'MongoDB', 'BSON 文档，可嵌套可数组', '二级索引、聚合管道', '副本集 + 分片', '高'),
       ('列式', 'HBase、Cassandra', '宽表，按行键排序', '行键扫描强，二级索引弱', '按行键分区', '中'),
       ('图', 'Neo4j', '节点 + 关系', '关系遍历、路径查询', '副本为主', '低')],
      [1.6, 2.8, 3.6, 3.6, 2.6, 1.6], ['center', 'left', 'left', 'left', 'left', 'center'])
body(doc, '选择文档型有三条理由：其一，业务字段异构且有嵌套，文档模型与数据结构同构，不必为存储改造业务对象；'
     '其二，六项检索、五项统计都能用二级索引与聚合管道完成，实测 11 项功能全部可执行；'
     '其三，高可用与水平扩展在同一技术栈内解决，副本集负责切换、分片负责容量与写入扩展、GridFS 直接承载电子书，不需要再引入对象存储。')

heading(doc, "2.3　CAP 取舍：两个场景，两种优先级", 2)
body(doc, 'CAP 不能笼统地“三选二”，要落到具体场景。本平台有两个性质完全不同的读写场景。')
body(doc, '馆藏查询场景读多写少，馆藏数量晚一秒更新可以接受，因此优先可用性与分区容忍性，即 AP。实现上把读偏好设为 SECONDARY_PREFERRED，'
     '正常时读从节点分担压力，从节点不可用时自动回落主节点。后文副本集实验验证了这点：两个从节点设为 hidden 后，SECONDARY_PREFERRED 仍成功，'
     '而严格指定 SECONDARY 的读取直接超时。')
body(doc, '借阅写入场景相反。借书要扣库存、置借出状态，同一本书不能被两人同时借走，因此优先一致性与分区容忍性，即 CP。'
     '实现上用单主接收写、writeConcern 设为 majority，故障窗口内宁可拒绝写也不脏写。实测击穿主节点后 10.5 秒产生新主，'
     '窗口内 30 次读成功 23 次、失败 7 次，失败集中在选举期，符合“短暂不可用但不丢数据”的预期。')
body(doc, 'BASE 与最终一致也要分功能讨论。可以接受最终一致的：category_stats 统计结果、月度趋势、排行榜，晚几十秒不影响决策；'
     '不可接受最终一致的：库存扣减、借阅状态流转、账号权限判定，读到旧值就会造成业务错误。')

heading(doc, "2.4　选型结论与两个风险", 2)
body(doc, '结论一句话：以文档模型承载异构馆藏与嵌套字段，用二级索引和聚合管道支撑检索统计，用副本集保证单点故障下的可用性，'
     '用哈希分片承载借阅流水的持续增长。')
body(doc, '风险一：schema 约束弱，脏数据容易进库。应对是三道关口——导入前按源文件清洗并核对条数，应用层对价格、评分、库存做范围校验，'
     '再保留固定质量核查查询（缺 tags 4 条、邮箱为空 5 条）每月跑一次。')
body(doc, '风险二：故障转移窗口内写入不可用。应对是分级处理：普通借还失败提示重试，后台批处理进入重试队列，'
     '并把 10 秒级选举窗口做成监控告警，超阈值人工介入。')

heading(doc, "2.5　面向非技术决策者的说明", 2)
body(doc, '选 MongoDB 不是追新技术，而是我们的图书信息本来就不整齐：有的书有标签、有的没有，位置信息又要和书一起显示。'
     '关系库要么留一堆空列，要么每次查询拼好几张表。文档库把一本书的所有信息放在一条记录里，查得快，以后加字段也不用改表。'
     '电子书可以直接存进数据库并与书目绑定，不再依赖共享盘。借阅量涨了加机器就能扩容，不用停机。')

heading(doc, "3　数据模型设计", 1)
heading(doc, "3.1　逻辑结构与集合划分", 2)
body(doc, '平台使用一个数据库 smartlib，五个业务集合加一个 GridFS 文件区：books 存馆藏，readers 存读者，borrow_logs 存借阅流水，'
     'audit_logs 存操作日志，category_stats 存分类统计结果；电子书 PDF 与封面通过 GridFS 存储，由 books.ebook_name 关联。'
     '当前库内 books 50 条、readers 30 条、borrow_logs 3000 条、category_stats 6 条、audit_logs 30 条，GridFS 6 个文件，'
     '整库 3128 个文档、数据大小 0.65 MB、索引 25 个。')
figure(doc, FIG / 'logical_model.png', '图 1　平台逻辑结构层次（数据库 → 集合 → 关键字段）', 15.0)

heading(doc, "3.2　三个容易选错的字段类型", 2)
body(doc, '字段类型选错，后面所有查询都会别扭。以下三个是最容易被追问、本项目也确实踩过的点。')
body(doc, '价格 price 必须是 Double 而不是 String。金额要参与价格区间筛选和平均价格聚合，字符串比较会把 99.0 排在 100.0 前面，'
     '数值聚合也不成立。同理 rating 用 Double，stock 与 borrow_count 用 Int。')
body(doc, '日期必须是 Date 而不是字符串。publish_date、borrow_date、return_date 都要做范围查询与按月分桶，字符串只能字典序比较，'
     '月份分桶还要截字符串。源数据是带 +08:00 的 ISO 8601 字符串，导入时解析成 UTC 存 Date，展示时转回本地时间，避免统计错位。')
body(doc, 'tags 用 Array<String> 而不是逗号分隔字符串。数组可建多键索引并用 $all 做同时包含匹配，字符串只能用正则且索引失效。'
     '缺字段时不写空数组、保留键不存在，这样“缺 tags 的图书”才能被 exists 精确查出（实测 4 条）。')
table(doc, '表 4　关键字段类型与选型理由',
      ['集合', '字段', '选定类型', '理由'],
      [('books', 'isbn', 'String（唯一索引）', '定长编码，不是数值，不能算术，前导零须保留'),
       ('books', 'price / rating', 'Double', '参与区间筛选与 avg 聚合，字符串比较会出错'),
       ('books', 'publish_date', 'Date', '范围查询与 $month 分桶，源数据需转 UTC'),
       ('books', 'tags', 'Array<String>', '多值字段，$all 匹配，可建多键索引'),
       ('books', 'location', 'Object（嵌套）', '楼层/架位/复本与书一对一，随书读写'),
       ('readers', 'email', 'String 或缺失', '允许为空，用 exists 区分空串与无字段'),
       ('borrow_logs', 'status / duration_days', 'String / Int', '状态枚举筛选，时长数值排序与逾期判定')],
      [2.2, 3.6, 3.6, 6.6], ['center', 'left', 'left', 'left'])

heading(doc, "3.3　location 为什么嵌入而不拆分", 2)
body(doc, 'location 采用嵌套文档 {floor, shelf, copies}：三者与图书一对一，读取时总随书返回，更新时 $set location.shelf 即原子修改，'
     '查询“二楼专业图书区有哪些书”也能直接用 location.floor 过滤。')
body(doc, '但以下情况应反过来拆成独立集合：需要按书架维度单独统计容量与占用率；多本书共享同一库位且需独立管理；'
     '库位本身有生命周期（新建、封存、搬迁、调拨留痕）；要对库位设置独立访问权限。这些条件下位置的读写频次与生命周期都和图书不同，嵌套会成为负担。')

heading(doc, "3.4　audit_logs 的字段设计与集合类型", 2)
body(doc, '操作日志字段设计为 operator（操作人）、action（动作）、target（对象标识）、result（ok / denied）、ts（时间）、'
     'detail（可选补充）。索引建两条：ts 倒序用于最近 100 条查询，action 加 ts 复合用于按动作追溯。')
body(doc, '集合类型选普通集合，不用 capped。capped 容量固定、写入覆盖旧数据、不能删除单条文档，也不能随意建二级索引；'
     '审计日志却要按动作与时间组合查询、长期保留、未来按保留期清理，因此普通集合加 TTL 索引才合适。')

heading(doc, "3.5　borrow_logs 的集合类型", 2)
body(doc, 'borrow_logs 选普通集合：需要更新 return_date 与 status（还书、逾期扫描都要改），需要多个复合索引支撑双维度查询，'
     '还要作为分片目标承载增长。capped 不支持更新且容量固定；时序集合适合只追加的指标，但这里要按读者与图书维度更新和关联。'
     '实际一条流水文档约 154 字节，3000 条占 462 KB。')

heading(doc, "3.6　索引设计与清单", 2)
body(doc, '索引按“等值字段在前、范围字段在后、排序方向与查询一致”的原则设计，唯一约束单独建唯一索引。'
     '共 15 个业务索引：books 6 个、readers 3 个、borrow_logs 4 个、audit_logs 2 个。')
table(doc, '表 5　索引清单',
      ['集合', '索引名', '键', '用途'],
      [('books', 'uk_isbn', '{isbn:1}', '唯一，防重复入库'),
       ('books', 'idx_category_price', '{category:1, price:1}', '类别 + 价格区间'),
       ('books', 'idx_tags', '{tags:1}', '多键索引，$all 匹配'),
       ('books', 'idx_rating_desc', '{rating:-1}', '评分榜排序'),
       ('books', 'idx_publish_date', '{publish_date:1}', '出版年份范围'),
       ('books', 'idx_borrow_count', '{borrow_count:-1}', '借阅次数排行'),
       ('readers', 'uk_card_no', '{card_no:1}', '唯一，借阅证号'),
       ('readers', 'idx_college_level', '{college:1, level:1}', '学院 + 等级'),
       ('readers', 'idx_register_date', '{register_date:1}', '注册时间范围'),
       ('borrow_logs', 'idx_reader_date', '{reader_card:1, borrow_date:-1}', '读者借阅历史倒序'),
       ('borrow_logs', 'idx_book_date', '{book_isbn:1, borrow_date:-1}', '书目借阅记录倒序'),
       ('borrow_logs', 'idx_date_status', '{borrow_date:1, status:1}', '按月统计与状态过滤'),
       ('borrow_logs', 'idx_status_duration', '{status:1, duration_days:-1}', '逾期记录按时长'),
       ('audit_logs', 'idx_ts_desc', '{ts:-1}', '最近操作日志'),
       ('audit_logs', 'idx_action_ts', '{action:1, ts:-1}', '按动作追溯')],
      [2.4, 4.0, 4.8, 4.8], ['center', 'left', 'left', 'left'])

heading(doc, "3.7　五条关键设计决策", 2)
body(doc, '（1）一本书一个文档。复本数用 location.copies 表达，不为每一册建文档，避免书目信息重复存储与更新扩散。')
body(doc, '（2）位置嵌进图书。一对一、同时读写、需要原子更新；一旦库位要独立管理再按 3.3 的条件拆分。')
body(doc, '（3）借阅流水独立成集合，不塞进读者或图书文档。单文档上限 16 MB，借阅历史会无限增长，并发写同一文档还会冲突，独立集合还能分片。')
body(doc, '（4）审计日志与业务数据分开。审计写入频次高、保留策略不同、只按时间与动作查询，独立集合便于设 TTL 与权限隔离。')
body(doc, '（5）统计结果落库。category_stats 存分类快照供报表直读，同时用实时聚合定期比对，实测 6 条逐行一致。')

heading(doc, "4　功能实现", 1)
heading(doc, "4.1　模块划分与统一连接", 2)
body(doc, '程序按职责拆分：config 读取环境变量并生成连接描述，db 负责客户端单例、集合获取与拓扑识别，schema 维护集合选项与索引清单，'
     'util 负责时间转换与表格输出，audit 负责写操作日志，book_service、reader_service、borrow_service、file_service 承载四类业务，'
     'app 提供 20 项菜单，另有导入、性能、权限、导出四个脚本。')
body(doc, '统一连接模块不写死地址与路径：主机、端口、库名、账号、认证库、副本集名、读偏好全部来自环境变量，缺省值只用于本机演示。'
     '连接成功后打印脱敏连接描述、拓扑类型与主节点，便于截图取证和换机排查。当前环境为 Linux、Python 3.12、MongoDB 7.0.14、pymongo 4.19.0。')

heading(doc, "4.2　十一项检索与统计", 2)
body(doc, '检索与统计共 11 项，全部跑通并记录结果条数：检索覆盖组合条件、数组匹配、正则模糊、日期范围、缺失字段与排序；'
     '统计覆盖分类汇总、学院排名、时间趋势、关联查询与结果落库。')
table(doc, '表 6　检索与统计功能的实现与结果',
      ['编号', '功能', '实现要点', '结果'],
      [('①', '类别 + 价格区间', 'category 等值 + price 范围，走 idx_category_price', '8 条'),
       ('②', '标签多选匹配', '$all 同时包含指定标签，走 tags 多键索引', '1 条'),
       ('③', '书名模糊检索', '正则匹配书名，大小写不敏感', '2 条'),
       ('④', '出版年份范围', '$gte/$lt 按 Date 过滤', '1 条'),
       ('⑤', '缺 tags 质量核查', 'exists:false 精确找出缺失字段', '4 条'),
       ('⑥', '评分榜 TOP10', 'rating 倒序 + projection 只返回三字段', '10 条'),
       ('⑦', '分类藏书/均价/评分', '按 category 分组，sum/avg 三项指标', '6 类'),
       ('⑧', '学院借阅 TOP5', '按 reader_card 关联 readers 后分组', '5 名'),
       ('⑨', '月度借阅趋势', '$dateToString 按年月分桶', '36 个月'),
       ('⑩', '借阅 TOP10 含馆藏位置', '$lookup 关联 books 取 location', '10 本'),
       ('⑪', '分类统计落库', '聚合结果写入 category_stats', '6 条')],
      [1.2, 4.2, 8.0, 2.6], ['center', 'left', 'left', 'center'])
figure(doc, SHOTS / '05_检索4-6.png', '图 2　按出版年份、缺失字段与评分排序的检索结果', 15.0)

heading(doc, "4.3　索引优化：先有基线，再谈收益", 2)
body(doc, '性能对比最容易做成“加了索引就变快”的口号。本项目的做法是：先用 hint({$natural:1}) 强制全表扫描取得无索引基线，'
     '再用同一批查询跑有索引版本，最后逐层下钻 explain 叶子阶段读取 stage、totalDocsExamined、totalKeysExamined，'
     '每条用例执行 200 次取中位数，避免单次抖动。')
table(doc, '表 7　索引优化前后执行计划与耗时对比',
      ['查询用例', '扫描方式', '检查文档', '检查索引键', '优化前', '优化后', '提速'],
      [('Q1 图书：类别 + 价格区间', 'COLLSCAN→IXSCAN', '50→8', '0→8', '0.301 ms', '0.328 ms', '0.9x'),
       ('Q2 流水：借阅日期区间', 'COLLSCAN→IXSCAN', '3000→500', '0→500', '0.676 ms', '0.305 ms', '2.2x'),
       ('Q3 流水：书目借阅记录倒序', 'COLLSCAN→IXSCAN', '3000→60', '0→60', '1.999 ms', '0.301 ms', '6.6x'),
       ('Q4 流水：逾期记录按时长倒序', 'COLLSCAN→IXSCAN', '3000→429', '0→429', '2.095 ms', '0.393 ms', '5.3x')],
      [4.6, 3.0, 2.0, 2.2, 1.8, 1.8, 1.2],
      ['left', 'center', 'center', 'center', 'right', 'right', 'center'])
body(doc, 'Q1 没有收益甚至略慢（0.301→0.328 ms），原因是 books 只有 50 条，全表扫描本就 0.3 毫秒，索引反而多一次间接访问。'
     '这说明优化要看集合规模与选择度：小集合加索引是负收益，流水集合上才是 2 至 6 倍的正收益。Q3 提速最大，索引同时满足过滤与排序，扫描文档从 3000 降到 60。')
figure(doc, SHOTS / '09_执行计划.png', '图 3　explain 输出的扫描方式与检查文档数对比', 15.0)

heading(doc, "4.4　三角色权限与越权验证", 2)
body(doc, '按最小权限原则建三个账号，对应只读、读写、管理三类角色，全部建在业务库 smartlib 下，认证库同样指定为 smartlib。'
     '验证方式是三个账号执行同一批读操作，再对只读账号执行写操作，确认被拒绝。')
table(doc, '表 8　账号权限与越权验证结果',
      ['账号', '角色', '可读图书数', '写入结果', '结论'],
      [('lib_readonly', 'read', '50', '被拒，code=13', '只读账号无法写入'),
       ('lib_readwrite', 'readWrite', '50', '成功', '应用账号按需读写'),
       ('lib_admin', 'dbOwner', '50', '成功', '管理账号可维护集合与索引')],
      [3.6, 2.8, 2.6, 3.4, 3.6], ['left', 'center', 'center', 'left', 'left'])
body(doc, '单机实例以 authorization: enabled 重启后带认证跑通全流程；副本集在此基础上加 keyFile 做节点间认证，权限设为 0600。')

heading(doc, "4.5　应用程序、日志与图形化一致性", 2)
body(doc, '主程序提供 20 项菜单：6 项检索、5 项统计、4 项维护、2 项借还、3 项文件操作、1 项日志查看，另加退出。'
     '演示模式跑完全部功能，借还用独立演示实体（读者 RDEMO0001、ISBN 9787000000001），跑完立即删除，'
     '保证 3000 条真实流水不被污染——演示后核对仍是 3000 条。')
figure(doc, SHOTS / '11_应用菜单.png', '图 4　主程序菜单与连接信息', 14.4)
body(doc, '所有新增、删除、借还、上传、下载都写入 audit_logs，记录操作人、动作、对象、结果与时间。演示后库内共 30 条日志，'
     '可按时间倒序查看最近 12 条，满足“最近 100 条”的查询要求。')
body(doc, '为避免“程序算一遍、控制台再算一遍”出现两套结论，另做了一个图形化控制台，与命令行程序共用同一份连接配置，'
     '含概览、数据浏览、聚合查询、文件存储、操作日志五个页面。聚合查询页把实时聚合结果与 category_stats 落库值逐行比对，'
     '六条全部显示“一致”，并可把统计结果导出为 JSON 与 CSV。')
figure(doc, SHOTS / '32_图形化聚合比对.png', '图 5　控制台聚合结果与落库值逐行比对', 15.0)

heading(doc, "5　文件存储", 1)
body(doc, '电子书与封面是二进制文件，生产环境的 PDF 动辄几十兆，超过 BSON 文档 16 MB 上限，不能直接内嵌。'
     'GridFS 把文件切成 255 KB 的块存入 chunks 集合，元数据（文件名、长度、上传时间、自定义 metadata）存入 files 集合，'
     '读取时按块序号自动拼装，天然支持大文件与流式读取。')
body(doc, '本项目把 3 本 PDF 与 3 张封面写入 GridFS，metadata 记录 ISBN、文件类型与原始文件名，便于按书目检索；'
     '同时在 books 的 ebook_name 字段登记文件名，形成“书目 → 文件”的反向索引。上传后逐个比对字节数，六个文件全部一致。')
table(doc, '表 9　GridFS 文件与字节核对',
      ['文件', '类型', 'ISBN', 'GridFS 字节', '源文件字节', '核对'],
      [('ebook_1.pdf', 'ebook', '9787115428028', '39837', '39837', '一致'),
       ('ebook_2.pdf', 'ebook', '9787121362726', '38524', '38524', '一致'),
       ('ebook_3.pdf', 'ebook', '9787115546081', '37004', '37004', '一致'),
       ('cover_1.png', 'cover', '9787115428028', '23611', '23611', '一致'),
       ('cover_2.png', 'cover', '9787121362726', '26053', '26053', '一致'),
       ('cover_3.png', 'cover', '9787115546081', '15171', '15171', '一致')],
      [2.8, 1.6, 3.8, 2.6, 2.6, 1.6], ['left', 'center', 'center', 'right', 'right', 'center'])
body(doc, '下载校验走“书名 → 书目 → 文件名 → GridFS”的真实链路：按书名模糊查到《Python编程：从入门到实践》，取到 ebook_1.pdf，'
     '读出并落盘到 data/downloads，再比对字节数与 SHA-256，结果一致。这一步同时验证了书名检索、ISBN 关联、文件读取与完整性校验。')
figure(doc, SHOTS / '13_上传校验.png', '图 6　六个文件上传后的字节核对结果', 15.0)
body(doc, '文件清单可按文件名、类型、大小、上传时间与 ISBN 列出，六条齐全，可直接作为交付物核对。')

heading(doc, "6　架构演进", 1)
heading(doc, "6.1　副本集：先讲清读偏好，再演故障", 2)
body(doc, '单机升级的第一步是高可用。三个实例分别使用 27018、27019、27020 端口与独立数据目录，以同一 keyFile 启动并开启认证，'
     '初始化后形成一主两从。副本集的价值不只是“有备份”，而是读偏好真的能改变请求落到哪个节点。')
table(doc, '表 10　三种读偏好在两种拓扑下的表现',
      ['读偏好', '三节点正常', '两个从节点 hidden 后', '说明'],
      [('PRIMARY', '成功，1 条', '成功，1 条', '只读主节点，写后读一致'),
       ('SECONDARY', '成功，1 条', '失败，选点超时', '严格只读从节点，无可用从节点即失败，不回落'),
       ('SECONDARY_PREFERRED', '成功，1 条', '成功，1 条', '优先从节点，不可用时回落主节点')],
      [4.2, 3.4, 4.4, 4.0], ['left', 'center', 'center', 'left'])
body(doc, '这张表的第二、三行是最有说服力的一处证据：把两个从节点临时设为 hidden（priority=0，对客户端不可见）后，'
     'SECONDARY 报出“No replica set members match selector Secondary()”，而 SECONDARY_PREFERRED 依然成功——'
     '说明读偏好不是注释，而是真正参与了节点选择。')

heading(doc, "6.2　故障转移：10.5 秒里发生了什么", 2)
body(doc, '演练用 SIGKILL 直接杀掉主节点 27018，模拟进程崩溃而非优雅关闭。故障时刻记为 17:23:11，随即每 0.3 秒发起一次读请求，'
     '共 30 次，同时轮询副本集状态观察新主产生。')
body(doc, '结果：新主 27020 在故障后 10.5 秒产生；30 次读成功 23 次、失败 7 次，失败集中在选举窗口；新主立即可写，'
     '故障前写入的 4 条测试文档全部可读；重启原主节点后它以 SECONDARY 角色回归，副本集恢复一主两从。'
     '也就是说，故障期间读会有秒级抖动，但数据不丢，也不会出现双主写入。')
figure(doc, SHOTS / '20_故障转移.png', '图 7　主节点被击穿后的新主产生时间与读写表现', 15.0)
body(doc, '节点增删同样做了演练：临时启动 27025 加入副本集，成员从 3 变 4，同步正常后再移除回到 3 个。'
     '过程中踩到一个坑：在从节点 27020 上执行配置变更被拒绝，提示 replSetReconfig 只能在可写主节点执行，改到主节点后成功。'
     '认证方面，未认证访问直接被拒（Command aggregate requires authentication），只读账号插入被拒，应用带副本集参数可正常读到 50/30/3000 条。')

heading(doc, "6.3　分片集群：拓扑与落地顺序", 2)
body(doc, '分片解决单机容量与写入上限。集群由一个配置服务器副本集、两个分片副本集和一个路由节点组成，全部启用 keyFile 认证。'
     '实验环境为节省资源，每个分片只放一个成员，生产环境应为三节点副本集。')
table(doc, '表 11　分片集群节点与端口',
      ['节点', '端口', '角色', '说明'],
      [('rsConfig', '27021', '配置服务器（单成员副本集）', '保存分片元数据与 chunk 路由表'),
       ('rsShard1', '27022', '分片一（单成员副本集）', '承载约 42% 流水'),
       ('rsShard2', '27023', '分片二（单成员副本集）', '承载约 58% 流水'),
       ('mongos', '27024', '路由节点', '应用唯一入口，负责路由与结果归并')],
      [3.0, 2.0, 5.4, 5.6], ['left', 'center', 'left', 'left'])
body(doc, '落地顺序有讲究：先建库导入静态数据，再对 borrow_logs 执行 shardCollection 指定分片键，最后灌入 3000 条流水。'
     '若先灌数据再分片，数据会先落在单个分片上，必须等均衡器迁移 chunk，验证时间不可控。按正确顺序，3000 条写入即按哈希值与路由直接分散到两个分片。')

heading(doc, "6.4　分片键论证", 2)
body(doc, 'borrow_logs 的分片键选 {book_isbn: "hashed"}，依据是基数、写分布均匀性与常用查询三项。'
     '基数方面，样例库只有 50 本书，生产约 50 万册，ISBN 取值空间足够大，哈希后不会出现大量文档挤在少数取值上。'
     '写分布方面，借阅热度差异明显，最热的一本被借 60 次，冷门书只有一两次；若按 ISBN 范围分片，相邻 ISBN 会集中到同一 chunk，'
     '热门书所在 chunk 成为写热点，而哈希把 ISBN 打散到固定区间，写入自然分散——实测两个分片分别承载 1740 与 1260 条，'
     '4 个 chunk 各占两个，分布接近。')
body(doc, '常用查询方面，业务最高频的是“某本书的借阅记录”，带 ISBN 条件时 mongos 能直接算出目标分片，只访问一个分片，'
     '实测中位耗时 0.65 至 0.71 毫秒。代价也要说清楚：哈希分片丢失按 ISBN 范围路由的能力，按借阅日期、读者证号、状态查询都会扇出到两个分片再归并，'
     '实测 0.90 至 1.03 毫秒，仍在一毫秒级；当前规模可以接受，因为分片少、单片数据量小。若未来按时间归档成为主查询，'
     '可改为复合键 {book_isbn: "hashed", borrow_date: 1}，让同一本书的流水固定落在同一分片且片内按时间有序，但配置与 chunk 管理成本会上升。')
table(doc, '表 12　分片键备选方案对比',
      ['方案', '写分布', '定向查询', '主要问题', '结论'],
      [('{book_isbn: "hashed"}', '均匀，1740/1260', '按 ISBN 定向单分片', '时间维度查询需跨片', '采用'),
       ('{borrow_date: 1}', '按时间递增，最新 chunk 为热点', '按时间范围可定向', '写热点集中，按 ISBN 变全扫', '不选'),
       ('{reader_card: "hashed"}', '较均匀但受活跃度影响', '按读者定向', '热门读者倾斜，按 ISBN 跨片', '不选'),
       ('{book_isbn: "hashed", borrow_date: 1}', '均匀', '按 ISBN + 时间定向', '复合键配置复杂，范围收益有限', '备选')],
      [5.6, 2.8, 2.8, 2.8, 2.0], ['left', 'left', 'left', 'left', 'center'])

heading(doc, "6.5　跨片查询与定向查询的实测对比", 2)
body(doc, '在 mongos 上跑五组查询，用 explain 判断参与分片数，再各跑 100 次取中位耗时。带 ISBN 的两组只访问 rsShard1 一个分片，'
     '耗时 0.65 至 0.71 毫秒；按状态、读者证号、月份统计的三组访问两个分片，耗时 0.90 至 1.03 毫秒。')
table(doc, '表 13　定向查询与跨分片查询对比',
      ['查询', '参与分片', '返回条数', '中位耗时'],
      [('按 ISBN 查某本书的借阅记录', '1（rsShard1）', '60', '0.65—0.71 ms'),
       ('按 ISBN + 时间范围', '1（rsShard1）', '39', '0.66—0.70 ms'),
       ('按状态筛逾期记录', '2（rsShard1、rsShard2）', '100', '0.96—1.00 ms'),
       ('按读者证号查借阅历史', '2（rsShard1、rsShard2）', '100', '0.90—0.91 ms'),
       ('按年月统计借阅量', '2（rsShard1、rsShard2）', '100', '1.03—1.20 ms')],
      [7.4, 4.6, 2.2, 1.8], ['left', 'center', 'center', 'center'])
figure(doc, SHOTS / '26_分片分布.png', '图 8　两个分片的文档数与 chunk 分布', 14.4)
body(doc, '集群同样配置了访问控制：未认证访问报“Command aggregate requires authentication”，cluster_admin 可查看分片列表与全库条数，'
     'app_user 可执行跨片聚合，应用连接后拓扑识别为 sharded，书目类别统计与单机结果完全一致。')

heading(doc, "7　问题与总结", 1)
heading(doc, "7.1　三个技术难点的排查过程", 2)
body(doc, '难点一：pymongo 4.19 的接口与网上教程不一致。按旧写法 GridFS(bucket_name=...) 直接抛参数不支持，ReadPreference.from_string 已不存在，'
     '给 MongoClient.read_preference 赋值报只读属性。排查方法是读异常栈定位到具体参数，再到驱动版本说明核对签名，'
     '最终改为 GridFS(db, collection=...)、用读偏好常量配合 collection.with_options(read_preference=...)，十处调用全部回归通过。')
body(doc, '难点二：mongos 带认证启动失败。按 mongod 的写法在配置里加 security.authorization: enabled，mongos 启动直接退出，'
     '前端只看到“启动超时”。逐行比对日志与官方配置项后确认，mongos 只接受 security.keyFile，authorization 属于非法配置；'
     '改为按节点类型生成不同的安全配置块，mongos 只写 keyFile，问题消失。教训是同一集群里不同进程的可配置项并不相同。')
body(doc, '难点三：配置变更与端口释放。在从节点执行 rs.add/rs.remove 被拒绝，提示 replSetReconfig 只能在可写主节点执行，改到主节点后成功；'
     '另外启停脚本停实例后立即启动，端口尚未释放，出现假“启动超时”，改为先探测端口关闭再启动，此后未复现。')

heading(doc, "7.2　两个风险与应对", 2)
body(doc, '数据倾斜与 chunk 分裂。哈希分片已把写打散，但业务增长后仍可能出现单 chunk 过大。应对是定期查看各分片文档数与 chunk 数，'
     '接近阈值时让均衡器迁移，必要时调整分片键或 reshard。')
body(doc, '权限过大与凭据暴露。应对是最小权限账号、keyFile 0600、密码只经环境变量注入，配置与代码不出现明文口令，日志输出前脱敏。')

heading(doc, "7.3　项目反思", 2)
body(doc, '这次实践的收获不在“会写几个查询”，而在把每个结论落到可复核的证据上：性能数字来自 explain 叶子阶段而不是感觉，'
     '故障转移有精确到秒的时间线和成功失败计数，分片分布有 collStats 的分片明细，权限验证有错误码。文档里每个数字都能在日志与截图里找到出处。'
     '不足也要承认：没有做接近生产规模的压力测试，分片集群每个分片只有单成员，不具备真正的高可用；书名模糊检索仍用正则，中文分词与全文索引尚未验证。')

# ---------------- 附录 ----------------
doc.add_section(WD_SECTION.NEW_PAGE)
page_setup(doc.sections[-1])
heading(doc, "附录 A　过程记录截图索引", 1)
body(doc, '截图按七个任务顺序编号，共 37 张，全部为实际运行输出，文件名与 shots 目录一致。')
names = sorted([p.name for p in SHOTS.glob("*.png")])
notes = {
    '01': '运行环境与驱动版本：MongoDB 7.0.14、pymongo 4.19.0',
    '02': '建库建索引：4 个业务集合与 15 个索引',
    '03': '导入核对：源文件 50/30/3000 与库内一致',
    '04': '检索①②③：组合 8 条、标签 1 条、模糊 2 条',
    '05': '检索④⑤⑥：年份 1 条、缺 tags 4 条、TOP10',
    '06': '统计①—③：分类 6 类、学院 TOP5、36 个月（两页）',
    '07': '统计④⑤：借阅 TOP10 含位置、落库 6 条',
    '08': '索引优化：Q2 2.2 倍、Q3 6.6 倍、Q4 5.3 倍',
    '09': 'explain：COLLSCAN 与 IXSCAN 检查文档数',
    '10': '权限：只读账号写入被拒 code=13',
    '11': '主程序菜单与连接信息（20 项）',
    '12': '借还业务：演示实体借书、还书、删除',
    '13': 'GridFS 上传：6 个文件字节一致',
    '14': '下载校验：字节一致且 SHA-256 通过',
    '15': '文件清单：文件名、大小、上传时间',
    '16': 'audit_logs：最近 12 条操作日志',
    '17': '副本集初始化：一主两从',
    '18': '读偏好：三节点正常三种偏好均成功',
    '19': '读偏好：hidden 后 SECONDARY 失败、PREFERRED 回落',
    '20': '故障转移：新主 10.5 秒，30 次读 23 成功',
    '21': '故障恢复：原主以 SECONDARY 回归',
    '22': '节点增删：加 27025 到 4 成员，移除回 3 成员',
    '23': '副本集认证：未认证被拒、只读写入被拒',
    '24': '分片部署：配置服务器、两分片、路由与分片键',
    '25': '分片导入：先分片后灌数 3000 条',
    '26': '分片分布：1740 / 1260，4 个 chunk',
    '27': '查询对比：定向 1 分片、跨片 2 分片',
    '28': '集群认证：未认证被拒、管理员与应用可用',
    '29': '图形化概览：条数与 dbStats 一致',
    '30': '图形化数据浏览：books 分页展示',
    '31': '图形化借阅流水：borrow_logs 查询',
    '32': '图形化聚合：实时结果与落库值一致',
    '33': '图形化文件存储：6 个文件可下载',
    '34': '图形化操作日志：按时间倒序',
    '35': '统计导出：JSON 与 CSV',
    '36': '最终核对：整库条数与 dbStats',
}
rows = []
for i in range(0, len(names), 2):
    pair = names[i:i + 2]
    row = []
    for n in pair:
        idx = n[:2]
        row.extend([idx, n, notes.get(idx, '')])
    if len(row) < 6:
        row.extend(['', '', ''])
    rows.append(tuple(row))
table(doc, '表 14　过程记录截图索引',
      ['编号', '文件', '核对要点', '编号', '文件', '核对要点'],
      rows, [1.0, 3.6, 3.4, 1.0, 3.6, 3.4],
      ['center', 'left', 'left', 'center', 'left', 'left'], font_size=8)

doc.save(OUT)
print("saved", OUT)
