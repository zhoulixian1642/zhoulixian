"""生成文档用的逻辑结构示意图（数据库 → 集合 → 文档字段）。"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

plt.rcParams["font.family"] = "Noto Sans CJK JP"
plt.rcParams["axes.unicode_minus"] = False

OUT = Path(__file__).resolve().parent.parent / "figures"
OUT.mkdir(exist_ok=True)

INK = "#1f2d3d"
LINE = "#8a9aa8"
COLL = ["books\n馆藏图书", "readers\n读者", "borrow_logs\n借阅流水",
        "audit_logs\n操作日志", "GridFS\n电子书文件"]
FIELDS = [
    "isbn / title / category\nprice / rating / stock\ntags / publish_date\nlocation{floor,shelf,copies}",
    "card_no / name / college\nlevel / register_date\nfav_categories",
    "reader_card → readers\nbook_isbn → books\nborrow_date / return_date\nstatus / duration_days",
    "operator / action / target\nresult / ts",
    "filename / length\nuploadDate / metadata{isbn,type}",
]

fig, ax = plt.subplots(figsize=(11, 5.6))
ax.set_xlim(0, 11)
ax.set_ylim(0, 5.6)
ax.axis("off")

ax.add_patch(FancyBboxPatch((0.25, 4.4), 10.5, 0.7, boxstyle="round,pad=0.02,rounding_size=0.08",
                            fc="#e8f0f4", ec=LINE, lw=1))
ax.text(5.5, 4.75, "数据库 smartlib（复制集 rs0 · 分片集群 shard1/shard2）", ha="center", va="center",
        fontsize=10.5, color=INK)

positions = [0.45, 2.55, 4.65, 6.75, 8.85]
width = 1.9
for x, name in zip(positions, COLL):
    ax.add_patch(FancyBboxPatch((x, 3.25), width, 0.78,
                                boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc="#cfe3ee", ec=LINE, lw=1))
    ax.text(x + width / 2, 3.64, name, ha="center", va="center", fontsize=9.5, color=INK)
    ax.add_patch(FancyBboxPatch((x, 1.25), width, 1.72,
                                boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc="#fbfcfd", ec=LINE, lw=0.8))
    ax.add_patch(FancyArrowPatch((x + width / 2, 3.25), (x + width / 2, 2.97),
                                 arrowstyle="-", lw=1, color=LINE))

for x, name, f in zip(positions, COLL, FIELDS):
    ax.text(x + width / 2, 2.11, f, ha="center", va="center", fontsize=8, color=INK)

ax.text(0.45, 0.85, "说明：books 的 location 为嵌套文档，不单独建集合；borrow_logs 以 reader_card、book_isbn 两个外键字段关联，"
        "\n采用「宽表 + 冗余字段」而非多表联查；GridFS 由 chunks/files 两个系统集合承载二进制与元数据。",
        ha="left", va="center", fontsize=8.5, color="#46586a")

fig.tight_layout()
fig.savefig(OUT / "logical_model.png", dpi=200, bbox_inches="tight", facecolor="white")
print("saved", OUT / "logical_model.png")
