# -*- coding: utf-8 -*-
"""
运行记录截图生成器
把每条真实命令的输出渲染成终端风格 PNG，便于直接放进项目文档附录。
用法：python3 tools/make_screenshots.py
"""
import json
import os
import subprocess
import sys
import textwrap

from PIL import Image, ImageDraw, ImageFont

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOT_DIR = os.path.join(BASE, "screenshots")
LOG_DIR = os.path.join(BASE, "evidence", "logs")
os.makedirs(SHOT_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"


def find_face_index():
    for i in range(12):
        try:
            f = ImageFont.truetype(FONT_PATH, 15, index=i)
            name = " ".join(f.getname())
            if "Mono" in name and "SC" in name:
                return i
        except Exception:
            continue
    return 0


FACE_INDEX = find_face_index()

SINGLE = {"MONGO_URI": "mongodb://127.0.0.1:27017", "MONGO_USER": "lib_editor",
          "MONGO_PWD": "Editor@2024", "MONGO_AUTHDB": "library"}
RS = {"MONGO_URI": "mongodb://127.0.0.1:27031,127.0.0.1:27032,127.0.0.1:27033/?replicaSet=rs0",
      "MONGO_USER": "lib_editor", "MONGO_PWD": "Editor@2024", "MONGO_AUTHDB": "library"}
SHARD = {"MONGO_URI": "mongodb://127.0.0.1:27020", "MONGO_USER": "root_admin",
         "MONGO_PWD": "Admin@2024", "MONGO_AUTHDB": "admin"}

MS = "/home/user/opt/mongosh-2.3.1-linux-x64/bin/mongosh"
MSS = f'{MS} --quiet "mongodb://lib_editor:Editor%402024@127.0.0.1:27017/library?authSource=library"'

CASES = [
    # (序号文件名, 标题, 命令, 环境变量)
    ("01_项目结构", "交付目录结构", "find . -maxdepth 2 -not -path './downloads*' -not -path './.git*' | sort | sed 's#[^/]*/#  #g' | head -46", None),
    ("02_单机启动", "单机实例启动与库状态", f'{MSS} --eval \'printjson(db.runCommand({{ping:1}})); printjson(db.stats().db+\" dataSize=\"+db.stats().dataSize+\" collections=\"+db.stats().collections)\'', None),
    ("03_数据导入", "三份数据导入与数量核对", "python3 src/import_data.py", SINGLE),
    ("04_数据质量", "数据质量巡检（缺失字段）", f'{MSS} --eval \'print(\"缺 tags 的图书: \"+db.books.countDocuments({{tags:{{$exists:false}}}})); print(\"缺 fav_categories 的读者: \"+db.readers.countDocuments({{fav_categories:{{$exists:false}}}})); print(\"email 为空的读者: \"+db.readers.countDocuments({{$or:[{{email:null}},{{email:\"\"}}]}}))\'; print(\"--- 一条 books 文档 ---\"); {MSS} --eval \'printjson(db.books.findOne({{}},{{_id:0}}))\'', None),
    ("05_检索1_类别价格", "检索一：类别+价格区间组合筛选", "printf '1\\n1\\n计算机\\n60\\n100\\n0\\n' | python3 src/main.py | tail -18", SINGLE),
    ("06_检索2_标签", "检索二：标签多选匹配（同时含多个标签）", "printf '1\\n2\\n编程,入门\\n0\\n' | python3 src/main.py | tail -12", SINGLE),
    ("07_检索3_书名", "检索三：书名模糊检索", "printf '1\\n3\\n系统\\n0\\n' | python3 src/main.py | tail -13", SINGLE),
    ("08_检索4_年份", "检索四：出版年份范围检索", "printf '1\\n4\\n2023\\n2024\\n0\\n' | python3 src/main.py | tail -14", SINGLE),
    ("09_检索5_缺字段", "检索五：缺少 tags 字段的图书", "printf '1\\n5\\n0\\n' | python3 src/main.py | tail -14", SINGLE),
    ("10_检索6_Top10", "检索六：评分倒序前 10（只返回三字段）", "printf '1\\n6\\n0\\n' | python3 src/main.py | tail -18", SINGLE),
    ("11_统计1_分类", "统计一：按类别统计藏书量/均价/均分", "printf '5\\n1\\n0\\n' | python3 src/main.py | tail -14", SINGLE),
    ("12_统计2_学院", "统计二：各学院借阅总量 Top5（$lookup 关联）", "printf '5\\n2\\n0\\n' | python3 src/main.py | tail -13", SINGLE),
    ("13_统计3_趋势", "统计三：按年月借阅趋势（时区处理）", "printf '5\\n3\\n0\\n' | python3 src/main.py | tail -20", SINGLE),
    ("14_统计4_排行", "统计四：借阅 Top10 图书并关联馆藏位置", "printf '5\\n4\\n0\\n' | python3 src/main.py | tail -18", SINGLE),
    ("15_统计5_落库", "统计五：分类统计结果写入新集合", "printf '5\\n5\\n0\\n' | python3 src/main.py | tail -14", SINGLE),
    ("16_索引清单", "索引清单（books/readers/borrow_logs）", f'{MSS} --eval \'[\"books\",\"readers\",\"borrow_logs\"].forEach(c=>{{print(\"===\"+c+\"===\"); db.getCollection(c).getIndexes().forEach(i=>print(\"  \"+i.name+\"  \"+JSON.stringify(i.key)))}})\'', None),
    ("17_索引前性能", "索引优化前的执行计划（强制全表扫描）", "python3 -c \"import json;d=json.load(open('evidence/index_perf.json'))['before'];[print(f\\\"{r['query']:<20} 阶段={r['stage']:<10} 检查文档={r['docsExamined']:<6} 检查键={r['keysExamined']:<5} 耗时={r['execMs']}ms 墙钟={r['avgWallMs']}ms\\\") for r in d]\"", None),
    ("18_索引后性能", "索引优化后的执行计划（走索引）", "python3 -c \"import json;d=json.load(open('evidence/index_perf.json'))['after'];[print(f\\\"{r['query']:<20} 阶段={r['stage']:<12} 索引={r['index']:<18} 检查文档={r['docsExamined']:<6} 耗时={r['execMs']}ms 墙钟={r['avgWallMs']}ms\\\") for r in d]\"", None),
    ("19_权限控制", "三角色权限验证（只读账号写入被拒）", f'echo \"[1] 只读账号读取\"; {MS} --quiet "mongodb://lib_reader:Reader%402024@127.0.0.1:27017/library?authSource=library" --eval \'print(\"books=\"+db.books.countDocuments())\'; echo \"[2] 只读账号写入\"; {MS} --quiet "mongodb://lib_reader:Reader%402024@127.0.0.1:27017/library?authSource=library" --eval \'db.books.insertOne({{isbn:\"TEST\",title:\"越权写入\"}})\' 2>&1 | head -3; echo \"[3] 管理账号写入\"; {MS} --quiet "mongodb://lib_admin:LibAdmin%402024@127.0.0.1:27017/library?authSource=library" --eval \'print(\"写入成功, 返回 id: \" + (db.audit_logs.insertOne({{action:\"权限验证\",ts:new Date()}}).insertedId))\'', None),
    ("20_应用菜单", "Python 应用主菜单（8 项功能）", "printf '0\\n' | python3 src/main.py | tail -18", SINGLE),
    ("21_GridFS上传", "GridFS 上传 3 个 PDF + 3 张封面（含 MD5）", "printf '6\\n1\\n0\\n' | python3 src/main.py | tail -18", SINGLE),
    ("22_文件清单", "GridFS 文件清单（大小/上传时间/关联 ISBN）", "printf '6\\n3\\n0\\n' | python3 src/main.py | tail -14", SINGLE),
    ("23_下载校验", "按书名下载并做字节数与 MD5 校验", "printf '6\\n2\\nPython编程\\n6\\n2\\n算法\\n6\\n2\\n计算机系统\\n0\\n' | python3 src/main.py | grep -E \"book|verify\" | head -6", SINGLE),
    ("24_存储统计", "GridFS 存储统计（按文件类型汇总）", "printf '6\\n4\\n0\\n' | python3 src/main.py | tail -6", SINGLE),
    ("25_操作日志", "操作日志 audit_logs（按时间倒序）", f'{MSS} --eval \'print(\"日志总数: \"+db.audit_logs.countDocuments()); db.audit_logs.find({{}},{{_id:0}}).sort({{ts:-1}}).limit(8).forEach(d=>print(d.ts.toISOString()+\"  \"+d.action+\"  \"+d.target+\"  \"+d.detail))\'', None),
    ("26_图书管理", "图书新增/删除/改库存", "printf '2\\n3\\n9787115428028\\n20\\n2\\n1\\n9780000000001\\n测试图书\\n测试作者\\n测试出版社\\n数学\\n45\\n4.0\\n3\\n测试\\n2\\n2\\n9780000000001\\n0\\n' | python3 src/main.py | tail -22", SINGLE),
    ("27_借阅管理", "借书/还书/读者流水", "printf '4\\n1\\nR20240001\\n9787115428028\\n30\\n4\\n2\\nR20240001\\n9787115428028\\n4\\n3\\nR20240001\\n0\\n' | python3 src/main.py | tail -16", SINGLE),
    ("28_副本集状态", "三节点副本集状态（主/从角色）", f'{MS} --quiet "mongodb://root_admin:Admin%402024@127.0.0.1:27031/admin?authSource=admin" --eval \'print(\"副本集: \"+rs.status().set+\"  节点数: \"+rs.status().members.length); rs.status().members.forEach(m=>print(\"  \"+m.name+\"  \"+m.stateStr+\"  health=\"+m.health+\"  uptime=\"+m.uptime+\"s\"))\'', None),
    ("29_读偏好验证", "读偏好验证：读写实际落点", "python3 src/read_pref_demo.py", None),
    ("30_故障转移", "故障转移演练：kill 主节点后选举与恢复", "timeout 120 python3 src/failover_test.py", None),
    ("31_故障时间线", "故障转移时间线（角色变化逐 0.2s 记录）", "python3 -c \"import json;d=json.load(open('evidence/failover.json'));print('选举耗时: '+str(d['election_seconds'])+'s');print('时间线:');[print(f\\\"  +{t['elapsed']:<5}s  27031={t['27031']:<11}27032={t['27032']:<11}27033={t['27033']}\\\") for t in d['timeline'][::5]];print('写探测: '+str(d['write_probe']))\"", None),
    ("32_节点增删", "副本集节点增删演练", "bash config/rs_member_demo.sh", None),
    ("33_副本集认证", "副本集启用认证后的访问控制", f'echo \"[无凭证]\"; {MS} --quiet "mongodb://127.0.0.1:27031/library" --eval \'db.books.countDocuments()\' 2>&1 | head -2; echo \"[有效凭证]\"; {MS} --quiet "mongodb://root_admin:Admin%402024@127.0.0.1:27031/admin?authSource=admin" --eval \'print(\"认证通过, 用户=\"+db.runCommand({{connectionStatus:1}}).authInfo.authenticatedUsers[0].user)\'', None),
    ("34_分片集群状态", "分片集群：分片列表与均衡状态", f'{MS} --quiet "mongodb://root_admin:Admin%402024@127.0.0.1:27020/admin?authSource=admin" --eval \'printjson(db.adminCommand({{listShards:1}}).shards.map(s=>({{shard:s._id,host:s.host,state:s.state}}))); print(\"库分片开关: \"+db.getSiblingDB(\"library\").getCollectionNames().length+\" 个集合\"); printjson(db.getSiblingDB(\"config\").collections.find({{_id:\"library.borrow_logs\"}},{{_id:0,key:1,unique:1}}).toArray())\'', None),
    ("35_数据分布", "数据在两个分片上的分布（文档数/chunk 数）", f'{MS} --quiet "mongodb://root_admin:Admin%402024@127.0.0.1:27020/admin?authSource=admin" --eval \'const c=db.getSiblingDB(\"library\"); c.borrow_logs.aggregate([{{$collStats:{{storageStats:{{}}}}}}]).forEach(r=>print(\"分片 \"+r.shard+\"  文档数=\"+r.storageStats.count+\"  大小=\"+r.storageStats.size+\"B\")); db.getSiblingDB(\"config\").chunks.aggregate([{{$group:{{_id:\"$shard\",n:{{$sum:1}}}}}}]).forEach(x=>print(\"chunk 数  \"+x._id+\" = \"+x.n))\'', None),
    ("36_分片键路由", "定向查询与跨分片查询执行计划对比", "python3 src/shard_query_demo.py", SHARD),
    ("37_集群权限", "分片集群访问控制验证", f'echo \"[只读账号读取]\"; {MS} --quiet "mongodb://lib_reader:Reader%402024@127.0.0.1:27020/library?authSource=library" --eval \'print(\"books=\"+db.books.countDocuments()+\"  borrow_logs=\"+db.borrow_logs.countDocuments())\'; echo \"[只读账号写入]\"; {MS} --quiet "mongodb://lib_reader:Reader%402024@127.0.0.1:27020/library?authSource=library" --eval \'db.books.insertOne({{isbn:\"X\",title:\"越权\"}})\' 2>&1 | head -2', None),
    ("38_应用连分片", "同一套程序连接分片集群运行统计", "printf '8\\n5\\n2\\n0\\n' | python3 src/main.py | tail -18", SHARD),
    ("39_命令行核对", "命令行程序与库内数据逐项核对", f'{MSS} --eval \'const c=[\"books\",\"readers\",\"borrow_logs\",\"audit_logs\",\"category_stats\"]; c.forEach(n=>print(n+\" = \"+db[n].countDocuments()+\" 条\")); print(\"分类统计合计藏书: \"+db.books.countDocuments()); print(\"分类统计行数: \"+db.category_stats.countDocuments())\'', None),
]


def run(cmd, env):
    e = os.environ.copy()
    e.update(env or {})
    p = subprocess.run(["bash", "-lc", cmd], cwd=BASE, env=e,
                       capture_output=True, text=True, timeout=180)
    out = (p.stdout or "") + (p.stderr or "")
    return out.replace("\r", "").strip("\n")


def render(name, title, cmd, text):
    lines = text.split("\n")[:62]
    # 按 96 个显示列换行（中文按 2 列计）
    wrapped = []
    for ln in lines:
        if not ln:
            wrapped.append("")
            continue
        cur, w = "", 0
        for ch in ln:
            cw = 2 if ord(ch) > 0x2E80 else 1
            if w + cw > 150:
                wrapped.append(cur)
                cur, w = "", 0
            cur += ch
            w += cw
        wrapped.append(cur)
    wrapped = wrapped[:64]

    f = ImageFont.truetype(FONT_PATH, 15, index=FACE_INDEX)
    fb = ImageFont.truetype(FONT_PATH, 16, index=FACE_INDEX)
    pad, lh, title_h = 18, 24, 40
    maxw = 0
    for ln in wrapped:
        maxw = max(maxw, f.getlength(ln))
    width = int(max(1080, min(maxw + pad * 2, 1560)))
    height = title_h + pad * 2 + lh * (len(wrapped) + 1)

    img = Image.new("RGB", (width, height), "#1b1f23")
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, width, title_h], fill="#2f363d")
    for i, c in enumerate(["#ff5f56", "#ffbd2e", "#27c93f"]):
        d.ellipse([14 + i * 20, 14, 26 + i * 20, 26], fill=c)
    d.text((88, 11), f"{name}  {title}", font=fb, fill="#e6edf3")

    y = title_h + pad
    d.text((pad, y), "$ " + cmd[:150], font=f, fill="#7ee787")
    y += lh
    for ln in wrapped:
        color = "#e6edf3"
        low = ln.lower()
        if any(k in ln for k in ("失败", "ERROR", "错误", "拒绝", "not authorized",
                                 "Unauthorized", "NotPrimary", "DOWN")):
            color = "#ff7b72"
        elif any(k in ln for k in ("成功", "一致", "OK", "通过", "已", "PRIMARY")):
            color = "#a5d6a7"
        d.text((pad, y), ln, font=f, fill=color)
        y += lh

    out = os.path.join(SHOT_DIR, f"{name}.png")
    img.save(out)
    with open(os.path.join(LOG_DIR, f"{name}.txt"), "w", encoding="utf-8") as fp:
        fp.write(text)
    return out


def main():
    only = sys.argv[1:] 
    for name, title, cmd, env in CASES:
        if only and not any(o in name for o in only):
            continue
        print(f"→ {name} {title} ... ", end="", flush=True)
        text = run(cmd, env)
        if not text.strip():
            text = "(该命令无输出)"
        render(name, title, cmd, text)
        print("ok")
    print("截图目录:", SHOT_DIR)


if __name__ == "__main__":
    main()
