"""按七个任务组织过程记录截图：从 logs/step_*.txt 取真实输出，渲染成终端窗口图。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import shot_term  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
LOGS = ROOT / "logs"
SHOTS = ROOT / "shots"


def seg(name, start=None, end=None, header=None, tail_lines=None):
    text = (LOGS / f"{name}.txt").read_text(encoding="utf-8")
    if start:
        i = text.index(start)
        text = text[i:]
    if end:
        j = text.index(end)
        text = text[:j]
    text = text.strip("\n")
    if tail_lines:
        text = "\n".join(text.split("\n")[-tail_lines:])
    return (header + "\n" if header else "") + text


SPECS = [
    # 任务一：技术选型与环境
    ("01_环境版本", "任务一 · 运行环境与驱动版本", seg("step_env")),
    # 任务二：数据建模与建库
    ("02_建库建索引", "任务二 · 建集合与建索引", seg("step_import", end="导入结果与条数核对",
                                                    header="$ python3 code/init_import.py --reset")),
    ("03_条数核对", "任务二 · 数据导入三方核对", seg("step_import", start="导入结果与条数核对")),
    # 任务三：检索统计、索引、权限
    ("04_检索1-3", "任务三 · 检索功能（一）", seg("step_demo_auth", start="检索①", end="检索④",
                                               header="$ python3 code/app.py --demo")),
    ("05_检索4-6", "任务三 · 检索功能（二）", seg("step_demo_auth", start="检索④", end="统计①")),
    ("06_统计1-3", "任务三 · 统计功能（一）", seg("step_demo_auth", start="统计①", end="统计④")),
    ("07_统计4-5", "任务三 · 统计功能（二）", seg("step_demo_auth", start="统计④", end="业务：")),
    ("08_索引对比", "任务三 · 索引优化前后耗时", seg("step_perf", end="表索引优化前后",
                                                 header="$ python3 code/perf_check.py")),
    ("09_执行计划", "任务三 · explain 扫描方式对比", seg("step_perf", start="表索引优化前后")),
    ("10_账号权限", "任务三 · 三角色权限验证", seg("step_security", header="$ python3 code/security.py")),
    ("11_应用菜单", "任务三 · 程序菜单与连接信息", seg("step_menu", tail_lines=26)),
    # 任务四：应用程序与文件存储
    ("12_借还业务", "任务四 · 借书还书与读者检索", seg("step_demo_auth", start="业务：", end="文件存储：")),
    ("13_上传校验", "任务四 · GridFS 上传与字节核对", seg("step_demo_auth", start="文件存储：",
                                                   end="命中：")),
    ("14_下载校验", "任务四 · 按书名下载与 SHA-256 校验", seg("step_demo_auth", start="命中：", end="文件名")),
    ("15_文件清单", "任务四 · GridFS 文件清单", seg("step_demo_auth", start="文件名", end="操作日志")),
    ("16_操作日志", "任务四 · audit_logs 操作日志", seg("step_demo_auth", start="操作日志 audit_logs")),
    # 任务五：副本集
    ("17_副本集初始化", "任务五 · 三节点副本集初始化", seg("step_rs_init",
        start="set=rs0  状态=1", header="$ mongosh --port 27018 --eval 'rs.initiate({_id:\"rs0\", members:[...]})'")),
    ("18_读偏好正常", "任务五 · 三节点正常时的读偏好", seg("step_rs_readpref", end="④ 将两个从节点",
                                                   header="$ python3 code/read_pref_demo.py")),
    ("19_读偏好回落", "任务五 · 无可用从节点时的读偏好", seg("step_rs_readpref", start="④ 将两个从节点", end="⑥")),
    ("20_故障转移", "任务五 · 主节点故障与新主产生", seg("step_rs_failover", end="④ 演练后角色",
                                                 header="$ python3 code/failover_drill.py")),
    ("21_故障恢复", "任务五 · 原主节点回归为从节点", seg("step_rs_failover", start="④ 演练后角色")),
    ("22_节点增删", "任务五 · 节点添加与移除", seg("step_rs_addnode")),
    ("23_副本集认证", "任务五 · 副本集访问控制", seg("step_rs_auth")),
    # 任务六：分片集群
    ("24_分片部署", "任务六 · 分片集群部署与分片键", seg("step_shard_init")),
    ("25_分片导入", "任务六 · 开启分片并导入流水", seg("step_shard_import",
        header="$ MONGO_PORT=27024 python3 conf/shard_import.py")),
    ("26_分片分布", "任务六 · 两个分片的文档与 chunk 分布", seg("step_shard_dist")),
    ("27_查询对比", "任务六 · 定向查询与跨分片查询", seg("step_shard_query",
        header="$ MONGO_PORT=27024 python3 code/shard_query_compare.py")),
    ("28_集群认证", "任务六 · 分片集群访问控制", seg("step_shard_auth")),
    # 任务七：图形化验收与导出
    ("35_统计导出", "任务七 · 统计结果导出为 JSON/CSV", seg("step_export",
        header="$ python3 code/export_stats.py")),
    ("36_最终核对", "任务七 · 最终条数与库统计", seg("step_final_counts",
        header="$ PYTHONPATH=code python3 -c 'dbStats'")),
]


def main():
    SHOTS.mkdir(exist_ok=True)
    for name, title, text in SPECS:
        shot_term.render(text, title, SHOTS / f"{name}.png",
                        footer="智慧图书馆数字资源平台 · 过程记录")


if __name__ == "__main__":
    main()
