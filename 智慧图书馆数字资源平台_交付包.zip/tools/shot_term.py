"""把真实终端输出渲染成"终端窗口"截图（深色主题），用于过程记录。

只做排版，不改内容：输入是程序/命令的原样输出，渲染时逐字符按等宽网格绘制，
中文用 CJK 字体、英文用等宽字体，长行自动折行。
"""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONO_B = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
CJK = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
CJK_B = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"

BG = (17, 24, 30)
BAR = (38, 45, 55)
TXT = (216, 224, 228)
DIM = (140, 155, 165)
GREEN = (126, 214, 160)
YELLOW = (232, 200, 120)
RED = (235, 130, 120)

FONT_SIZE = 15
LINE_H = 23
WIDTH = 1400
PAD = 26
BAR_H = 44


def _fonts(bold=False):
    return (ImageFont.truetype(MONO_B if bold else MONO, FONT_SIZE),
            ImageFont.truetype(CJK_B if bold else CJK, FONT_SIZE))


def _char_w(ch, mono, cjk):
    if ord(ch) < 128:
        return mono.getlength(ch)
    return cjk.getlength(ch)


def wrap_line(line, mono, cjk, max_w):
    """按像素宽度折行；中文按 CJK 字形宽度累计。"""
    out, cur, w = [], "", 0.0
    for ch in line:
        cw = _char_w(ch, mono, cjk)
        if w + cw > max_w and cur:
            out.append(cur)
            cur, w = ch, cw
        else:
            cur += ch
            w += cw
    out.append(cur)
    return out


def color_for(line):
    if line.startswith("$ "):
        return GREEN
    if line.strip().startswith("①") or line.strip().startswith("②"):
        return YELLOW
    if "失败" in line or "错误" in line or "MongoServerError" in line or "被拒" in line:
        return RED
    if line.startswith("#") or line.startswith("//"):
        return DIM
    return TXT


def render(text: str, title: str, out_path, footer: str = ""):
    mono, cjk = _fonts()
    mono_b, cjk_b = _fonts(bold=True)
    lines = []
    for raw in text.rstrip("\n").split("\n"):
        lines.extend(wrap_line(raw, mono, cjk, WIDTH - 2 * PAD - 8))

    per_page = 48
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[]]
    for idx, page in enumerate(pages, 1):
        height = BAR_H + PAD + len(page) * LINE_H + PAD + (26 if footer else 0)
        img = Image.new("RGB", (WIDTH, max(height, 260)), BG)
        d = ImageDraw.Draw(img)
        # 标题栏
        d.rectangle([0, 0, WIDTH, BAR_H], fill=BAR)
        for i, c in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
            d.ellipse([18 + i * 22, 15, 32 + i * 22, 29], fill=c)
        t = title if len(pages) == 1 else f"{title}（{idx}/{len(pages)}）"
        d.text((WIDTH / 2, BAR_H / 2), t, font=cjk_b, fill=(228, 232, 236), anchor="mm")

        y = BAR_H + PAD
        for line in page:
            # 字体分段绘制：ASCII 用等宽字体，中文用 CJK，保持字符网格
            x = PAD
            color = color_for(line)
            bold = line.startswith("$ ")
            seg_font_mono = mono_b if bold else mono
            seg_font_cjk = cjk_b if bold else cjk
            # 逐字符绘制保证网格严格对齐
            for ch in line:
                f = seg_font_mono if ord(ch) < 128 else seg_font_cjk
                d.text((x, y), ch, font=f, fill=color)
                x += _char_w(ch, mono, cjk)
            y += LINE_H
        if footer:
            d.text((PAD, y + 8), footer, font=cjk, fill=DIM)
        base = Path(out_path)
        page_path = base if len(pages) == 1 else base.with_name(f"{base.stem}_{idx}{base.suffix}")
        img.save(page_path)
        print("saved", page_path)
