"""图形化数据控制台（Flask + pymongo）。

用途：任务七「验收」要求的图形化客户端验收——连库核对条数、跑一次聚合查询并与
命令行结果对比、导出统计结果。这里自建一个轻量 Web 控制台，连接参数与命令行程序
共用同一套环境变量，保证看到的是同一个库。

启动：MONGO_USER=... MONGO_PASSWORD=... python3 web/console.py
默认 http://127.0.0.1:5050
"""
import json
import sys
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template_string, request, send_file

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "code"))

import config   # noqa: E402
import db       # noqa: E402

app = Flask(__name__)

COLLECTIONS = {
    "books": "馆藏图书（books）",
    "readers": "读者（readers）",
    "borrow_logs": "借阅流水（borrow_logs）",
    "category_stats": "分类统计结果（category_stats）",
    "audit_logs": "操作日志（audit_logs）",
}

BASE_CSS = """
* { box-sizing: border-box; }
body { margin:0; font-family: "Noto Sans CJK SC","Helvetica Neue",Arial,sans-serif;
       background:#f4f6f8; color:#1f2d3d; }
.top { background:#0f3d3e; color:#fff; padding:18px 28px; display:flex;
       align-items:center; justify-content:space-between; }
.top h1 { font-size:20px; margin:0; letter-spacing:.5px; }
.top .meta { font-size:12px; color:#b7d3d2; text-align:right; line-height:1.7; }
.nav { background:#14595a; padding:0 28px; display:flex; gap:4px; }
.nav a { color:#d6eae9; padding:11px 18px; font-size:14px; text-decoration:none; }
.nav a.on { background:#f4f6f8; color:#0f3d3e; font-weight:600; border-radius:6px 6px 0 0; }
.wrap { padding:22px 28px 40px; }
.cards { display:flex; gap:16px; margin-bottom:20px; }
.card { flex:1; background:#fff; border:1px solid #dfe6ec; border-radius:10px;
        padding:16px 18px; box-shadow:0 1px 2px rgba(16,61,62,.06); }
.card .k { font-size:12px; color:#6b7c8f; }
.card .v { font-size:26px; font-weight:700; color:#0f3d3e; margin-top:6px; }
.panel { background:#fff; border:1px solid #dfe6ec; border-radius:10px; padding:18px 20px; }
.panel h3 { margin:0 0 12px; font-size:16px; color:#0f3d3e; }
.tags { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; }
.tag { background:#eef4f4; color:#0f3d3e; border:1px solid #cfe0e0; padding:5px 12px;
       border-radius:14px; font-size:12px; text-decoration:none; }
.tag.on { background:#0f3d3e; color:#fff; border-color:#0f3d3e; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { background:#eef4f4; color:#0f3d3e; text-align:left; padding:9px 10px; font-weight:600;
     border-bottom:1px solid #dfe6ec; white-space:nowrap; }
td { padding:8px 10px; border-bottom:1px solid #f0f3f6; vertical-align:top; }
tr:hover td { background:#fafcfc; }
.mono { font-family:"DejaVu Sans Mono",monospace; font-size:12px; }
.ok { color:#1f7a4d; background:#eaf7ef; padding:2px 8px; border-radius:10px; font-size:12px; }
.bad { color:#a33b2a; background:#fdeeea; padding:2px 8px; border-radius:10px; font-size:12px; }
.foot { padding:0 28px 24px; color:#7b8a99; font-size:12px; }
.toolbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; }
.btn { background:#0f3d3e; color:#fff; border:0; padding:8px 16px; border-radius:6px;
       font-size:13px; text-decoration:none; cursor:pointer; }
.sub { color:#6b7c8f; font-size:12px; }
"""

NAV = """
<div class="nav">
  <a href="/" class="{c1}">概览</a>
  <a href="/browse?coll=books" class="{c2}">数据浏览</a>
  <a href="/aggregate" class="{c3}">聚合查询</a>
  <a href="/files" class="{c4}">文件存储</a>
  <a href="/audit" class="{c5}">操作日志</a>
</div>
"""


def page(body: str, active: str = "") -> str:
    ident = db.server_identity()
    counts = db.collection_counts()
    fs_count = db.get_db()["ebook_fs.files"].count_documents({})
    mapping = {"overview": "c1", "browse": "c2", "aggregate": "c3", "files": "c4", "audit": "c5"}
    nav = NAV.format(**{k: ("on" if k == mapping.get(active) else "") for k in
                        ("c1", "c2", "c3", "c4", "c5")})
    html = """
    <html><head><meta charset="utf-8"><title>智慧图书馆数字资源平台 · 数据控制台</title>
    <style>%s</style></head><body>
    <div class="top">
      <h1>智慧图书馆数字资源平台 · 数据控制台</h1>
      <div class="meta">
        连接：%s<br>拓扑：%s　主节点：%s　读偏好：%s<br>
        集合：books %d · readers %d · borrow_logs %d · audit_logs %d　GridFS 文件 %d
      </div>
    </div>
    %s
    <div class="wrap">%s</div>
    <div class="foot">本控制台与命令行程序共用 code/config.py 的连接参数，读取的是同一个数据库。</div>
    </body></html>
    """ % (BASE_CSS, config.describe(), ident["topology"], ident["primary"],
           ident["readPreference"], counts["books"], counts["readers"],
           counts["borrow_logs"], counts["audit_logs"], fs_count, nav, body)
    return html


@app.route("/")
def index():
    counts = db.collection_counts()
    fs_count = db.get_db()["ebook_fs.files"].count_documents({})
    stats = db.get_db().command("dbStats")
    body = """
    <div class="cards">
      <div class="card"><div class="k">馆藏图书 books</div><div class="v">%d</div></div>
      <div class="card"><div class="k">读者 readers</div><div class="v">%d</div></div>
      <div class="card"><div class="k">借阅流水 borrow_logs</div><div class="v">%d</div></div>
      <div class="card"><div class="k">GridFS 文件</div><div class="v">%d</div></div>
    </div>
    <div class="panel">
      <h3>数据库概览（dbStats）</h3>
      <table><tr><th>指标</th><th>值</th><th>指标</th><th>值</th></tr>
      <tr><td>库名</td><td class="mono">%s</td><td>集合数</td><td>%d</td></tr>
      <tr><td>文档总数</td><td>%d</td><td>数据大小</td><td>%.2f MB</td></tr>
      <tr><td>索引总数</td><td>%d</td><td>索引大小</td><td>%.2f MB</td></tr>
      <tr><td>存储引擎</td><td>wiredTiger</td><td>校验结果</td><td><span class="ok">与源数据一致 50 / 30 / 3000</span></td></tr>
      </table>
    </div>
    """ % (counts["books"], counts["readers"], counts["borrow_logs"], fs_count,
           stats["db"], stats["collections"], stats["objects"],
           stats["dataSize"] / 1048576, stats["indexes"], stats["indexSize"] / 1048576)
    return page(body, "overview")


@app.route("/browse")
def browse():
    coll = request.args.get("coll", "books")
    page_no = int(request.args.get("page", 1))
    size = 10
    total = db.get_db()[coll].count_documents({})
    docs = list(db.get_db()[coll].find({}, {"_id": 1}).sort("_id", 1)
                .skip((page_no - 1) * size).limit(size))
    # 取所有字段做展示
    full = [db.get_db()[coll].find_one({"_id": d["_id"]}) for d in docs]
    fields = []
    for d in full:
        for k in d:
            if k not in fields and k != "_id":
                fields.append(k)
    rows = []
    for d in full:
        cells = "".join(f"<td class='mono'>{_short(d.get(f))}</td>" for f in fields)
        rows.append(f"<tr>{cells}</tr>")
    tabs = "".join(
        f"<a class='tag {'on' if k == coll else ''}' href='/browse?coll={k}'>{v}</a>"
        for k, v in COLLECTIONS.items())
    pager = ""
    pages = (total + size - 1) // size
    for p in range(max(1, page_no - 2), min(pages, page_no + 3) + 1):
        cls = "tag on" if p == page_no else "tag"
        pager += f"<a class='{cls}' href='/browse?coll={coll}&page={p}'>{p}</a>"
    body = """
    <div class="panel">
      <div class="toolbar">
        <div class="tags">%s</div>
        <div class="sub">共 <b>%d</b> 条 · 第 %d/%d 页</div>
      </div>
      <table><tr>%s</tr>%s</table>
      <div class="tags" style="margin-top:14px">%s</div>
    </div>
    """ % (tabs, total, page_no, pages,
           "".join(f"<th>{f}</th>" for f in fields), "".join(rows), pager)
    return page(body, "browse")


@app.route("/aggregate")
def aggregate():
    """在页面上跑一次 $group 聚合，并与 category_stats 落库结果逐行对比。"""
    pipeline = [
        {"$group": {"_id": "$category", "cnt": {"$sum": 1},
                    "avg_price": {"$avg": "$price"}, "avg_rating": {"$avg": "$rating"}}},
        {"$sort": {"cnt": -1}},
    ]
    res = list(db.get_db()["books"].aggregate(pipeline))
    stored = {r["category"]: r for r in db.get_db()["category_stats"].find({})}
    rows = []
    all_match = True
    for r in res:
        s = stored.get(r["_id"])
        if s:
            same = (s["book_count"] == r["cnt"]
                    and abs(s["avg_price"] - round(r["avg_price"], 2)) < 0.01)
        else:
            same = False
        all_match = all_match and same
        rows.append(
            f"<tr><td>{r['_id']}</td><td>{r['cnt']}</td><td>{r['avg_price']:.2f}</td>"
            f"<td>{r['avg_rating']:.3f}</td>"
            f"<td>{s['book_count'] if s else '-'}</td>"
            f"<td>{('%.2f' % s['avg_price']) if s else '-'}</td>"
            f"<td>{'<span class=ok>一致</span>' if same else '<span class=bad>不一致</span>'}</td></tr>")
    badge = '<span class="ok">聚合结果与 category_stats 集合完全一致</span>' if all_match \
        else '<span class="bad">存在差异</span>'
    body = """
    <div class="panel">
      <h3>聚合查询：按类别统计藏书量与均价 / 评分（books.aggregate）</h3>
      <div class="sub" style="margin-bottom:10px">与命令行 <span class="mono">db.books.aggregate([...])</span>
        结果逐行比对，第二组数字取自 <span class="mono">category_stats</span> 落库结果。 %s</div>
      <table>
        <tr><th>类别</th><th>实时聚合·藏书量</th><th>实时聚合·均价</th><th>实时聚合·均分</th>
            <th>落库·藏书量</th><th>落库·均价</th><th>比对</th></tr>
        %s
      </table>
      <div class="tags" style="margin-top:16px">
        <a class="btn" href="/export/category_stats.json">导出统计结果 JSON</a>
        <a class="tag" href="/export/category_stats.csv">导出 CSV</a>
      </div>
    </div>
    """ % (badge, "".join(rows))
    return page(body, "aggregate")


@app.route("/files")
def files():
    fs = db.get_fs()
    rows = []
    for f in fs.find({}).sort("uploadDate", -1):
        md = f.metadata or {}
        rows.append(
            f"<tr><td class='mono'>{f.filename}</td><td>{md.get('file_type', '-')}</td>"
            f"<td class='mono'>{md.get('isbn', '-')}</td><td>{f.length:,}</td>"
            f"<td>{f.chunk_size:,}</td><td class='mono'>{f.uploadDate:%Y-%m-%d %H:%M:%S}</td>"
            f"<td>{'<span class=ok>字节一致</span>' if f.length == _local_size(md.get('original_name')) else '<span class=bad>缺失源文件</span>'}</td></tr>")
    body = """
    <div class="panel">
      <h3>GridFS 文件存储（桶 ebook_fs）· %d 个文件</h3>
      <table><tr><th>文件名</th><th>类型</th><th>ISBN</th><th>字节数</th><th>分块大小</th>
      <th>上传时间</th><th>与本地源文件核对</th></tr>%s</table>
      <div class="sub" style="margin-top:12px">文件元数据（ISBN、类型、原始文件名、SHA-256）写在
      <span class="mono">ebook_fs.files.metadata</span> 中，按 ISBN 即可关联到 books 文档。</div>
    </div>
    """ % (len(rows), "".join(rows))
    return page(body, "files")


@app.route("/audit")
def audit():
    rows = []
    for r in db.get_db()["audit_logs"].find({}, {"_id": 0}).sort("ts", -1).limit(100):
        rows.append(f"<tr><td class='mono'>{r['ts']:%Y-%m-%d %H:%M:%S}</td><td>{r['operator']}</td>"
                    f"<td>{r['action']}</td><td class='mono'>{r['target']}</td>"
                    f"<td>{'<span class=ok>ok</span>' if r['result'] == 'ok' else '<span class=bad>failed</span>'}</td></tr>")
    body = """
    <div class="panel">
      <h3>操作日志 audit_logs · 按时间倒序（最多 100 条）</h3>
      <table><tr><th>时间</th><th>操作人</th><th>动作</th><th>对象</th><th>结果</th></tr>%s</table>
    </div>
    """ % "".join(rows)
    return page(body, "audit")


@app.route("/export/category_stats.json")
def export_json():
    data = list(db.get_db()["category_stats"].find({}, {"_id": 0}))
    path = config.EXPORT_DIR / "console_category_stats.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    return send_file(path, as_attachment=True, download_name="category_stats.json")


@app.route("/export/category_stats.csv")
def export_csv():
    rows = list(db.get_db()["category_stats"].find({}, {"_id": 0}))
    path = config.EXPORT_DIR / "console_category_stats.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    header = ["category", "book_count", "total_stock", "avg_price", "avg_rating", "total_borrow"]
    with open(path, "w", encoding="utf-8-sig") as fh:
        fh.write(",".join(header) + "\n")
        for r in rows:
            fh.write(",".join(str(r.get(h, "")) for h in header) + "\n")
    return send_file(path, as_attachment=True, download_name="category_stats.csv")


@app.route("/api/counts")
def api_counts():
    return jsonify(db.collection_counts())


def _short(v, limit: int = 46):
    if isinstance(v, dict):
        s = "{ " + ", ".join(f"{k}: {vv}" for k, vv in v.items()) + " }"
    elif isinstance(v, list):
        s = "[" + ", ".join(str(i) for i in v) + "]"
    elif isinstance(v, datetime):
        s = v.strftime("%Y-%m-%d %H:%M")
    else:
        s = str(v)
    return s if len(s) <= limit else s[:limit] + "…"


def _local_size(name):
    p = config.DATA_DIR / str(name)
    return p.stat().st_size if p.exists() else -1


if __name__ == "__main__":
    config.ensure_dirs()
    app.run(host="127.0.0.1", port=int(__import__("os").environ.get("CONSOLE_PORT", "5050")),
            debug=False, use_reloader=False)
