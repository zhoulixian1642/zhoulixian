"""用 headless Chromium 给图形化控制台截图，作为任务七的验收过程记录。"""
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "shots")
BASE = "http://127.0.0.1:5050"
PAGES = [
    ("gui_01_overview.png", "/"),
    ("gui_02_books.png", "/browse?coll=books"),
    ("gui_03_borrow.png", "/browse?coll=borrow_logs"),
    ("gui_04_aggregate.png", "/aggregate"),
    ("gui_05_files.png", "/files"),
    ("gui_06_audit.png", "/audit"),
]

OUT.mkdir(parents=True, exist_ok=True)
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path="/usr/local/bin/chromium",
                                args=["--no-sandbox", "--font-render-hinting=none"])
    page = browser.new_page(viewport={"width": 1440, "height": 900}, device_scale_factor=2)
    for name, path in PAGES:
        page.goto(BASE + path, wait_until="networkidle")
        page.screenshot(path=str(OUT / name), full_page=(name in ("gui_05_files.png",)))
        print("saved", name)
    browser.close()
